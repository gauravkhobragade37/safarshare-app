export type VehicleType = 'Bike' | 'Car' | 'Auto' | 'Pickup/Truck' | 'Bus' | 'Train';

export type ParcelSlab = 'doc' | 'bag' | 'cargo' | 'full_vehicle';

export type TripStatus = 'Active' | 'Completed' | 'Cancelled';

export type BookingStatus =
  | 'Pending'
  | 'Counter Offered'
  | 'Countered_By_Driver'
  | 'Accepted'
  | 'Confirmed'
  | 'In-Transit'
  | 'Completed'
  | 'Cancelled'
  | 'Rejected';

export interface UserProfile {
  uid: string;
  name: string;
  displayName?: string;
  email: string;
  phone: string;
  gender: 'Male' | 'Female' | 'Other';
  photoURL: string;
  role: 'admin' | 'citizen';
  isBlocked?: boolean;
  blockReason?: string;
  lastActive?: number;
  ratingSum?: number;
  ratingCount?: number;
  avgRating?: number;
}

export interface UserVehicle {
  id: string;
  userUid: string;
  userEmail?: string;
  type: VehicleType;
  model: string;
  plate: string;
  created: number;
  kycStatus?: 'verified' | 'rejected' | 'pending';
}

export interface SavedPlace {
  id: string;
  userUid: string;
  title: string;
  address: string;
  createdAt: number;
}

export interface RideTrip {
  id: string;
  driverUid: string;
  driverName: string;
  driverEmail?: string;
  driverPhone?: string;
  driverDp?: string;
  from: string;
  to: string;
  date: string;
  time: string;
  pickupSpot?: string;
  status: TripStatus;
  created: number;
  updatedAt: number;
  passenger: boolean;
  parcel: boolean;
  seats: number;
  seatPrice: number;
  fare?: number;
  vehicle: string;
  carModel?: string;
  carNumber?: string;
  isLadiesOnly?: boolean;
  isFamilyOnBoard?: boolean;
  isDaily?: boolean;
  tripStarted?: boolean;
  typeDoc?: boolean;
  typeBag?: boolean;
  typeCargo?: boolean;
  docPrice?: number;
  bagPrice?: number;
  cargoPrice?: number;
  fullVehiclePrice?: number;
  geometry?: any;
  routeDistanceKm?: number;
  routeDurationMin?: number;
  cancelReason?: string;
  cancelledAt?: number;
}

export interface BookingRequest {
  id: string;
  rideId: string;
  driverUid: string;
  driverName: string;
  driverPhone?: string;
  passengerUid: string;
  passengerName: string;
  passengerPhone?: string;
  passengerEmail?: string;
  type: 'passenger' | 'parcel';
  numSeats?: number;
  slab?: ParcelSlab;
  originalPrice: number;
  currentPrice: number;
  price?: number;
  from: string;
  to: string;
  date: string;
  travelKm?: number;
  status: BookingStatus;
  paymentMode?: string;
  paymentSettlement?: string;
  recName?: string;
  recPhone?: string;
  startOtp?: string;
  dropOtp?: string;
  bookingScope?: 'intercity' | 'local';
  created: number;
  createdAt: number;
  updatedAt: number;
  cancelReason?: string;
  cancelledBy?: string;
  cancelledAt?: number;
  startedAt?: number;
  confirmedAt?: number;
  completedAt?: number;
  isRated?: boolean;
  driverRated?: boolean;
  passengerRated?: boolean;
  ratingStars?: number;
  lastMsgText?: string;
  lastMsgTime?: number;
  lastMsgSender?: string;
  lastMsgSenderName?: string;
}

export interface SponsoredAd {
  id: string;
  name: string;
  category: string;
  landmark: string;
  targetRoute?: string;
  phone: string;
  createdAt: number;
}

export interface ReportItem {
  id: string;
  type: string;
  reporterUid?: string;
  reporterName?: string;
  targetUid?: string;
  targetName?: string;
  requestId?: string;
  reason: string;
  status: 'open' | 'resolved';
  createdAt: number;
}

export interface LiveLocation {
  rideId: string;
  driverUid: string;
  lat: number;
  lng: number;
  accuracy?: number;
  speed?: number;
  updatedAt: number;
  status: 'live' | 'offline';
}

export interface ChatMessage {
  id: string;
  text: string;
  senderUid: string;
  senderName: string;
  createdAt: number;
}
