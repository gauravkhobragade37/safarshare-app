import React from 'react';
import { UserProfile } from '../types';

interface HeaderProps {
  currentUser: UserProfile | null;
  onLogin: () => void;
  onDemoLogin: (asAdmin: boolean) => void;
  onOpenProfile: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onLogin,
  onDemoLogin,
  onOpenProfile
}) => {
  return (
    <header className="bg-white/95 backdrop-blur-md px-4 py-2 sticky top-0 z-[1000] border-b border-slate-200 flex justify-between items-center h-[52px]">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5 font-extrabold text-lg text-blue-600 tracking-tight">
          <span>🚗 SafarShare</span>
        </div>
        <span className="bg-amber-300 text-slate-900 text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs">
          LIVE
        </span>
      </div>

      <div className="flex items-center gap-2">
        {!currentUser ? (
          <div className="flex items-center gap-1.5">
            <button
              onClick={onLogin}
              className="bg-gradient-to-r from-blue-600 to-sky-600 text-white px-3 py-1.5 rounded-xl text-xs font-bold shadow-md shadow-blue-600/20 hover:opacity-95 transition-all flex items-center gap-1.5"
            >
              <span>🔐</span>
              <span>Google Login</span>
            </button>
            <button
              onClick={() => onDemoLogin(true)}
              title="Test immediately with Demo Admin account"
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-2 py-1.5 rounded-xl text-[11px] font-bold transition-all"
            >
              👑 Demo Admin
            </button>
          </div>
        ) : (
          <button
            onClick={onOpenProfile}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 px-2.5 py-1 rounded-full cursor-pointer text-xs font-bold text-slate-800 transition-all"
          >
            <img
              src={currentUser.photoURL || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'}
              alt={currentUser.name}
              className="w-6 h-6 rounded-full object-cover border border-blue-600"
            />
            <span>{currentUser.name.split(' ')[0]}</span>
            {currentUser.role === 'admin' && (
              <span className="text-[10px] text-amber-500">👑</span>
            )}
          </button>
        )}
      </div>
    </header>
  );
};
