import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

interface MapViewProps {
  mapId: string;
  pickupCoords: { lat: number; lng: number };
  dropCoords: { lat: number; lng: number };
  onPickupChange: (coords: { lat: number; lng: number }) => void;
  onDropChange: (coords: { lat: number; lng: number }) => void;
  routeCoordinates?: [number, number][];
  altRoutes?: [number, number][][];
  selectedRouteIndex?: number;
  onSelectRouteIndex?: (index: number) => void;
  radarMode: 'intercity' | 'local';
  onToggleRadar: () => void;
  onTriggerGPS: () => void;
  isActiveTab: boolean;
}

export const MapView: React.FC<MapViewProps> = ({
  mapId,
  pickupCoords,
  dropCoords,
  onPickupChange,
  onDropChange,
  routeCoordinates,
  altRoutes,
  selectedRouteIndex = 0,
  onSelectRouteIndex,
  radarMode,
  onToggleRadar,
  onTriggerGPS,
  isActiveTab
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const dropMarkerRef = useRef<L.Marker | null>(null);
  const polylinesRef = useRef<L.Polyline[]>([]);

  // Initialize map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    const startPinHtml = `
      <div class="rapido-marker-container">
        <div class="rapido-tag green">Start Point 🚀</div>
        <div class="rapido-stem green"></div>
        <div class="rapido-dot-ring"><div class="rapido-dot-core green"></div></div>
      </div>
    `;
    const destPinHtml = `
      <div class="rapido-marker-container">
        <div class="rapido-tag red">Destination 🏁</div>
        <div class="rapido-stem red"></div>
        <div class="rapido-dot-ring"><div class="rapido-dot-core red"></div></div>
      </div>
    `;

    const startIcon = L.divIcon({
      className: '',
      html: startPinHtml,
      iconSize: [110, 42],
      iconAnchor: [55, 42]
    });

    const destIcon = L.divIcon({
      className: '',
      html: destPinHtml,
      iconSize: [100, 42],
      iconAnchor: [50, 42]
    });

    const map = L.map(mapContainerRef.current, {
      zoomControl: false,
      attributionControl: false
    }).setView([pickupCoords.lat, pickupCoords.lng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19
    }).addTo(map);

    const pMarker = L.marker([pickupCoords.lat, pickupCoords.lng], {
      icon: startIcon,
      draggable: true
    }).addTo(map);

    const dMarker = L.marker([dropCoords.lat, dropCoords.lng], {
      icon: destIcon,
      draggable: true
    }).addTo(map);

    pMarker.on('dragend', (e: any) => {
      const pos = e.target.getLatLng();
      onPickupChange({ lat: pos.lat, lng: pos.lng });
    });

    dMarker.on('dragend', (e: any) => {
      const pos = e.target.getLatLng();
      onDropChange({ lat: pos.lat, lng: pos.lng });
    });

    pickupMarkerRef.current = pMarker;
    dropMarkerRef.current = dMarker;
    mapInstanceRef.current = map;

    const resizeObserver = new ResizeObserver(() => {
      map.invalidateSize();
    });
    resizeObserver.observe(mapContainerRef.current);

    return () => {
      resizeObserver.disconnect();
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update pickup marker position if changed externally
  useEffect(() => {
    if (pickupMarkerRef.current) {
      const curr = pickupMarkerRef.current.getLatLng();
      if (Math.abs(curr.lat - pickupCoords.lat) > 0.0001 || Math.abs(curr.lng - pickupCoords.lng) > 0.0001) {
        pickupMarkerRef.current.setLatLng([pickupCoords.lat, pickupCoords.lng]);
      }
    }
  }, [pickupCoords]);

  // Update drop marker position if changed externally
  useEffect(() => {
    if (dropMarkerRef.current) {
      const curr = dropMarkerRef.current.getLatLng();
      if (Math.abs(curr.lat - dropCoords.lat) > 0.0001 || Math.abs(curr.lng - dropCoords.lng) > 0.0001) {
        dropMarkerRef.current.setLatLng([dropCoords.lat, dropCoords.lng]);
      }
    }
  }, [dropCoords]);

  // Handle resizing on tab change
  useEffect(() => {
    if (isActiveTab && mapInstanceRef.current) {
      setTimeout(() => {
        mapInstanceRef.current?.invalidateSize();
      }, 100);
    }
  }, [isActiveTab]);

  // Draw routes
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    // Clear old polylines
    polylinesRef.current.forEach((pl) => pl.remove());
    polylinesRef.current = [];

    const boundsGroup = L.featureGroup();
    if (pickupMarkerRef.current) boundsGroup.addLayer(pickupMarkerRef.current);
    if (dropMarkerRef.current) boundsGroup.addLayer(dropMarkerRef.current);

    if (altRoutes && altRoutes.length > 0) {
      altRoutes.forEach((route, idx) => {
        const isSelected = idx === selectedRouteIndex;
        const line = L.polyline(route, {
          color: isSelected ? '#1261ff' : '#94a3b8',
          weight: isSelected ? 6 : 4,
          opacity: isSelected ? 0.95 : 0.45
        }).addTo(map);

        line.on('click', () => {
          if (onSelectRouteIndex) onSelectRouteIndex(idx);
        });

        boundsGroup.addLayer(line);
        polylinesRef.current.push(line);
      });
    } else if (routeCoordinates && routeCoordinates.length > 0) {
      const line = L.polyline(routeCoordinates, {
        color: '#1261ff',
        weight: 5,
        opacity: 0.9
      }).addTo(map);
      boundsGroup.addLayer(line);
      polylinesRef.current.push(line);
    }

    if (boundsGroup.getLayers().length > 0) {
      try {
        map.fitBounds(boundsGroup.getBounds(), { padding: [40, 40], maxZoom: 15 });
      } catch {
        // Ignored
      }
    }
  }, [routeCoordinates, altRoutes, selectedRouteIndex]);

  return (
    <div className="absolute inset-0 bg-slate-200 z-0 overflow-hidden">
      <div ref={mapContainerRef} className="w-full h-full" id={mapId} />

      {/* Radar Mode Pill */}
      <button
        type="button"
        onClick={onToggleRadar}
        className={`absolute top-3 left-3 z-[400] text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-2 shadow-lg backdrop-blur-md border transition-all cursor-pointer select-none ${
          radarMode === 'local'
            ? 'bg-emerald-600/90 border-emerald-300'
            : 'bg-slate-900/85 border-white/20'
        }`}
      >
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span>
          {radarMode === 'local' ? '🛵 Local (2 KM)' : '🚗 Intercity (10 KM)'}
        </span>
      </button>

      {/* GPS Locate Button */}
      <button
        type="button"
        onClick={onTriggerGPS}
        title="Detect Live GPS"
        className="absolute bottom-1/2 translate-y-12 right-3.5 z-[400] bg-white border border-slate-200 rounded-full w-11 h-11 flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all text-blue-600"
      >
        <svg
          width="22"
          height="22"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#1261ff"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <line x1="22" y1="12" x2="18" y2="12" />
          <line x1="6" y1="12" x2="12" y2="12" />
          <line x1="12" y1="6" x2="12" y2="2" />
          <line x1="12" y1="22" x2="12" y2="18" />
        </svg>
      </button>
    </div>
  );
};
