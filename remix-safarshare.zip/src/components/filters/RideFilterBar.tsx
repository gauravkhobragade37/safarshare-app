import React, { useState } from 'react';

export type DateFilterOption = 'all' | 'today' | 'tomorrow' | 'custom';
export type TimeRangeOption = 'all' | 'morning' | 'afternoon' | 'evening' | 'custom';
export type VehicleFilterType = 'all' | 'Car' | 'Bike' | 'Truck' | 'Auto';
export type SortOption = 'departure' | 'fare' | 'eta';

export interface RideFiltersState {
  dateOption: DateFilterOption;
  customDate: string;
  timeRange: TimeRangeOption;
  customStartTime: string;
  customEndTime: string;
  vehicleType: VehicleFilterType;
  ladiesOnly: boolean;
  familySafe: boolean;
  sortBy: SortOption;
}

interface RideFilterBarProps {
  filters: RideFiltersState;
  onChange: (updated: RideFiltersState) => void;
  onReset: () => void;
  totalResultsCount: number;
}

export const RideFilterBar: React.FC<RideFilterBarProps> = ({
  filters,
  onChange,
  onReset,
  totalResultsCount
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Compute active filter count
  let activeCount = 0;
  if (filters.dateOption !== 'all') activeCount++;
  if (filters.timeRange !== 'all') activeCount++;
  if (filters.vehicleType !== 'all') activeCount++;
  if (filters.ladiesOnly) activeCount++;
  if (filters.familySafe) activeCount++;
  if (filters.sortBy !== 'departure') activeCount++;

  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  const update = (partial: Partial<RideFiltersState>) => {
    onChange({ ...filters, ...partial });
  };

  const getVehicleName = (type: VehicleFilterType) => {
    switch (type) {
      case 'Car':
        return '🚗 Car';
      case 'Bike':
        return '🏍️ Bike';
      case 'Truck':
        return '🛻 Truck';
      case 'Auto':
        return '🛺 Auto';
      default:
        return 'All Vehicles';
    }
  };

  const getTimeLabel = (range: TimeRangeOption) => {
    switch (range) {
      case 'morning':
        return '🌅 Morning (6-12)';
      case 'afternoon':
        return '☀️ Afternoon (12-5)';
      case 'evening':
        return '🌆 Evening (5-12)';
      case 'custom':
        return `⏱️ ${filters.customStartTime || '00:00'}-${filters.customEndTime || '23:59'}`;
      default:
        return 'All Day';
    }
  };

  const getDateLabel = (opt: DateFilterOption) => {
    switch (opt) {
      case 'today':
        return '📅 Today';
      case 'tomorrow':
        return '📅 Tomorrow';
      case 'custom':
        return `📅 ${filters.customDate || 'Date'}`;
      default:
        return 'All Dates';
    }
  };

  return (
    <div className="w-full bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden transition-all duration-200 mb-3">
      {/* Header / Quick Bar */}
      <div className="p-2.5 flex items-center justify-between gap-2 bg-slate-50/70">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {/* Main Expand/Collapse Toggle Button */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 ${
              isExpanded
                ? 'bg-blue-600 text-white shadow-xs'
                : activeCount > 0
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <span>⚡ Filters</span>
            {activeCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] font-black flex items-center justify-center">
                {activeCount}
              </span>
            )}
            <span className="text-[10px]">{isExpanded ? '▲' : '▼'}</span>
          </button>

          {/* Quick Active Chips */}
          {filters.vehicleType !== 'all' && (
            <span
              onClick={() => update({ vehicleType: 'all' })}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold shrink-0 cursor-pointer hover:bg-indigo-100"
              title="Click to remove"
            >
              {getVehicleName(filters.vehicleType)}
              <span className="text-slate-400 font-normal">✕</span>
            </span>
          )}

          {filters.dateOption !== 'all' && (
            <span
              onClick={() => update({ dateOption: 'all' })}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold shrink-0 cursor-pointer hover:bg-emerald-100"
              title="Click to remove"
            >
              {getDateLabel(filters.dateOption)}
              <span className="text-slate-400 font-normal">✕</span>
            </span>
          )}

          {filters.timeRange !== 'all' && (
            <span
              onClick={() => update({ timeRange: 'all' })}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-bold shrink-0 cursor-pointer hover:bg-amber-100"
              title="Click to remove"
            >
              {getTimeLabel(filters.timeRange)}
              <span className="text-slate-400 font-normal">✕</span>
            </span>
          )}

          {filters.ladiesOnly && (
            <span
              onClick={() => update({ ladiesOnly: false })}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-pink-50 border border-pink-200 text-pink-700 text-[11px] font-bold shrink-0 cursor-pointer hover:bg-pink-100"
            >
              🌸 Women Only ✕
            </span>
          )}
        </div>

        {/* Counter & Clear */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[11px] font-extrabold text-slate-500">
            {totalResultsCount} {totalResultsCount === 1 ? 'ride' : 'rides'}
          </span>
          {activeCount > 0 && (
            <button
              type="button"
              onClick={onReset}
              className="text-[10.5px] font-bold text-red-600 hover:text-red-700 underline cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Expanded Filter Panel */}
      {isExpanded && (
        <div className="p-3.5 border-t border-slate-100 space-y-3.5 bg-white animate-fadeIn">
          {/* 1. Date Filter Section */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-600 flex items-center gap-1">
                <span>📅 Departure Date</span>
              </label>
              {filters.dateOption !== 'all' && (
                <span className="text-[10px] text-emerald-700 font-bold">
                  {getDateLabel(filters.dateOption)}
                </span>
              )}
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              <button
                type="button"
                onClick={() => update({ dateOption: 'all' })}
                className={`py-1.5 text-xs font-extrabold rounded-xl border transition-all cursor-pointer ${
                  filters.dateOption === 'all'
                    ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                All Dates
              </button>

              <button
                type="button"
                onClick={() => update({ dateOption: 'today', customDate: todayStr })}
                className={`py-1.5 text-xs font-extrabold rounded-xl border transition-all cursor-pointer ${
                  filters.dateOption === 'today'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Today
              </button>

              <button
                type="button"
                onClick={() => update({ dateOption: 'tomorrow', customDate: tomorrowStr })}
                className={`py-1.5 text-xs font-extrabold rounded-xl border transition-all cursor-pointer ${
                  filters.dateOption === 'tomorrow'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Tomorrow
              </button>

              <label
                className={`relative flex items-center justify-center py-1.5 text-xs font-extrabold rounded-xl border transition-all cursor-pointer ${
                  filters.dateOption === 'custom'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>{filters.customDate ? filters.customDate.slice(5) : 'Pick'}</span>
                <input
                  type="date"
                  value={filters.customDate}
                  onChange={(e) => update({ dateOption: 'custom', customDate: e.target.value })}
                  className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* 2. Time Range Filter Section */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-600 flex items-center gap-1">
                <span>⏰ Departure Time Range</span>
              </label>
              {filters.timeRange !== 'all' && (
                <span className="text-[10px] text-blue-700 font-bold">
                  {getTimeLabel(filters.timeRange)}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              <button
                type="button"
                onClick={() => update({ timeRange: 'all' })}
                className={`py-1.5 px-2 text-xs font-extrabold rounded-xl border transition-all cursor-pointer text-center ${
                  filters.timeRange === 'all'
                    ? 'bg-slate-900 border-slate-900 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                All Day
              </button>

              <button
                type="button"
                onClick={() => update({ timeRange: 'morning' })}
                className={`py-1.5 px-2 text-xs font-extrabold rounded-xl border transition-all cursor-pointer text-center ${
                  filters.timeRange === 'morning'
                    ? 'bg-amber-500 border-amber-500 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                🌅 Morning (6-12)
              </button>

              <button
                type="button"
                onClick={() => update({ timeRange: 'afternoon' })}
                className={`py-1.5 px-2 text-xs font-extrabold rounded-xl border transition-all cursor-pointer text-center ${
                  filters.timeRange === 'afternoon'
                    ? 'bg-amber-500 border-amber-500 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                ☀️ Noon (12-5)
              </button>

              <button
                type="button"
                onClick={() => update({ timeRange: 'evening' })}
                className={`py-1.5 px-2 text-xs font-extrabold rounded-xl border transition-all cursor-pointer text-center ${
                  filters.timeRange === 'evening'
                    ? 'bg-amber-500 border-amber-500 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                🌆 Evening (5-12)
              </button>
            </div>

            {/* Custom Time Range Selector */}
            <div className="mt-2 flex items-center gap-2 pt-1">
              <span className="text-[10px] font-bold text-slate-400">Custom:</span>
              <div className="flex-1 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-2 py-1">
                <input
                  type="time"
                  value={filters.customStartTime}
                  onChange={(e) => update({ timeRange: 'custom', customStartTime: e.target.value })}
                  className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer"
                />
                <span className="text-slate-400 text-xs font-bold">to</span>
                <input
                  type="time"
                  value={filters.customEndTime}
                  onChange={(e) => update({ timeRange: 'custom', customEndTime: e.target.value })}
                  className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* 3. Vehicle Type Filter Section */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-600 flex items-center gap-1">
                <span>🚘 Vehicle Type</span>
              </label>
              {filters.vehicleType !== 'all' && (
                <span className="text-[10px] text-indigo-700 font-bold">
                  {getVehicleName(filters.vehicleType)}
                </span>
              )}
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              <button
                type="button"
                onClick={() => update({ vehicleType: 'all' })}
                className={`py-2 px-1 text-[11px] font-extrabold rounded-xl border transition-all cursor-pointer text-center ${
                  filters.vehicleType === 'all'
                    ? 'bg-slate-900 border-slate-900 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                All
              </button>

              <button
                type="button"
                onClick={() => update({ vehicleType: 'Car' })}
                className={`py-2 px-1 text-[11px] font-extrabold rounded-xl border transition-all cursor-pointer text-center flex flex-col items-center gap-0.5 ${
                  filters.vehicleType === 'Car'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className="text-sm">🚗</span>
                <span>Car</span>
              </button>

              <button
                type="button"
                onClick={() => update({ vehicleType: 'Bike' })}
                className={`py-2 px-1 text-[11px] font-extrabold rounded-xl border transition-all cursor-pointer text-center flex flex-col items-center gap-0.5 ${
                  filters.vehicleType === 'Bike'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className="text-sm">🏍️</span>
                <span>Bike</span>
              </button>

              <button
                type="button"
                onClick={() => update({ vehicleType: 'Truck' })}
                className={`py-2 px-1 text-[11px] font-extrabold rounded-xl border transition-all cursor-pointer text-center flex flex-col items-center gap-0.5 ${
                  filters.vehicleType === 'Truck'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className="text-sm">🛻</span>
                <span>Truck</span>
              </button>

              <button
                type="button"
                onClick={() => update({ vehicleType: 'Auto' })}
                className={`py-2 px-1 text-[11px] font-extrabold rounded-xl border transition-all cursor-pointer text-center flex flex-col items-center gap-0.5 ${
                  filters.vehicleType === 'Auto'
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className="text-sm">🛺</span>
                <span>Auto</span>
              </button>
            </div>
          </div>

          {/* 4. Sort and Extra Preferences */}
          <div className="pt-1 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100">
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-600">
              <span>Sort:</span>
              <select
                value={filters.sortBy}
                onChange={(e) => update({ sortBy: e.target.value as SortOption })}
                className="bg-slate-100 border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 outline-none cursor-pointer"
              >
                <option value="departure">⏰ Earliest Departure</option>
                <option value="fare">💰 Lowest Fare</option>
                <option value="eta">🏁 Fastest ETA</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1 text-xs font-bold text-pink-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={filters.ladiesOnly}
                  onChange={(e) => update({ ladiesOnly: e.target.checked })}
                  className="rounded text-pink-600"
                />
                <span>🌸 Women Only</span>
              </label>

              <label className="flex items-center gap-1 text-xs font-bold text-purple-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={filters.familySafe}
                  onChange={(e) => update({ familySafe: e.target.checked })}
                  className="rounded text-purple-600"
                />
                <span>👨‍👩‍👧 Family</span>
              </label>
            </div>
          </div>

          {/* Collapse Footer Button */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setIsExpanded(false)}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs rounded-xl transition-all cursor-pointer text-center"
            >
              Done Filtering ({totalResultsCount} Available)
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
