import React from 'react';

export interface ToastMessage {
  id: string;
  text: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onRemove: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onRemove }) => {
  return (
    <div
      id="toast-container"
      className="fixed top-3 left-1/2 -translate-x-1/2 z-[99999] flex flex-col gap-2 w-[90%] max-w-sm pointer-events-none"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xl flex items-center justify-between border-l-4 border-blue-600 pointer-events-auto transition-all animate-in fade-in slide-in-from-top-2"
        >
          <span>{toast.text}</span>
          <button
            onClick={() => onRemove(toast.id)}
            className="ml-3 text-slate-400 hover:text-white text-sm"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
};
