import React from 'react';

export type TabType = 'rides' | 'parcel' | 'post' | 'activity' | 'profile';

interface NavigationProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  pendingCount?: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  pendingCount = 0
}) => {
  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: 'rides', label: 'Rides', icon: '🛵' },
    { id: 'parcel', label: 'Parcel', icon: '📦' },
    { id: 'post', label: 'Post', icon: '🚗' },
    { id: 'activity', label: 'Activity', icon: '📋' },
    { id: 'profile', label: 'Profile', icon: '👤' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-[66px] bg-white/98 backdrop-blur-md flex justify-around items-center border-t border-slate-200 z-[1000] shadow-lg max-w-4xl mx-auto">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className={`flex flex-col items-center justify-center flex-1 h-full cursor-pointer relative transition-all ${
              isActive ? 'text-blue-600 font-extrabold scale-105' : 'text-slate-500 font-bold hover:text-slate-700'
            }`}
          >
            <span className="text-xl mb-0.5">{tab.icon}</span>
            <span className="text-[11px] tracking-tight">{tab.label}</span>
            {tab.id === 'activity' && pendingCount > 0 && (
              <span className="absolute top-2 right-1/4 bg-amber-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {pendingCount}
              </span>
            )}
            {isActive && (
              <span className="absolute bottom-1 w-6 h-1 bg-blue-600 rounded-full" />
            )}
          </button>
        );
      })}
    </nav>
  );
};
