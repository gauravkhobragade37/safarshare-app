import React from 'react';
import { calculateETA, getTripProgress } from '../../utils/tripProgress';

interface TripProgressBarProps {
  from: string;
  to: string;
  date?: string;
  time?: string;
  vehicle?: string;
  routeDistanceKm?: number;
  routeDurationMin?: number;
  tripStarted?: boolean;
  startedAt?: number;
  compact?: boolean;
  className?: string;
}

export const TripProgressBar: React.FC<TripProgressBarProps> = ({
  from,
  to,
  date,
  time,
  vehicle = 'Car',
  routeDistanceKm,
  routeDurationMin,
  tripStarted = false,
  startedAt,
  compact = false,
  className = ''
}) => {
  const tripInfo = getTripProgress(date, time, routeDurationMin, routeDistanceKm, tripStarted, startedAt);
  const { eta, progressPercent, statusText, isLive } = tripInfo;

  const getVehicleEmoji = (type?: string) => {
    const lower = (type || '').toLowerCase();
    if (lower.includes('bike') || lower.includes('motorcycle')) return '🏍️';
    if (lower.includes('truck') || lower.includes('pickup')) return '🛻';
    if (lower.includes('auto') || lower.includes('rickshaw')) return '🛺';
    return '🚗';
  };

  const emoji = getVehicleEmoji(vehicle);

  // Clean location names for display
  const cleanShort = (addr: string) => {
    if (!addr) return '';
    return addr.split(',')[0].trim();
  };

  if (compact) {
    return (
      <div className={`w-full bg-slate-50/80 rounded-xl p-2.5 border border-slate-200/80 ${className}`}>
        <div className="flex items-center justify-between text-[11px] mb-1.5">
          <div className="flex items-center gap-1 font-bold text-slate-700">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
            <span className="truncate max-w-[120px]">{cleanShort(from)}</span>
            <span className="text-slate-400 font-normal">({eta.departureTime12})</span>
          </div>

          <div className="flex items-center gap-1 font-bold text-slate-900">
            <span className="text-blue-600">🏁 ETA {eta.arrivalTime12}</span>
            <span className="w-2 h-2 rounded-sm bg-red-500 shrink-0" />
          </div>
        </div>

        {/* Progress Bar Track */}
        <div className="relative h-2 w-full bg-slate-200 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              isLive ? 'bg-gradient-to-r from-emerald-500 via-blue-500 to-indigo-600 animate-pulse' : 'bg-gradient-to-r from-emerald-400 to-blue-500'
            }`}
            style={{ width: `${Math.max(12, Math.min(100, progressPercent > 0 ? progressPercent : 15))}%` }}
          />
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-500 mt-1 font-semibold">
          <span>{routeDistanceKm ? `${routeDistanceKm} km` : 'Direct Route'}</span>
          <span className="text-emerald-700 font-bold">~{eta.durationFormatted} travel</span>
          <span className="truncate max-w-[120px] text-right">{cleanShort(to)}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`w-full bg-gradient-to-b from-slate-50 to-blue-50/30 rounded-2xl p-3 border border-slate-200 shadow-xs ${className}`}>
      {/* Header Info: Distance, ETA, Status */}
      <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-200/60">
        <div className="flex items-center gap-1.5">
          <span className="text-xs">{emoji}</span>
          <span className="text-[11px] font-bold text-slate-700">
            {routeDistanceKm ? `${routeDistanceKm} km corridor` : 'Highway Route'}
          </span>
          <span className="text-slate-300">•</span>
          <span className="text-[11px] font-extrabold text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded-md">
            ~{eta.durationFormatted}
          </span>
        </div>

        {/* ETA Badge */}
        <div className="flex items-center gap-1 bg-emerald-100/80 border border-emerald-300/80 px-2 py-0.5 rounded-lg">
          <span className="text-[10px]">🏁</span>
          <span className="text-[10px] font-black text-emerald-900 tracking-tight">
            ETA {eta.arrivalTime12}
          </span>
          {eta.isNextDay && (
            <span className="text-[8px] bg-amber-500 text-white font-bold px-1 rounded">
              +1d
            </span>
          )}
        </div>
      </div>

      {/* Progress Track with Moving Indicator */}
      <div className="relative my-3 mx-1">
        {/* Background Bar */}
        <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              isLive
                ? 'bg-gradient-to-r from-emerald-500 via-sky-500 to-blue-600 animate-pulse'
                : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-blue-500'
            }`}
            style={{ width: `${Math.max(8, Math.min(100, progressPercent > 0 ? progressPercent : 20))}%` }}
          />
        </div>

        {/* Start Point Marker */}
        <div className="absolute -top-1 left-0 transform -translate-x-1/2 flex flex-col items-center">
          <div className="w-4 h-4 rounded-full bg-emerald-500 border-2 border-white shadow-sm flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-white" />
          </div>
        </div>

        {/* Vehicle Position Node on Track */}
        <div
          className="absolute -top-2.5 transform -translate-x-1/2 transition-all duration-700"
          style={{ left: `${Math.max(10, Math.min(90, progressPercent > 0 ? progressPercent : 28))}%` }}
        >
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-white border border-blue-400 shadow-md text-xs select-none">
            {emoji}
          </div>
        </div>

        {/* End Point Marker */}
        <div className="absolute -top-1 right-0 transform translate-x-1/2 flex flex-col items-center">
          <div className="w-4 h-4 rounded-full bg-red-500 border-2 border-white shadow-sm flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-sm bg-white" />
          </div>
        </div>
      </div>

      {/* Origin & Destination Labels */}
      <div className="flex justify-between items-start text-xs pt-1">
        {/* Origin */}
        <div className="max-w-[45%]">
          <div className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-700">
            Depart {eta.departureTime12}
          </div>
          <div className="font-extrabold text-slate-800 text-[11.5px] truncate" title={from}>
            {cleanShort(from)}
          </div>
        </div>

        {/* Live Trip Phase / Tag */}
        <div className="text-center px-1">
          {isLive ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] font-black bg-emerald-500 text-white shadow-xs animate-bounce">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
              Live {progressPercent}%
            </span>
          ) : (
            <span className="text-[9.5px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
              {statusText}
            </span>
          )}
        </div>

        {/* Destination */}
        <div className="max-w-[45%] text-right">
          <div className="text-[10px] uppercase tracking-wider font-extrabold text-blue-700">
            Arrive ~{eta.arrivalTime12}
          </div>
          <div className="font-extrabold text-slate-800 text-[11.5px] truncate" title={to}>
            {cleanShort(to)}
          </div>
        </div>
      </div>
    </div>
  );
};
