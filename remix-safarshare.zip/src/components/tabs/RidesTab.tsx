import React, { useState, useEffect, useMemo } from 'react';
import { MapView } from '../MapView';
import { RideTrip, BookingRequest, SponsoredAd, UserProfile } from '../../types';
import {
  autocompletePlaces,
  reverseGeocode,
  cleanLocation,
  format12Hour,
  checkCorridorMatch,
  fetchRoutesBetweenPoints
} from '../../utils/geo';
import { LuggageModal, VehicleFilterModal, SeatsModal, BookingPaymentModal } from '../modals/AppModals';
import { TripProgressBar } from '../common/TripProgressBar';
import { RideFilterBar, RideFiltersState } from '../filters/RideFilterBar';
import { calculateETA } from '../../utils/tripProgress';

interface RidesTabProps {
  currentUser: UserProfile | null;
  rides: RideTrip[];
  sponsoredAds: SponsoredAd[];
  isActive: boolean;
  onBookRide: (ride: RideTrip, fare: number, travelKm: number, paymentMode: 'cash_pickup' | 'driver_qr') => Promise<void>;
  onOfferFare: (ride: RideTrip, offerPrice: number, travelKm: number) => void;
  onShowToast: (msg: string) => void;
  onRequestLogin: () => void;
}

export const RidesTab: React.FC<RidesTabProps> = ({
  currentUser,
  rides,
  sponsoredAds,
  isActive,
  onBookRide,
  onOfferFare,
  onShowToast,
  onRequestLogin
}) => {
  const [pickup, setPickup] = useState({ lat: 21.4588, lng: 80.1961, text: '' });
  const [drop, setDrop] = useState({ lat: 21.5588, lng: 80.3961, text: '' });
  const [radarMode, setRadarMode] = useState<'intercity' | 'local'>('intercity');
  const [snapState, setSnapState] = useState<'collapsed' | 'half' | 'expanded'>('half');

  const [fromQuery, setFromQuery] = useState('');
  const [toQuery, setToQuery] = useState('');
  const [fromSuggestions, setFromSuggestions] = useState<any[]>([]);
  const [toSuggestions, setToSuggestions] = useState<any[]>([]);

  const [isLadiesOnly, setIsLadiesOnly] = useState(false);
  const [extraBags, setExtraBags] = useState(0);
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [seatCount, setSeatCount] = useState(1);
  const [dateTime, setDateTime] = useState('');

  // Enhanced Filter Component State
  const [filters, setFilters] = useState<RideFiltersState>({
    dateOption: 'all',
    customDate: '',
    timeRange: 'all',
    customStartTime: '08:00',
    customEndTime: '20:00',
    vehicleType: 'all',
    ladiesOnly: false,
    familySafe: false,
    sortBy: 'departure'
  });

  // Modals
  const [isBagModalOpen, setIsBagModalOpen] = useState(false);
  const [isVehModalOpen, setIsVehModalOpen] = useState(false);
  const [isSeatsModalOpen, setIsSeatsModalOpen] = useState(false);
  const [pendingBookingRide, setPendingBookingRide] = useState<{ ride: RideTrip; fare: number; travelKm: number } | null>(null);

  const [searchResults, setSearchResults] = useState<Array<RideTrip & { travelKm: number; calculatedFare: number }>>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);

  // Filter Match Helper
  const matchesRideFilters = (ride: RideTrip, currentFilters: RideFiltersState): boolean => {
    // 1. Vehicle Type (car / bike / truck / auto)
    if (currentFilters.vehicleType !== 'all') {
      const v = (ride.vehicle || '').toLowerCase();
      const m = (ride.carModel || '').toLowerCase();
      if (currentFilters.vehicleType === 'Car') {
        const isCar =
          v.includes('car') ||
          v.includes('sedan') ||
          v.includes('hatchback') ||
          v.includes('suv') ||
          (!v.includes('bike') && !v.includes('truck') && !v.includes('pickup') && !v.includes('auto'));
        if (!isCar) return false;
      } else if (currentFilters.vehicleType === 'Bike') {
        const isBike = v.includes('bike') || v.includes('motorcycle') || v.includes('scooter') || m.includes('bike');
        if (!isBike) return false;
      } else if (currentFilters.vehicleType === 'Truck') {
        const isTruck =
          v.includes('truck') ||
          v.includes('pickup') ||
          v.includes('carrier') ||
          m.includes('truck') ||
          m.includes('pickup');
        if (!isTruck) return false;
      } else if (currentFilters.vehicleType === 'Auto') {
        const isAuto = v.includes('auto') || v.includes('rickshaw');
        if (!isAuto) return false;
      }
    }

    // 2. Date Filter (all / today / tomorrow / custom)
    if (currentFilters.dateOption !== 'all') {
      const todayStr = new Date().toISOString().split('T')[0];
      const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      const targetDate =
        currentFilters.dateOption === 'today'
          ? todayStr
          : currentFilters.dateOption === 'tomorrow'
          ? tomorrowStr
          : currentFilters.customDate;
      if (targetDate && ride.date && ride.date !== targetDate) {
        return false;
      }
    }

    // 3. Time Range Filter (all / morning / afternoon / evening / custom)
    if (currentFilters.timeRange !== 'all') {
      const rideTime = ride.time || '12:00';
      const [h, m] = rideTime.split(':').map((x) => parseInt(x, 10) || 0);
      const timeMinutes = h * 60 + m;

      if (currentFilters.timeRange === 'morning') {
        // 06:00 to 11:59
        if (timeMinutes < 6 * 60 || timeMinutes >= 12 * 60) return false;
      } else if (currentFilters.timeRange === 'afternoon') {
        // 12:00 to 16:59
        if (timeMinutes < 12 * 60 || timeMinutes >= 17 * 60) return false;
      } else if (currentFilters.timeRange === 'evening') {
        // 17:00 to 23:59
        if (timeMinutes < 17 * 60) return false;
      } else if (currentFilters.timeRange === 'custom') {
        if (currentFilters.customStartTime) {
          const [sh, sm] = currentFilters.customStartTime.split(':').map((x) => parseInt(x, 10) || 0);
          if (timeMinutes < sh * 60 + sm) return false;
        }
        if (currentFilters.customEndTime) {
          const [eh, em] = currentFilters.customEndTime.split(':').map((x) => parseInt(x, 10) || 0);
          if (timeMinutes > eh * 60 + em) return false;
        }
      }
    }

    // 4. Ladies Only
    if (currentFilters.ladiesOnly && !ride.isLadiesOnly && !ride.isFamilyOnBoard) {
      return false;
    }

    // 5. Family Safe
    if (currentFilters.familySafe && !ride.isFamilyOnBoard) {
      return false;
    }

    return true;
  };

  const handleVehicleSelect = (veh: string) => {
    setSelectedVehicle(veh);
    let vType: 'all' | 'Car' | 'Bike' | 'Truck' | 'Auto' = 'all';
    if (veh === 'Bike') vType = 'Bike';
    else if (veh === 'Car') vType = 'Car';
    else if (veh === 'Pickup/Truck' || veh === 'Truck') vType = 'Truck';
    else if (veh === 'Auto') vType = 'Auto';
    setFilters((f) => ({ ...f, vehicleType: vType }));
  };

  const handleFiltersChange = (newFilters: RideFiltersState) => {
    setFilters(newFilters);
    if (newFilters.vehicleType === 'all') setSelectedVehicle('');
    else if (newFilters.vehicleType === 'Truck') setSelectedVehicle('Pickup/Truck');
    else setSelectedVehicle(newFilters.vehicleType);
    setIsLadiesOnly(newFilters.ladiesOnly);
  };

  const handleResetFilters = () => {
    setFilters({
      dateOption: 'all',
      customDate: '',
      timeRange: 'all',
      customStartTime: '08:00',
      customEndTime: '20:00',
      vehicleType: 'all',
      ladiesOnly: false,
      familySafe: false,
      sortBy: 'departure'
    });
    setSelectedVehicle('');
    setIsLadiesOnly(false);
  };

  // Filtered & Sorted rides to display
  const displayedRides = useMemo(() => {
    let list: Array<RideTrip & { travelKm: number; calculatedFare: number }> = [];

    if (hasSearched) {
      list = searchResults.filter((ride) => matchesRideFilters(ride, filters));
    } else {
      // Show available platform rides when not searching
      list = rides
        .filter((r) => {
          if (r.status !== 'Active') return false;
          if (currentUser && r.driverUid === currentUser.uid) return false;
          if (!r.passenger || (r.seats || 0) < seatCount) return false;
          return matchesRideFilters(r, filters);
        })
        .map((r) => ({
          ...r,
          travelKm: r.routeDistanceKm || 15,
          calculatedFare: r.seatPrice || r.fare || 120
        }));
    }

    // Sort rides
    return [...list].sort((a, b) => {
      if (filters.sortBy === 'fare') {
        return a.calculatedFare - b.calculatedFare;
      }
      if (filters.sortBy === 'eta') {
        const etaA = calculateETA(a.date, a.time, a.routeDurationMin, a.travelKm);
        const etaB = calculateETA(b.date, b.time, b.routeDurationMin, b.travelKm);
        return etaA.durationMinutes - etaB.durationMinutes;
      }
      // 'departure'
      const dateComp = (a.date || '').localeCompare(b.date || '');
      if (dateComp !== 0) return dateComp;
      return (a.time || '').localeCompare(b.time || '');
    });
  }, [hasSearched, searchResults, rides, currentUser, seatCount, filters]);

  // Initial geocoding
  useEffect(() => {
    reverseGeocode(pickup.lat, pickup.lng).then((addr) => {
      setPickup((p) => ({ ...p, text: addr }));
      setFromQuery(addr);
    });
    reverseGeocode(drop.lat, drop.lng).then((addr) => {
      setDrop((d) => ({ ...d, text: addr }));
      setToQuery(addr);
    });
  }, []);

  // Update route polyline when coordinates change
  useEffect(() => {
    fetchRoutesBetweenPoints(pickup, drop).then((routes) => {
      if (routes && routes.length > 0) {
        setRouteCoordinates(routes[0].coordinates);
      }
    });
  }, [pickup.lat, pickup.lng, drop.lat, drop.lng]);

  const handleGPS = () => {
    if (!navigator.geolocation) {
      onShowToast('GPS not supported on this browser');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const addr = await reverseGeocode(lat, lng);
        setPickup({ lat, lng, text: addr });
        setFromQuery(addr);
        onShowToast('📍 Current Live GPS Position Set!');
      },
      () => onShowToast('GPS access denied or unavailable'),
      { enableHighAccuracy: true }
    );
  };

  const handleSwap = () => {
    const tempP = { ...pickup };
    const tempQ = fromQuery;
    setPickup(drop);
    setFromQuery(toQuery);
    setDrop(tempP);
    setToQuery(tempQ);
    onShowToast('🔄 Pickup and Destination Swapped!');
  };

  const searchFromLocation = async (txt: string) => {
    setFromQuery(txt);
    if (txt.trim().length >= 2) {
      const list = await autocompletePlaces(txt);
      setFromSuggestions(list);
    } else {
      setFromSuggestions([]);
    }
  };

  const searchToLocation = async (txt: string) => {
    setToQuery(txt);
    if (txt.trim().length >= 2) {
      const list = await autocompletePlaces(txt);
      setToSuggestions(list);
    } else {
      setToSuggestions([]);
    }
  };

  const handleFindRides = async () => {
    if (!fromQuery.trim() || !toQuery.trim()) {
      onShowToast('❌ Please enter Pickup and Destination areas');
      return;
    }

    setIsSearching(true);
    setHasSearched(true);
    setSnapState('expanded');

    const maxCorridorKm = radarMode === 'local' ? 2.0 : 10.0;
    const fromText = fromQuery.toLowerCase().split(',')[0].trim();
    const toText = toQuery.toLowerCase().split(',')[0].trim();

    const candidates = rides.filter((r) => {
      if (r.status !== 'Active') return false;
      if (currentUser && r.driverUid === currentUser.uid) return false;
      if (!r.passenger || (r.seats || 0) < seatCount) return false;
      if (selectedVehicle && r.vehicle !== selectedVehicle && r.carModel !== selectedVehicle) return false;
      if (isLadiesOnly && !r.isLadiesOnly && !r.isFamilyOnBoard) return false;
      return true;
    });

    const matched: Array<RideTrip & { travelKm: number; calculatedFare: number }> = [];

    candidates.forEach((trip) => {
      let match = false;
      let travelKm = 10;
      let calculatedFare = trip.seatPrice || trip.fare || 150;

      if (trip.geometry) {
        const res = checkCorridorMatch(pickup, drop, trip.geometry, maxCorridorKm);
        if (res.isMatch) {
          match = true;
          travelKm = res.travelKm;
          if (trip.seatPrice && trip.routeDistanceKm) {
            const perKm = trip.seatPrice / trip.routeDistanceKm;
            calculatedFare = Math.max(30, Math.round((travelKm * perKm) / 5) * 5);
          } else {
            calculatedFare = Math.max(30, Math.round((travelKm * 2.5) / 5) * 5);
          }
        }
      }

      // Fallback text match
      if (!match) {
        const tripFrom = (trip.from || '').toLowerCase();
        const tripTo = (trip.to || '').toLowerCase();
        if (tripFrom.includes(fromText) && tripTo.includes(toText)) {
          match = true;
          calculatedFare = trip.seatPrice || 150;
        }
      }

      if (match) {
        matched.push({ ...trip, travelKm, calculatedFare });
      }
    });

    setTimeout(() => {
      setSearchResults(matched);
      setIsSearching(false);
    }, 250);
  };

  const getVehicleLabel = () => {
    if (selectedVehicle === 'Bike') return '🏍️ Bike';
    if (selectedVehicle === 'Auto') return '🛺 Auto';
    if (selectedVehicle === 'Car') return '🚗 Car';
    if (selectedVehicle === 'Pickup/Truck') return '🛻 Pickup';
    return '🚗 Any';
  };

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Map View */}
      <MapView
        mapId="rideMap"
        pickupCoords={pickup}
        dropCoords={drop}
        onPickupChange={(coords) => {
          setPickup((p) => ({ ...p, ...coords }));
          reverseGeocode(coords.lat, coords.lng).then((addr) => {
            setPickup((p) => ({ ...p, text: addr }));
            setFromQuery(addr);
          });
        }}
        onDropChange={(coords) => {
          setDrop((d) => ({ ...d, ...coords }));
          reverseGeocode(coords.lat, coords.lng).then((addr) => {
            setDrop((d) => ({ ...d, text: addr }));
            setToQuery(addr);
          });
        }}
        routeCoordinates={routeCoordinates}
        radarMode={radarMode}
        onToggleRadar={() => {
          setRadarMode((m) => (m === 'intercity' ? 'local' : 'intercity'));
          onShowToast(
            `Radar mode: ${radarMode === 'intercity' ? '🛵 Local (2 KM Corridor)' : '🚗 Intercity (10 KM Corridor)'}`
          );
        }}
        onTriggerGPS={handleGPS}
        isActiveTab={isActive}
      />

      {/* 3-Snap Draggable Bottom Sheet */}
      <div
        className={`absolute left-0 right-0 bottom-0 bg-white rounded-t-3xl shadow-2xl z-[500] flex flex-col transition-all duration-300 ${
          snapState === 'collapsed'
            ? 'h-[16%]'
            : snapState === 'expanded'
            ? 'h-[88%]'
            : 'h-[54%]'
        }`}
      >
        {/* Drag Handle Bar */}
        <div
          onClick={() => {
            setSnapState((s) => (s === 'collapsed' ? 'half' : s === 'half' ? 'expanded' : 'half'));
          }}
          className="w-full py-2.5 flex justify-center items-center cursor-pointer select-none"
        >
          <div className="w-11 h-1 bg-slate-300 rounded-full" />
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 px-4 pb-20 overflow-y-auto no-scrollbar">
          {/* Pickup Input */}
          <div className="relative mb-2">
            <div className="flex items-center gap-1.5 bg-slate-100 focus-within:bg-white border focus-within:border-blue-500 rounded-xl px-2.5 py-2 transition-all">
              <span className="text-emerald-600 text-xs">●</span>
              <input
                type="text"
                value={fromQuery}
                onChange={(e) => searchFromLocation(e.target.value)}
                placeholder="Pickup Area (GPS Enabled)"
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
              {fromQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setFromQuery('');
                    setFromSuggestions([]);
                  }}
                  className="text-slate-400 hover:text-slate-600 text-xs px-1"
                >
                  ✕
                </button>
              )}
              <button
                type="button"
                onClick={() => setSnapState('collapsed')}
                className="text-[10px] font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 px-2 py-1 rounded-md shrink-0 cursor-pointer"
              >
                📍 Map
              </button>
            </div>

            {/* Suggestions dropdown */}
            {fromSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl mt-1 z-50 overflow-hidden">
                {fromSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setPickup({ lat: item.lat, lng: item.lon, text: item.cleanName });
                      setFromQuery(item.cleanName);
                      setFromSuggestions([]);
                    }}
                    className="p-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
                  >
                    📍 {item.cleanName}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Swap & Destination Row */}
          <div className="flex items-center gap-1.5 mb-2 relative">
            <div className="flex-1 flex items-center gap-1.5 bg-slate-100 focus-within:bg-white border focus-within:border-blue-500 rounded-xl px-2.5 py-2 transition-all">
              <span className="text-red-500 text-xs">◼</span>
              <input
                type="text"
                value={toQuery}
                onChange={(e) => searchToLocation(e.target.value)}
                placeholder="Where are you going?"
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
              {toQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setToQuery('');
                    setToSuggestions([]);
                  }}
                  className="text-slate-400 hover:text-slate-600 text-xs px-1"
                >
                  ✕
                </button>
              )}
              <button
                type="button"
                onClick={() => setSnapState('collapsed')}
                className="text-[10px] font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 px-2 py-1 rounded-md shrink-0 cursor-pointer"
              >
                📍 Map
              </button>
            </div>

            <button
              type="button"
              onClick={handleSwap}
              title="Swap From & To"
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0 transition-transform active:rotate-180 cursor-pointer"
            >
              ⇄
            </button>

            {/* Ladies Toggle */}
            <button
              type="button"
              onClick={() => setIsLadiesOnly(!isLadiesOnly)}
              className={`flex flex-col items-center justify-center w-12 h-10 rounded-xl border text-[9.5px] font-black shrink-0 transition-all cursor-pointer ${
                isLadiesOnly
                  ? 'bg-pink-50 border-pink-400 text-pink-600 shadow-sm shadow-pink-200'
                  : 'bg-slate-50 border-slate-200 text-pink-700 hover:bg-pink-50/50'
              }`}
            >
              <span>🌸</span>
              <span>Ladies</span>
            </button>

            {/* Bag Toggle */}
            <button
              type="button"
              onClick={() => setIsBagModalOpen(true)}
              className={`flex flex-col items-center justify-center w-12 h-10 rounded-xl border text-[9.5px] font-black shrink-0 transition-all cursor-pointer ${
                extraBags > 0
                  ? 'bg-emerald-50 border-emerald-400 text-emerald-700 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span>🧳</span>
              <span>{extraBags > 0 ? `${extraBags} Bag` : '+Bag'}</span>
            </button>

            {/* Destination suggestions */}
            {toSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl mt-1 z-50 overflow-hidden">
                {toSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setDrop({ lat: item.lat, lng: item.lon, text: item.cleanName });
                      setToQuery(item.cleanName);
                      setToSuggestions([]);
                    }}
                    className="p-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
                  >
                    📍 {item.cleanName}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Chips Grid */}
          <div className="grid grid-cols-3 gap-1.5 mb-3">
            {/* DateTime Chip */}
            <label className="relative flex items-center justify-center gap-1 py-2 px-1 bg-slate-900 text-white rounded-xl text-[11px] font-bold cursor-pointer select-none">
              <span>📅</span>
              <span className="truncate">
                {dateTime ? dateTime.replace('T', ' ') : 'Today, Now'}
              </span>
              <input
                type="datetime-local"
                value={dateTime}
                onChange={(e) => setDateTime(e.target.value)}
                className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
              />
            </label>

            {/* Vehicle Filter Chip */}
            <button
              type="button"
              onClick={() => setIsVehModalOpen(true)}
              className="py-2 px-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold border border-slate-200 truncate cursor-pointer"
            >
              {getVehicleLabel()}
            </button>

            {/* Seats Filter Chip */}
            <button
              type="button"
              onClick={() => setIsSeatsModalOpen(true)}
              className="py-2 px-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold border border-slate-200 truncate cursor-pointer"
            >
              👥 {seatCount} {seatCount === 1 ? 'Seat' : 'Seats'}
            </button>
          </div>

          {/* Find Button */}
          <button
            type="button"
            onClick={handleFindRides}
            disabled={isSearching}
            className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-600 text-white rounded-xl font-extrabold text-sm shadow-md shadow-blue-600/20 hover:opacity-95 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {isSearching ? (
              <span>⏳ Scanning {radarMode === 'local' ? '2 KM' : '10 KM'} Corridor...</span>
            ) : (
              <span>Find Available Rides →</span>
            )}
          </button>

          {/* Ride Filter Component (Filter by Date, Time Range, Vehicle Type) */}
          <div className="mt-3">
            <RideFilterBar
              filters={filters}
              onChange={handleFiltersChange}
              onReset={handleResetFilters}
              totalResultsCount={displayedRides.length}
            />
          </div>

          {/* Results List */}
          <div className="space-y-3">
            {/* Context Heading */}
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <span>{hasSearched ? '📍 Corridor Matching Rides' : '🚗 Available Rides on Platform'}</span>
                <span className="text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.2 rounded-full">
                  {displayedRides.length}
                </span>
              </span>
              <span className="text-[10px] text-slate-400 font-semibold">
                Sorted by {filters.sortBy}
              </span>
            </div>

            {displayedRides.length === 0 && !isSearching && (
              <div className="text-center py-8 px-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="text-3xl mb-2">🚗</div>
                <h4 className="text-sm font-extrabold text-slate-800 mb-1">
                  {hasSearched ? 'No Matching Rides Found' : 'No Rides Match Selected Filters'}
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mb-3">
                  {hasSearched
                    ? `No active driver along this ${radarMode === 'local' ? '2 KM' : '10 KM'} corridor matches your current filters.`
                    : 'Try changing your vehicle type, expanding your time range, or clearing date filters.'}
                </p>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="py-2 px-4 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-extrabold rounded-xl transition-all cursor-pointer"
                >
                  🔄 Reset All Filters
                </button>
              </div>
            )}

            {displayedRides.map((ride) => {
              const eta = calculateETA(ride.date, ride.time, ride.routeDurationMin, ride.travelKm);

              return (
                <div
                  key={ride.id}
                  className="p-3.5 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-2.5 hover:border-blue-300 transition-all"
                >
                  {/* Driver & Vehicle Header */}
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={ride.driverDp || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'}
                        alt={ride.driverName}
                        className="w-10 h-10 rounded-full object-cover border-2 border-blue-600 shrink-0"
                      />
                      <div>
                        <div className="text-xs font-black text-slate-900 flex items-center gap-1">
                          <span>{ride.driverName}</span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                            ✓ Verified
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-semibold">
                          {ride.carModel || ride.vehicle} ({ride.carNumber || 'Verified'})
                        </div>
                      </div>
                    </div>

                    <div className="text-right flex flex-col items-end">
                      <div className="text-base font-black text-emerald-600">
                        ₹{ride.calculatedFare}
                      </div>
                      <div className="text-[9.5px] text-slate-400 font-bold">
                        per seat
                      </div>
                      {/* Prominent Estimated Arrival Time Badge */}
                      <div className="mt-1 flex items-center gap-1 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md text-[10px] font-black text-blue-800">
                        <span>🏁 ETA</span>
                        <span>{eta.arrivalTime12}</span>
                      </div>
                    </div>
                  </div>

                  {/* Trip Progressive Bar */}
                  <TripProgressBar
                    from={cleanLocation(ride.from)}
                    to={cleanLocation(ride.to)}
                    date={ride.date}
                    time={ride.time}
                    vehicle={ride.vehicle}
                    routeDistanceKm={ride.travelKm || ride.routeDistanceKm}
                    routeDurationMin={ride.routeDurationMin}
                    tripStarted={ride.tripStarted}
                  />

                  {/* Pickup Spot Details if available */}
                  {ride.pickupSpot && (
                    <div className="text-[10.5px] bg-teal-50 border border-teal-200 text-teal-800 font-bold px-2.5 py-1 rounded-xl">
                      📍 Exact Pickup Spot: {ride.pickupSpot}
                    </div>
                  )}

                  {/* Badges */}
                  <div className="flex flex-wrap gap-1.5 text-[10px] font-bold">
                    <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md border border-emerald-200">
                      ⏰ Departs {format12Hour(ride.time)} • {ride.date}
                    </span>
                    <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-md border border-blue-200">
                      🏁 Est. Arrival: {eta.arrivalTime12} (~{eta.durationFormatted})
                    </span>
                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
                      💺 {ride.seats} Seats Left
                    </span>
                    {ride.isLadiesOnly && (
                      <span className="bg-pink-50 text-pink-600 px-2 py-0.5 rounded-md border border-pink-200">
                        🌸 Women Driven
                      </span>
                    )}
                    {ride.isFamilyOnBoard && (
                      <span className="bg-purple-50 text-purple-700 px-2 py-0.5 rounded-md border border-purple-200">
                        👨‍👩‍👧 Family Safe
                      </span>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        if (!currentUser) {
                          onRequestLogin();
                          return;
                        }
                        setPendingBookingRide({
                          ride,
                          fare: ride.calculatedFare,
                          travelKm: ride.travelKm
                        });
                      }}
                      className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer transition-all flex items-center justify-center gap-1.5"
                    >
                      <span>✅ Book Seat</span>
                      <span>•</span>
                      <span>₹{ride.calculatedFare * seatCount}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (!currentUser) {
                          onRequestLogin();
                          return;
                        }
                        const val = prompt('Enter your offer fare per seat (₹):', String(ride.calculatedFare));
                        if (val && !isNaN(Number(val)) && Number(val) > 0) {
                          onOfferFare(ride, Number(val), ride.travelKm);
                        }
                      }}
                      className="py-2 px-3 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer transition-all"
                    >
                      🔄 Offer
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Sponsored Ads in feed */}
            {hasSearched && sponsoredAds.length > 0 && (
              <div className="p-3 bg-amber-50 border border-dashed border-amber-400 rounded-2xl space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-amber-200 text-amber-800">
                    📢 SPONSORED LOCAL PARTNER
                  </span>
                  <span className="text-[10px] text-amber-700 font-bold">
                    {sponsoredAds[0].category}
                  </span>
                </div>
                <div className="text-xs font-black text-slate-800">
                  {sponsoredAds[0].name}
                </div>
                <div className="text-[11px] text-slate-600">
                  📍 {sponsoredAds[0].landmark}
                </div>
                <a
                  href={`tel:${sponsoredAds[0].phone}`}
                  className="block text-center py-2 bg-blue-600 text-white text-xs font-extrabold rounded-xl"
                >
                  📞 Call {sponsoredAds[0].phone}
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      <LuggageModal
        isOpen={isBagModalOpen}
        selectedCount={extraBags}
        onSelect={(cnt) => setExtraBags(cnt)}
        onClose={() => setIsBagModalOpen(false)}
      />

      <VehicleFilterModal
        isOpen={isVehModalOpen}
        selectedVehicle={selectedVehicle}
        onSelect={(veh) => handleVehicleSelect(veh)}
        onClose={() => setIsVehModalOpen(false)}
      />

      <SeatsModal
        isOpen={isSeatsModalOpen}
        selectedSeats={seatCount}
        onSelect={(cnt) => setSeatCount(cnt)}
        onClose={() => setIsSeatsModalOpen(false)}
      />

      <BookingPaymentModal
        isOpen={Boolean(pendingBookingRide)}
        onConfirm={async (mode) => {
          if (pendingBookingRide) {
            await onBookRide(
              pendingBookingRide.ride,
              pendingBookingRide.fare,
              pendingBookingRide.travelKm,
              mode
            );
            setPendingBookingRide(null);
          }
        }}
        onClose={() => setPendingBookingRide(null)}
      />
    </div>
  );
};
