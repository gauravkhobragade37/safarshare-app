import React, { useState, useEffect } from 'react';
import { MapView } from '../MapView';
import { UserProfile, UserVehicle, RideTrip } from '../../types';
import {
  autocompletePlaces,
  reverseGeocode,
  cleanLocation,
  fetchRoutesBetweenPoints,
  OsrmRouteOption
} from '../../utils/geo';
import { ParcelSlabsModal } from '../modals/AppModals';

interface PostTabProps {
  currentUser: UserProfile | null;
  vehicles: UserVehicle[];
  isActive: boolean;
  onPublishTrip: (tripData: Omit<RideTrip, 'id' | 'created' | 'updatedAt'>, alsoReturn: boolean, returnTime: string) => Promise<void>;
  onShowToast: (msg: string) => void;
  onRequestLogin: () => void;
}

export const PostTab: React.FC<PostTabProps> = ({
  currentUser,
  vehicles,
  isActive,
  onPublishTrip,
  onShowToast,
  onRequestLogin
}) => {
  const [pickup, setPickup] = useState({ lat: 21.4588, lng: 80.1961, text: '' });
  const [drop, setDrop] = useState({ lat: 21.5588, lng: 80.3961, text: '' });
  const [radarMode, setRadarMode] = useState<'intercity' | 'local'>('intercity');
  const [snapState, setSnapState] = useState<'collapsed' | 'half' | 'expanded'>('half');

  const [fromQuery, setFromQuery] = useState('');
  const [toQuery, setToQuery] = useState('');
  const [fromSuggestions, setFromSuggestions] = useState<any[]>([]);
  const [toSuggestions, setToSuggestions] = useState<any[]>([]);

  // Selected vehicle
  const [selectedVehicleType, setSelectedVehicleType] = useState('Car');
  const [selectedModel, setSelectedModel] = useState('Personal Car');
  const [selectedPlate, setSelectedPlate] = useState('MH35AB1234');
  const [seats, setSeats] = useState(3);
  const [price, setPrice] = useState(150);
  const [pickupSpot, setPickupSpot] = useState('');

  // Toggles
  const [isLadiesOnly, setIsLadiesOnly] = useState(false);
  const [isDaily, setIsDaily] = useState(false);
  const [hasReturnTrip, setHasReturnTrip] = useState(false);
  const [returnTime, setReturnTime] = useState('18:30');
  const [dateTime, setDateTime] = useState('');

  // Parcel slabs
  const [isParcelModalOpen, setIsParcelModalOpen] = useState(false);
  const [typeDoc, setTypeDoc] = useState(true);
  const [typeBag, setTypeBag] = useState(true);
  const [typeCargo, setTypeCargo] = useState(false);
  const [typeFull, setTypeFull] = useState(false);

  // Routes
  const [availableRoutes, setAvailableRoutes] = useState<OsrmRouteOption[]>([]);
  const [selectedRouteIdx, setSelectedRouteIdx] = useState(0);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isFleetModalOpen, setIsFleetModalOpen] = useState(false);

  useEffect(() => {
    reverseGeocode(pickup.lat, pickup.lng).then((addr) => {
      setPickup((p) => ({ ...p, text: addr }));
      setFromQuery(addr);
    });
    reverseGeocode(drop.lat, drop.lng).then((addr) => {
      setDrop((d) => ({ ...d, text: addr }));
      setToQuery(addr);
    });
  }, []);

  // Update garage vehicle default if user has vehicles
  useEffect(() => {
    if (vehicles && vehicles.length > 0) {
      const v = vehicles[0];
      setSelectedVehicleType(v.type);
      setSelectedModel(v.model);
      setSelectedPlate(v.plate);
      setSeats(v.type === 'Bike' ? 1 : 3);
    }
  }, [vehicles]);

  // Recalculate routes on coordinate changes
  useEffect(() => {
    fetchRoutesBetweenPoints(pickup, drop).then((rts) => {
      setAvailableRoutes(rts);
      setSelectedRouteIdx(0);
      if (rts && rts.length > 0) {
        const dist = rts[0].distanceKm;
        setPrice(Math.max(50, Math.round(dist * 5.5)));
      }
    });
  }, [pickup.lat, pickup.lng, drop.lat, drop.lng]);

  const handleGPS = () => {
    if (!navigator.geolocation) {
      onShowToast('GPS unsupported on this device');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const addr = await reverseGeocode(lat, lng);
        setPickup({ lat, lng, text: addr });
        setFromQuery(addr);
        onShowToast('📍 Live GPS Position Set!');
      },
      () => onShowToast('GPS access denied'),
      { enableHighAccuracy: true }
    );
  };

  const handlePublish = async () => {
    if (!currentUser) {
      onRequestLogin();
      return;
    }
    if (!fromQuery.trim() || !toQuery.trim()) {
      onShowToast('❌ Please enter Starting Point & Destination!');
      return;
    }

    const selRoute = availableRoutes[selectedRouteIdx] || availableRoutes[0];
    let dateStr = '';
    let timeStr = '';

    if (dateTime) {
      const parts = dateTime.split('T');
      dateStr = parts[0];
      timeStr = parts[1] || '09:00';
    } else {
      const n = new Date();
      dateStr = n.toISOString().split('T')[0];
      timeStr = `${String(n.getHours()).padStart(2, '0')}:${String(n.getMinutes()).padStart(2, '0')}`;
    }

    setIsPublishing(true);

    try {
      const tripPayload: Omit<RideTrip, 'id' | 'created' | 'updatedAt'> = {
        driverUid: currentUser.uid,
        driverName: currentUser.name || 'Driver',
        driverEmail: currentUser.email || '',
        driverPhone: currentUser.phone || '',
        driverDp: currentUser.photoURL || '',
        from: fromQuery.trim(),
        to: toQuery.trim(),
        date: dateStr,
        time: timeStr,
        pickupSpot: pickupSpot.trim(),
        status: 'Active',
        passenger: seats > 0,
        parcel: typeDoc || typeBag || typeCargo || typeFull,
        seats: Number(seats),
        seatPrice: Number(price),
        vehicle: selectedVehicleType,
        carModel: selectedModel,
        carNumber: selectedPlate,
        isLadiesOnly,
        isDaily,
        typeDoc,
        typeBag,
        typeCargo,
        docPrice: typeDoc ? 60 : 0,
        bagPrice: typeBag ? 100 : 0,
        cargoPrice: typeCargo ? 150 : 0,
        fullVehiclePrice: typeFull ? 800 : 0,
        geometry: selRoute ? selRoute.geometry : null,
        routeDistanceKm: selRoute ? selRoute.distanceKm : 10,
        routeDurationMin: selRoute ? selRoute.durationMin : 25
      };

      await onPublishTrip(tripPayload, hasReturnTrip, returnTime);
      onShowToast('🚀 Smart Trip Published (0% Commission)!');
      setPickupSpot('');
    } catch (e: any) {
      onShowToast('❌ Failed to publish: ' + (e.message || 'Error'));
    } finally {
      setIsPublishing(false);
    }
  };

  const getVehicleIcon = (type: string) => {
    if (type === 'Bike') return '🏍️';
    if (type === 'Auto') return '🛺';
    if (type === 'Pickup/Truck') return '🛻';
    if (type === 'Bus') return '🚌';
    if (type === 'Train') return '🚆';
    return '🚗';
  };

  return (
    <div className="relative w-full h-full overflow-hidden">
      <MapView
        mapId="postMap"
        pickupCoords={pickup}
        dropCoords={drop}
        onPickupChange={(coords) => {
          setPickup((p) => ({ ...p, ...coords }));
          reverseGeocode(coords.lat, coords.lng).then((addr) => {
            setPickup((p) => ({ ...p, text: addr }));
            setFromQuery(addr);
          });
        }}
        onDropChange={(coords) => {
          setDrop((d) => ({ ...d, ...coords }));
          reverseGeocode(coords.lat, coords.lng).then((addr) => {
            setDrop((d) => ({ ...d, text: addr }));
            setToQuery(addr);
          });
        }}
        altRoutes={availableRoutes.map((r) => r.coordinates)}
        selectedRouteIndex={selectedRouteIdx}
        onSelectRouteIndex={(idx) => {
          setSelectedRouteIdx(idx);
          if (availableRoutes[idx]) {
            setPrice(Math.max(50, Math.round(availableRoutes[idx].distanceKm * 5.5)));
          }
        }}
        radarMode={radarMode}
        onToggleRadar={() => {
          setRadarMode((m) => (m === 'intercity' ? 'local' : 'intercity'));
          onShowToast(
            `Radar: ${radarMode === 'intercity' ? '🛵 Local (2 KM)' : '🚗 Intercity (10 KM)'}`
          );
        }}
        onTriggerGPS={handleGPS}
        isActiveTab={isActive}
      />

      {/* Bottom Sheet */}
      <div
        className={`absolute left-0 right-0 bottom-0 bg-white rounded-t-3xl shadow-2xl z-[500] flex flex-col transition-all duration-300 ${
          snapState === 'collapsed'
            ? 'h-[16%]'
            : snapState === 'expanded'
            ? 'h-[88%]'
            : 'h-[54%]'
        }`}
      >
        <div
          onClick={() => {
            setSnapState((s) => (s === 'collapsed' ? 'half' : s === 'half' ? 'expanded' : 'half'));
          }}
          className="w-full py-2.5 flex justify-center items-center cursor-pointer select-none"
        >
          <div className="w-11 h-1 bg-slate-300 rounded-full" />
        </div>

        <div className="flex-1 px-4 pb-20 overflow-y-auto no-scrollbar">
          {/* Fleet Vehicle Selector Row */}
          <div className="flex items-center gap-2 mb-2">
            <div
              onClick={() => setIsFleetModalOpen(true)}
              className="flex-1 flex items-center justify-between bg-slate-50 border border-slate-200 hover:border-blue-500 rounded-xl p-2 cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-xl">{getVehicleIcon(selectedVehicleType)}</span>
                <div>
                  <div className="text-xs font-black text-slate-800 leading-tight">
                    {selectedModel} ({selectedPlate})
                  </div>
                  <div className="text-[10px] text-slate-500 font-semibold">
                    {selectedVehicleType} • Verified Garage Fleet
                  </div>
                </div>
              </div>
              <span className="text-xs text-slate-400">▼</span>
            </div>

            {/* Ladies Toggle */}
            <button
              type="button"
              onClick={() => setIsLadiesOnly(!isLadiesOnly)}
              className={`flex flex-col items-center justify-center w-12 h-11 rounded-xl border text-[9.5px] font-black shrink-0 transition-all cursor-pointer ${
                isLadiesOnly
                  ? 'bg-pink-50 border-pink-400 text-pink-600 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-pink-700 hover:bg-pink-50/50'
              }`}
            >
              <span>🌸</span>
              <span>Ladies</span>
            </button>
          </div>

          {/* From Input */}
          <div className="relative mb-2">
            <div className="flex items-center gap-1.5 bg-slate-100 focus-within:bg-white border focus-within:border-blue-500 rounded-xl px-2.5 py-2 transition-all">
              <span className="text-emerald-600 text-xs">●</span>
              <input
                type="text"
                value={fromQuery}
                onChange={async (e) => {
                  setFromQuery(e.target.value);
                  if (e.target.value.length >= 2) {
                    const list = await autocompletePlaces(e.target.value);
                    setFromSuggestions(list);
                  }
                }}
                placeholder="Starting Point (GPS Enabled)"
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
              {fromQuery && (
                <button
                  onClick={() => { setFromQuery(''); setFromSuggestions([]); }}
                  className="text-slate-400 text-xs px-1"
                >
                  ✕
                </button>
              )}
              <button
                onClick={() => setSnapState('collapsed')}
                className="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-1 rounded-md shrink-0"
              >
                📍 Map
              </button>
            </div>

            {fromSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl mt-1 z-50 overflow-hidden">
                {fromSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setPickup({ lat: item.lat, lng: item.lon, text: item.cleanName });
                      setFromQuery(item.cleanName);
                      setFromSuggestions([]);
                    }}
                    className="p-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
                  >
                    📍 {item.cleanName}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Destination Input & Commuter Toggle */}
          <div className="flex items-center gap-1.5 mb-2 relative">
            <div className="flex-1 flex items-center gap-1.5 bg-slate-100 focus-within:bg-white border focus-within:border-blue-500 rounded-xl px-2.5 py-2 transition-all">
              <span className="text-red-500 text-xs">◼</span>
              <input
                type="text"
                value={toQuery}
                onChange={async (e) => {
                  setToQuery(e.target.value);
                  if (e.target.value.length >= 2) {
                    const list = await autocompletePlaces(e.target.value);
                    setToSuggestions(list);
                  }
                }}
                placeholder="Destination Point..."
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
              {toQuery && (
                <button
                  onClick={() => { setToQuery(''); setToSuggestions([]); }}
                  className="text-slate-400 text-xs px-1"
                >
                  ✕
                </button>
              )}
              <button
                onClick={() => setSnapState('collapsed')}
                className="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-1 rounded-md shrink-0"
              >
                📍 Map
              </button>
            </div>

            {/* Daily Commuter toggle */}
            <button
              type="button"
              onClick={() => setIsDaily(!isDaily)}
              className={`flex flex-col items-center justify-center w-12 h-10 rounded-xl border text-[9.5px] font-black shrink-0 transition-all cursor-pointer ${
                isDaily
                  ? 'bg-amber-50 border-amber-400 text-amber-700 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span>🔁</span>
              <span>Daily</span>
            </button>

            {toSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl mt-1 z-50 overflow-hidden">
                {toSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setDrop({ lat: item.lat, lng: item.lon, text: item.cleanName });
                      setToQuery(item.cleanName);
                      setToSuggestions([]);
                    }}
                    className="p-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
                  >
                    📍 {item.cleanName}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Highway Route selector pills */}
          {availableRoutes.length > 0 && (
            <div className="flex gap-1.5 overflow-x-auto py-1 mb-2 no-scrollbar">
              {availableRoutes.map((r, idx) => {
                const isSelected = selectedRouteIdx === idx;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setSelectedRouteIdx(idx);
                      setPrice(Math.max(50, Math.round(r.distanceKm * 5.5)));
                    }}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-bold shrink-0 border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🛣️ {r.summary}: {r.distanceKm} KM
                  </button>
                );
              })}
            </div>
          )}

          {/* Price and Seats Row */}
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <span className="text-xs font-black text-blue-600">₹</span>
              <input
                type="number"
                min={10}
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                placeholder="Fare / Seat (₹)"
                className="w-full text-xs font-bold bg-transparent outline-none text-slate-800"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <span className="text-xs">👥</span>
              <select
                value={seats}
                onChange={(e) => setSeats(Number(e.target.value))}
                className="w-full text-xs font-bold bg-transparent outline-none cursor-pointer"
              >
                <option value={0}>0 (Parcel Only)</option>
                <option value={1}>1 Seat</option>
                <option value={2}>2 Seats</option>
                <option value={3}>3 Seats</option>
                <option value={4}>4 Seats</option>
                <option value={6}>6 Seats (SUV/Van)</option>
              </select>
            </div>
          </div>

          {/* Pickup spot landmark */}
          <div className="mb-2">
            <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <span className="text-xs">📍</span>
              <input
                type="text"
                value={pickupSpot}
                onChange={(e) => setPickupSpot(e.target.value)}
                placeholder="Pickup Landmark Spot (e.g. Bus Stand Gate 2)"
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
            </div>
          </div>

          {/* Return Trip Box */}
          {hasReturnTrip && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl mb-2 flex justify-between items-center text-xs">
              <span className="font-bold text-emerald-800">⏰ Return Departure Time</span>
              <input
                type="time"
                value={returnTime}
                onChange={(e) => setReturnTime(e.target.value)}
                className="bg-white border border-emerald-300 rounded-lg px-2 py-1 font-bold text-emerald-700 outline-none"
              />
            </div>
          )}

          {/* Chips Scroller */}
          <div className="flex gap-1.5 overflow-x-auto py-1 mb-3 no-scrollbar">
            <label className="relative flex items-center gap-1 py-1.5 px-3 bg-slate-900 text-white rounded-full text-[11px] font-bold cursor-pointer select-none shrink-0">
              <span>📅</span>
              <span>{dateTime ? dateTime.replace('T', ' ') : 'Today, Now'}</span>
              <input
                type="datetime-local"
                value={dateTime}
                onChange={(e) => setDateTime(e.target.value)}
                className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
              />
            </label>

            <button
              type="button"
              onClick={() => setIsParcelModalOpen(true)}
              className="py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full text-[11px] font-bold border border-slate-200 shrink-0 cursor-pointer"
            >
              📦 Accept Parcels
            </button>

            <button
              type="button"
              onClick={() => setHasReturnTrip(!hasReturnTrip)}
              className={`py-1.5 px-3 rounded-full text-[11px] font-bold border shrink-0 transition-all cursor-pointer ${
                hasReturnTrip
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
              }`}
            >
              🔄 {hasReturnTrip ? 'Return Added' : '+ Add Return'}
            </button>
          </div>

          {/* Publish Button */}
          <button
            type="button"
            onClick={handlePublish}
            disabled={isPublishing}
            className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-sky-600 text-white rounded-xl font-black text-sm shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            {isPublishing ? (
              <span>⏳ Publishing Trip to SafarShare...</span>
            ) : (
              <span>Publish Smart Trip (0% Commission) →</span>
            )}
          </button>
        </div>
      </div>

      {/* Parcel Slabs Modal */}
      <ParcelSlabsModal
        isOpen={isParcelModalOpen}
        typeDoc={typeDoc}
        typeBag={typeBag}
        typeCargo={typeCargo}
        typeFull={typeFull}
        onToggle={(key) => {
          if (key === 'doc') setTypeDoc(!typeDoc);
          if (key === 'bag') setTypeBag(!typeBag);
          if (key === 'cargo') setTypeCargo(!typeCargo);
          if (key === 'full') setTypeFull(!typeFull);
        }}
        onClose={() => setIsParcelModalOpen(false)}
      />

      {/* Garage Fleet Vehicle Modal */}
      {isFleetModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[80vh] flex flex-col">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-extrabold text-slate-800">🚗 Select Fleet Vehicle</h3>
              <button onClick={() => setIsFleetModalOpen(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {vehicles.map((v) => (
                <div
                  key={v.id}
                  onClick={() => {
                    setSelectedVehicleType(v.type);
                    setSelectedModel(v.model);
                    setSelectedPlate(v.plate);
                    setSeats(v.type === 'Bike' ? 1 : 3);
                    setIsFleetModalOpen(false);
                  }}
                  className={`p-3 rounded-xl border cursor-pointer flex justify-between items-center transition-all ${
                    selectedPlate === v.plate ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold text-slate-800">
                      {getVehicleIcon(v.type)} {v.model} ({v.plate})
                    </div>
                    <div className="text-[10.5px] text-slate-500">
                      {v.type} • {v.kycStatus === 'verified' ? '✅ Verified KYC' : '⏳ Verified Garage'}
                    </div>
                  </div>
                  <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
                    selectedPlate === v.plate ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
                  }`}>
                    {selectedPlate === v.plate ? '✓' : ''}
                  </div>
                </div>
              ))}

              {/* Standard Options */}
              <div
                onClick={() => {
                  setSelectedVehicleType('Car');
                  setSelectedModel('Personal Car');
                  setSelectedPlate('MH35AB1234');
                  setSeats(3);
                  setIsFleetModalOpen(false);
                }}
                className="p-3 rounded-xl border bg-slate-50 border-slate-200 cursor-pointer"
              >
                <div className="text-xs font-bold text-slate-800">🚗 Personal Car (MH35AB1234)</div>
                <div className="text-[10px] text-slate-500">4-Seater AC Car Pool</div>
              </div>

              <div
                onClick={() => {
                  setSelectedVehicleType('Bike');
                  setSelectedModel('Motorcycle');
                  setSelectedPlate('MH35AD0901');
                  setSeats(1);
                  setIsFleetModalOpen(false);
                }}
                className="p-3 rounded-xl border bg-slate-50 border-slate-200 cursor-pointer"
              >
                <div className="text-xs font-bold text-slate-800">🏍️ Apache RTR (MH35AD0901)</div>
                <div className="text-[10px] text-slate-500">1 Seat Pillion Bike</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
