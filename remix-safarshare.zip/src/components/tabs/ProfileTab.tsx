import React, { useState } from 'react';
import {
  UserProfile,
  UserVehicle,
  SavedPlace,
  RideTrip,
  BookingRequest,
  SponsoredAd,
  ReportItem,
  LiveLocation
} from '../../types';
import { cleanLocation, format12Hour } from '../../utils/geo';
import {
  EditProfileModal,
  AddVehicleModal,
  AddSavedPlaceModal,
  TermsModal
} from '../modals/AppModals';
import {
  DeepInspectModal,
  AdminGarageModal,
  AdminTripDetailsModal,
  SponsoredAdsModal
} from '../modals/AdminModals';

interface ProfileTabProps {
  currentUser: UserProfile | null;
  users: UserProfile[];
  trips: RideTrip[];
  requests: BookingRequest[];
  vehicles: UserVehicle[];
  savedPlaces: SavedPlace[];
  sponsoredAds: SponsoredAd[];
  reports: ReportItem[];
  liveLocations: Record<string, LiveLocation>;
  onUpdateProfile: (name: string, phone: string, gender: 'Male' | 'Female' | 'Other') => Promise<void>;
  onAddVehicle: (type: any, model: string, plate: string) => Promise<void>;
  onDeleteVehicle: (id: string) => Promise<void>;
  onAddPlace: (title: string, address: string) => Promise<void>;
  onDeletePlace: (id: string) => Promise<void>;
  onToggleBlockUser: (userUid: string, currentStatus: boolean, name: string) => Promise<void>;
  onForceCancelTrip: (rideId: string) => Promise<void>;
  onApproveVehicleKYC: (vehicleId: string) => Promise<void>;
  onRejectVehicleKYC: (vehicleId: string, userUid: string) => Promise<void>;
  onAddSponsoredAd: (name: string, cat: string, landmark: string, target: string, phone: string) => Promise<void>;
  onDeleteSponsoredAd: (id: string) => Promise<void>;
  onClearAllTestData: () => Promise<void>;
  onLogout: () => void;
  onShowToast: (msg: string) => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  currentUser,
  users,
  trips,
  requests,
  vehicles,
  savedPlaces,
  sponsoredAds,
  reports,
  liveLocations,
  onUpdateProfile,
  onAddVehicle,
  onDeleteVehicle,
  onAddPlace,
  onDeletePlace,
  onToggleBlockUser,
  onForceCancelTrip,
  onApproveVehicleKYC,
  onRejectVehicleKYC,
  onAddSponsoredAd,
  onDeleteSponsoredAd,
  onClearAllTestData,
  onLogout,
  onShowToast
}) => {
  const [adminTab, setAdminTab] = useState<'overview' | 'users' | 'trips' | 'payments' | 'parcels' | 'live' | 'reports' | 'ads'>('overview');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [tripFilter, setTripFilter] = useState<'all' | 'Active' | 'Completed' | 'Cancelled'>('all');

  // Modals
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isAddVehicleOpen, setIsAddVehicleOpen] = useState(false);
  const [isAddPlaceOpen, setIsAddPlaceOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isAdsModalOpen, setIsAdsModalOpen] = useState(false);

  // Admin Selected Modals
  const [inspectUser, setInspectUser] = useState<UserProfile | null>(null);
  const [garageKycUser, setGarageKycUser] = useState<UserProfile | null>(null);
  const [selectedAdminTrip, setSelectedAdminTrip] = useState<RideTrip | null>(null);

  const isAdmin = currentUser?.role === 'admin' || currentUser?.email === 'gauravkhobragade37@gmail.com';

  // Calculate driver earnings
  const myCompletedTripsAsDriver = requests.filter(
    (q) => q.driverUid === currentUser?.uid && q.status === 'Completed'
  );
  const totalEarnings = myCompletedTripsAsDriver.reduce(
    (sum, q) => sum + (Number(q.currentPrice) || 0),
    0
  );

  // Filtered users for admin
  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      u.phone.includes(userSearchQuery)
  );

  // Filtered trips for admin
  const filteredTrips =
    tripFilter === 'all' ? trips : trips.filter((t) => t.status === tripFilter);

  return (
    <div className="h-full overflow-y-auto p-4 pb-24 space-y-4 max-w-2xl mx-auto">
      {/* User Hero Card */}
      <div className="p-4 bg-white border border-slate-200 rounded-3xl shadow-xs flex items-center gap-3.5">
        <div className="relative w-14 h-14 shrink-0">
          <img
            src={currentUser?.photoURL || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'}
            alt="User"
            className="w-full h-full rounded-full object-cover border-2 border-blue-600 bg-slate-100"
          />
          <div className="absolute -bottom-1 -right-1 bg-slate-900 text-amber-400 text-xs w-5 h-5 rounded-full flex items-center justify-center border-2 border-white font-bold">
            {isAdmin ? '👑' : '✓'}
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="font-extrabold text-sm text-slate-900 truncate">
            {currentUser?.name || 'Guest User'}
          </div>
          <div className="text-xs text-slate-500 truncate">
            {currentUser?.email || 'Sign in with Google to sync trips'}
          </div>
          <div className="text-xs font-bold text-emerald-700 mt-0.5 truncate">
            📞 {currentUser?.phone ? `+91 ${currentUser.phone}` : 'No phone added'} | 🧑 {currentUser?.gender || 'Male'}
          </div>
        </div>

        {currentUser && (
          <button
            type="button"
            onClick={() => setIsEditProfileOpen(true)}
            className="py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-extrabold rounded-xl shrink-0 cursor-pointer"
          >
            ✏️ Edit
          </button>
        )}
      </div>

      {/* Driver Earnings Card */}
      <div className="p-4 bg-gradient-to-r from-blue-600 to-sky-600 text-white rounded-3xl shadow-md space-y-1">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-[10px] font-black text-amber-300 tracking-wider uppercase">
              TOTAL DIRECT DRIVER SETTLEMENT
            </div>
            <div className="text-2xl font-black">₹{totalEarnings}</div>
          </div>
          <span className="text-3xl">💵</span>
        </div>
        <div className="text-[10.5px] text-blue-100">
          100% direct payment via Cash or Personal UPI QR Code. 0% Commission Platform.
        </div>
      </div>

      {/* MASTER ADMIN PANEL */}
      {isAdmin && (
        <div className="p-4 bg-blue-50 border-2 border-blue-600 rounded-3xl space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-black text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>👑 Master Admin Control Center</span>
            </h3>
            <span className="bg-blue-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full">
              SUPER ADMIN
            </span>
          </div>

          {/* Admin Navigation Pills */}
          <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar">
            {[
              { id: 'overview', label: '📊 1. Overview' },
              { id: 'users', label: '👥 2. Users' },
              { id: 'trips', label: '🚗 3. Trips' },
              { id: 'payments', label: '💳 4. Payments' },
              { id: 'parcels', label: '📦 5. Parcels' },
              { id: 'live', label: '📍 6. Live Map' },
              { id: 'reports', label: '⚠️ 7. Reports' },
              { id: 'ads', label: '📢 8. Ads' }
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setAdminTab(tab.id as any)}
                className={`px-3 py-1 rounded-lg text-[11px] font-bold shrink-0 transition-all cursor-pointer ${
                  adminTab === tab.id
                    ? 'bg-white text-blue-700 shadow-sm border border-blue-200'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab 1: Overview */}
          {adminTab === 'overview' && (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-white border border-slate-200 rounded-xl">
                <div className="text-slate-500 font-semibold">Total Users</div>
                <div className="text-lg font-black text-blue-600">{users.length}</div>
              </div>
              <div className="p-2.5 bg-white border border-slate-200 rounded-xl">
                <div className="text-slate-500 font-semibold">Active Trips</div>
                <div className="text-lg font-black text-blue-600">
                  {trips.filter((t) => t.status === 'Active').length}
                </div>
              </div>
              <div className="p-2.5 bg-white border border-slate-200 rounded-xl">
                <div className="text-slate-500 font-semibold">Total Requests</div>
                <div className="text-lg font-black text-blue-600">{requests.length}</div>
              </div>
              <div className="p-2.5 bg-white border border-slate-200 rounded-xl">
                <div className="text-slate-500 font-semibold">Parcel Logistics</div>
                <div className="text-lg font-black text-blue-600">
                  {requests.filter((q) => q.type === 'parcel').length}
                </div>
              </div>
              <div className="p-2.5 bg-white border border-slate-200 rounded-xl">
                <div className="text-slate-500 font-semibold">Completed Trips</div>
                <div className="text-lg font-black text-blue-600">
                  {trips.filter((t) => t.status === 'Completed').length}
                </div>
              </div>
              <div className="p-2.5 bg-white border border-slate-200 rounded-xl">
                <div className="text-slate-500 font-semibold">Platform Volume</div>
                <div className="text-lg font-black text-blue-600">
                  ₹{requests.reduce((sum, q) => sum + (Number(q.currentPrice) || 0), 0)}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Users */}
          {adminTab === 'users' && (
            <div className="space-y-2">
              <input
                type="text"
                value={userSearchQuery}
                onChange={(e) => setUserSearchQuery(e.target.value)}
                placeholder="🔍 Search users by name, email, phone..."
                className="w-full text-xs p-2 rounded-xl border border-slate-200 bg-white outline-none"
              />

              <div className="space-y-2 max-h-60 overflow-y-auto">
                {filteredUsers.map((u) => (
                  <div
                    key={u.uid}
                    className={`p-3 rounded-xl border bg-white space-y-2 ${
                      u.isBlocked ? 'border-red-300 bg-red-50/50' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex justify-between items-center text-xs">
                      <div>
                        <b>{u.name}</b> {u.isBlocked && <span className="text-red-600 font-bold">(BLOCKED)</span>}
                        <div className="text-[10.5px] text-slate-500">
                          {u.email} • 📞 {u.phone || 'No phone'}
                        </div>
                      </div>
                      <button
                        onClick={() => onToggleBlockUser(u.uid, Boolean(u.isBlocked), u.name)}
                        className={`px-2.5 py-1 text-[11px] font-bold rounded-lg ${
                          u.isBlocked
                            ? 'bg-emerald-600 text-white'
                            : 'bg-red-50 text-red-600 border border-red-200'
                        }`}
                      >
                        {u.isBlocked ? 'Unblock' : 'Block'}
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => setInspectUser(u)}
                        className="flex-1 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold rounded-lg"
                      >
                        🔍 Inspect Trips
                      </button>
                      <button
                        onClick={() => setGarageKycUser(u)}
                        className="flex-1 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 text-[11px] font-bold rounded-lg"
                      >
                        🚘 Garage / KYC
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Trips */}
          {adminTab === 'trips' && (
            <div className="space-y-2">
              <div className="flex gap-1.5 overflow-x-auto pb-1">
                {(['all', 'Active', 'Completed', 'Cancelled'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setTripFilter(filter)}
                    className={`px-2.5 py-1 text-[11px] font-bold rounded-lg ${
                      tripFilter === filter
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-slate-700 border border-slate-200'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>

              <div className="space-y-1.5 max-h-60 overflow-y-auto">
                {filteredTrips.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedAdminTrip(t)}
                    className="p-2.5 bg-white border border-slate-200 rounded-xl hover:border-blue-500 cursor-pointer text-xs"
                  >
                    <div className="flex justify-between items-center font-bold">
                      <span>{cleanLocation(t.from)} ➔ {cleanLocation(t.to)}</span>
                      <span className="text-[10px] text-blue-600">{t.status}</span>
                    </div>
                    <div className="text-[10.5px] text-slate-500">
                      Driver: {t.driverName} • Fare: ₹{t.seatPrice} • {t.date}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: Payments */}
          {adminTab === 'payments' && (
            <div className="space-y-1.5 max-h-60 overflow-y-auto text-xs">
              {requests.map((q) => (
                <div key={q.id} className="p-2.5 bg-white border border-slate-200 rounded-xl">
                  <div className="font-bold flex justify-between">
                    <span>{q.type === 'passenger' ? '🧑 Seat Fare' : '📦 Parcel Fare'}</span>
                    <span className="text-emerald-600 font-extrabold">₹{q.currentPrice}</span>
                  </div>
                  <div className="text-[10.5px] text-slate-500">
                    Status: <b>{q.status}</b> • Mode: {q.paymentMode || 'Cash'} • Passenger: {q.passengerName}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tab 5: Parcels */}
          {adminTab === 'parcels' && (
            <div className="space-y-1.5 max-h-60 overflow-y-auto text-xs">
              {requests
                .filter((q) => q.type === 'parcel')
                .map((q) => (
                  <div key={q.id} className="p-2.5 bg-white border border-slate-200 rounded-xl">
                    <div className="font-bold">
                      📦 Slab: {q.slab} • Fare: ₹{q.currentPrice}
                    </div>
                    <div className="text-[10.5px] text-slate-500">
                      Receiver: {q.recName} ({q.recPhone}) • Status: <b>{q.status}</b>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Tab 6: Live Map */}
          {adminTab === 'live' && (
            <div className="p-3 bg-white border border-slate-200 rounded-xl text-xs space-y-2">
              <div className="font-bold text-slate-800">
                Active Transporters on Radar: {Object.keys(liveLocations).length}
              </div>
              <div className="space-y-1">
                {Object.entries(liveLocations).map(([rideId, loc]: [string, LiveLocation]) => (
                  <div key={rideId} className="p-2 bg-slate-50 rounded-lg flex justify-between">
                    <span>Ride #{rideId.slice(0, 6)}</span>
                    <span className={loc.status === 'live' ? 'text-emerald-600 font-bold' : 'text-red-500 font-bold'}>
                      {loc.status === 'live' ? '🟢 Live GPS' : '🔴 Offline'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 7: Reports */}
          {adminTab === 'reports' && (
            <div className="space-y-1.5 max-h-60 overflow-y-auto text-xs">
              {reports.length === 0 ? (
                <div className="text-slate-400 text-center py-4">No reports filed.</div>
              ) : (
                reports.map((rep) => (
                  <div key={rep.id} className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-900">
                    <div className="font-bold">🚨 {rep.type}</div>
                    <div className="text-[11px]">Reporter: {rep.reporterName} • Reason: {rep.reason}</div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Tab 8: Ads */}
          {adminTab === 'ads' && (
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setIsAdsModalOpen(true)}
                className="w-full py-2 bg-blue-600 text-white text-xs font-bold rounded-xl"
              >
                📢 Manage Sponsored Ads
              </button>
              <div className="space-y-1 text-xs">
                {sponsoredAds.map((a) => (
                  <div key={a.id} className="p-2 bg-white border border-slate-200 rounded-xl flex justify-between items-center">
                    <div>
                      <b>{a.name}</b> ({a.category})
                      <div className="text-[10px] text-slate-500">📍 {a.landmark}</div>
                    </div>
                    <button onClick={() => onDeleteSponsoredAd(a.id)} className="text-red-500 font-bold">
                      🗑️
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Clear Test Data */}
          <button
            type="button"
            onClick={onClearAllTestData}
            className="w-full py-2 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 text-xs font-bold rounded-xl"
          >
            🗑️ Clear All Test Data (1-Click)
          </button>
        </div>
      )}

      {/* Garage Section */}
      <div className="p-4 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-3">
        <div className="flex justify-between items-center">
          <div className="font-extrabold text-xs text-slate-900">
            🏍️ My Registered Vehicles
          </div>
          {currentUser && (
            <button
              onClick={() => setIsAddVehicleOpen(true)}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              + Add Vehicle
            </button>
          )}
        </div>

        <div className="space-y-2">
          {vehicles.length === 0 ? (
            <div className="text-xs text-slate-400">
              No vehicles registered. Click + Add Vehicle above.
            </div>
          ) : (
            vehicles.map((v) => (
              <div
                key={v.id}
                className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex justify-between items-center text-xs"
              >
                <div>
                  <div className="font-bold text-slate-800">
                    {v.model} <span className="font-mono text-blue-600">({v.plate})</span>
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {v.type} • {v.kycStatus === 'verified' ? '✅ Verified' : '⏳ Pending KYC'}
                  </div>
                </div>
                <button
                  onClick={() => onDeleteVehicle(v.id)}
                  className="text-slate-400 hover:text-red-500 text-sm font-bold"
                >
                  🗑️
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Saved Places Section */}
      <div className="p-4 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-3">
        <div className="flex justify-between items-center">
          <div className="font-extrabold text-xs text-slate-900">
            📍 Saved Places
          </div>
          {currentUser && (
            <button
              onClick={() => setIsAddPlaceOpen(true)}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              + Add Place
            </button>
          )}
        </div>

        <div className="space-y-2">
          {savedPlaces.length === 0 ? (
            <div className="text-xs text-slate-400">
              No saved places. Add Home or Office for quick 1-click booking.
            </div>
          ) : (
            savedPlaces.map((p) => (
              <div
                key={p.id}
                className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex justify-between items-center text-xs"
              >
                <div>
                  <div className="font-bold text-slate-800">📍 {p.title}</div>
                  <div className="text-[10px] text-slate-500">{p.address}</div>
                </div>
                <button
                  onClick={() => onDeletePlace(p.id)}
                  className="text-slate-400 hover:text-red-500 text-sm font-bold"
                >
                  🗑️
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Platform Rules & Support */}
      <div className="p-4 bg-white border border-slate-200 rounded-3xl shadow-xs space-y-2">
        <div className="font-extrabold text-xs text-slate-900 mb-2">
          📜 Platform Rules & Support
        </div>

        <div
          onClick={() => setIsTermsOpen(true)}
          className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl cursor-pointer flex justify-between items-center text-xs text-slate-700 font-bold"
        >
          <span>🛡️ Terms of Service & Privacy Policy</span>
          <span>›</span>
        </div>

        <a
          href="https://wa.me/918668828542?text=Hello%20SafarShare%20Support"
          target="_blank"
          rel="noreferrer"
          className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl flex justify-between items-center text-xs text-slate-700 font-bold"
        >
          <span>💬 24x7 WhatsApp Help & Support (Admin)</span>
          <span>›</span>
        </a>
      </div>

      {/* Logout Button */}
      {currentUser && (
        <button
          type="button"
          onClick={onLogout}
          className="w-full py-3 bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs rounded-2xl border border-red-200 transition-all cursor-pointer"
        >
          🚪 Logout Account
        </button>
      )}

      {/* Modals */}
      <EditProfileModal
        isOpen={isEditProfileOpen}
        currentUser={currentUser}
        onSave={onUpdateProfile}
        onClose={() => setIsEditProfileOpen(false)}
      />

      <AddVehicleModal
        isOpen={isAddVehicleOpen}
        onAdd={onAddVehicle}
        onClose={() => setIsAddVehicleOpen(false)}
      />

      <AddSavedPlaceModal
        isOpen={isAddPlaceOpen}
        onAdd={onAddPlace}
        onClose={() => setIsAddPlaceOpen(false)}
      />

      <TermsModal
        isOpen={isTermsOpen}
        onClose={() => setIsTermsOpen(false)}
      />

      <DeepInspectModal
        isOpen={Boolean(inspectUser)}
        user={inspectUser}
        userTrips={trips.filter((t) => t.driverUid === inspectUser?.uid)}
        userBookings={requests.filter(
          (q) => q.passengerUid === inspectUser?.uid || q.driverUid === inspectUser?.uid
        )}
        onClose={() => setInspectUser(null)}
      />

      <AdminGarageModal
        isOpen={Boolean(garageKycUser)}
        user={garageKycUser}
        vehicles={vehicles.filter((v) => v.userUid === garageKycUser?.uid)}
        onApprove={onApproveVehicleKYC}
        onRejectAndSuspend={onRejectVehicleKYC}
        onClose={() => setGarageKycUser(null)}
      />

      <AdminTripDetailsModal
        isOpen={Boolean(selectedAdminTrip)}
        trip={selectedAdminTrip}
        tripRequests={requests.filter((q) => q.rideId === selectedAdminTrip?.id)}
        onForceCancel={onForceCancelTrip}
        onClose={() => setSelectedAdminTrip(null)}
      />

      <SponsoredAdsModal
        isOpen={isAdsModalOpen}
        ads={sponsoredAds}
        onAdd={onAddSponsoredAd}
        onDelete={onDeleteSponsoredAd}
        onClose={() => setIsAdsModalOpen(false)}
      />
    </div>
  );
};
