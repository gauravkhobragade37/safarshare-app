import React, { useState } from 'react';
import { UserProfile, RideTrip, BookingRequest } from '../../types';
import { cleanLocation, format12Hour } from '../../utils/geo';
import { TripProgressBar } from '../common/TripProgressBar';
import { calculateETA } from '../../utils/tripProgress';

interface ActivityTabProps {
  currentUser: UserProfile | null;
  trips: RideTrip[];
  requests: BookingRequest[];
  onAcceptRequest: (request: BookingRequest) => Promise<void>;
  onRejectRequest: (requestId: string) => Promise<void>;
  onCancelRequest: (requestId: string) => Promise<void>;
  onCancelTrip: (rideId: string) => Promise<void>;
  onDriverReOffer: (requestId: string, newPrice: number) => Promise<void>;
  onVerifyStartPin: (request: BookingRequest) => void;
  onVerifyDropPin: (request: BookingRequest) => void;
  onOpenChat: (request: BookingRequest) => void;
  onOpenRating: (request: BookingRequest) => void;
  onOpenEditTrip: (trip: RideTrip) => void;
  onTriggerSOS: (request: BookingRequest) => void;
  onReportUser: (targetUid: string, targetName: string, requestId: string) => void;
  onShowToast: (msg: string) => void;
}

export const ActivityTab: React.FC<ActivityTabProps> = ({
  currentUser,
  trips,
  requests,
  onAcceptRequest,
  onRejectRequest,
  onCancelRequest,
  onCancelTrip,
  onDriverReOffer,
  onVerifyStartPin,
  onVerifyDropPin,
  onOpenChat,
  onOpenRating,
  onOpenEditTrip,
  onTriggerSOS,
  onReportUser,
  onShowToast
}) => {
  const [subTab, setSubTab] = useState<'active' | 'pending' | 'history'>('active');
  const [expandedTrackingId, setExpandedTrackingId] = useState<string | null>(null);

  if (!currentUser) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center text-slate-500">
        <div className="text-4xl mb-2">👤</div>
        <h3 className="text-sm font-extrabold text-slate-800 mb-1">Login Required</h3>
        <p className="text-xs max-w-xs">
          Please login to view your active trips, passenger requests, and delivery history.
        </p>
      </div>
    );
  }

  // Filter items based on subTab
  const myTrips = trips.filter((t) => t.driverUid === currentUser.uid);
  const myRequests = requests.filter(
    (q) => q.passengerUid === currentUser.uid || q.driverUid === currentUser.uid
  );

  const activeTrips = myTrips.filter((t) => t.status === 'Active');
  const activeRequests = myRequests.filter((q) =>
    ['Accepted', 'Confirmed', 'In-Transit'].includes(q.status)
  );

  const pendingRequests = myRequests.filter((q) =>
    ['Pending', 'Counter Offered', 'Countered_By_Driver'].includes(q.status)
  );

  const historyTrips = myTrips.filter((t) => ['Completed', 'Cancelled'].includes(t.status));
  const historyRequests = myRequests.filter((q) =>
    ['Completed', 'Cancelled', 'Rejected'].includes(q.status)
  );

  const shareTripWhatsApp = (t: RideTrip) => {
    const text = `🚗 *SafarShare Trip Update!*\n📍 *From:* ${cleanLocation(t.from)}\n🎯 *To:* ${cleanLocation(t.to)}\n📅 *Date:* ${t.date} • ⏰ *Time:* ${format12Hour(t.time)}\n🚘 *Vehicle:* ${t.vehicle} (${t.carNumber || ''})\n💺 *Available Seats:* ${t.seats} | ₹${t.seatPrice}/seat\n👉 Book directly on SafarShare!`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const shareLiveTrackingWhatsApp = (q: BookingRequest) => {
    const text = `🚗 *My SafarShare Ride is LIVE!*\n📍 Route: ${cleanLocation(q.from)} ➔ ${cleanLocation(q.to)}\n👤 Driver: ${q.driverName} • 📞 ${q.driverPhone || 'N/A'}\n_Sharing this for safety with family!_`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="h-full overflow-y-auto p-4 pb-24 space-y-4 max-w-2xl mx-auto">
      {/* Sub-tabs header */}
      <div className="flex bg-slate-200 p-1 rounded-2xl">
        <button
          type="button"
          onClick={() => setSubTab('active')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
            subTab === 'active' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          🟢 Active ({activeTrips.length + activeRequests.length})
        </button>
        <button
          type="button"
          onClick={() => setSubTab('pending')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
            subTab === 'pending' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          ⏳ Pending ({pendingRequests.length})
        </button>
        <button
          type="button"
          onClick={() => setSubTab('history')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
            subTab === 'history' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          📜 History
        </button>
      </div>

      {/* ACTIVE TAB CONTENT */}
      {subTab === 'active' && (
        <div className="space-y-3">
          {activeTrips.length === 0 && activeRequests.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs">
              No active trips or in-progress bookings.
            </div>
          )}

          {/* Active Trips Posted by Me */}
          {activeTrips.map((t) => {
            const bookingsOnTrip = requests.filter((q) => q.rideId === t.id);
            const hasActiveBooking = bookingsOnTrip.some((q) =>
              ['Accepted', 'Confirmed', 'In-Transit'].includes(q.status)
            );
            const eta = calculateETA(t.date, t.time, t.routeDurationMin, t.routeDistanceKm);

            return (
              <div
                key={t.id}
                className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-3"
              >
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                    <span>🚗 My Posted Trip</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                      🏁 ETA {eta.arrivalTime12}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      Active
                    </span>
                  </div>
                </div>

                {/* Trip Progressive Bar */}
                <TripProgressBar
                  from={cleanLocation(t.from)}
                  to={cleanLocation(t.to)}
                  date={t.date}
                  time={t.time}
                  vehicle={t.vehicle}
                  routeDistanceKm={t.routeDistanceKm}
                  routeDurationMin={t.routeDurationMin}
                  tripStarted={t.tripStarted}
                />

                <div className="text-[11px] text-slate-500 font-medium">
                  📅 {t.date} • ⏰ {format12Hour(t.time)} | 🚘 {t.vehicle} • 💺 {t.seats} seats left
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => shareTripWhatsApp(t)}
                    className="flex-1 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1"
                  >
                    <span>💬 Share WhatsApp</span>
                  </button>

                  {!hasActiveBooking && (
                    <button
                      type="button"
                      onClick={() => onOpenEditTrip(t)}
                      className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                    >
                      ✏️ Edit
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => onCancelTrip(t.id)}
                    className="py-2 px-3 bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs rounded-xl border border-red-200 transition-all cursor-pointer"
                  >
                    🚫 Cancel
                  </button>
                </div>
              </div>
            );
          })}

          {/* Active Booking Requests */}
          {activeRequests.map((q) => {
            const isDriver = q.driverUid === currentUser.uid;
            const otherName = isDriver ? q.passengerName : q.driverName;
            const otherPhone = isDriver ? q.passengerPhone : q.driverPhone;

            return (
              <div
                key={q.id}
                className="p-4 bg-white border-l-4 border-l-emerald-500 border border-slate-200 rounded-2xl shadow-xs space-y-3"
              >
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-xs text-slate-900">
                    {q.type === 'passenger' ? `🧑 Seat Booking (${q.numSeats || 1})` : `📦 Parcel Delivery`}
                  </span>
                  <span className="text-[10.5px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {q.status}
                  </span>
                </div>

                <div className="relative pl-5 py-1 text-xs border-l-2 border-slate-200 ml-2 space-y-1.5">
                  <div className="font-bold text-slate-800">{cleanLocation(q.from)}</div>
                  <div className="font-bold text-slate-800">{cleanLocation(q.to)}</div>
                </div>

                {/* Receiver Info for Parcel */}
                {isDriver && q.type === 'parcel' && q.recName && (
                  <div className="text-xs bg-teal-50 border border-teal-200 p-2 rounded-xl text-teal-900">
                    📦 <b>Receiver:</b> {q.recName} • 📞 {q.recPhone || 'N/A'}
                  </div>
                )}

                <div className="text-xs text-slate-600">
                  👤 <b>{otherName}</b> • 💰 <b>Fare: ₹{q.currentPrice}</b> ({q.paymentMode || 'Cash'})
                </div>

                {/* Progress bar for confirmed and in-transit trips */}
                {['Confirmed', 'In-Transit', 'Accepted'].includes(q.status) && (
                  <TripProgressBar
                    from={cleanLocation(q.from)}
                    to={cleanLocation(q.to)}
                    tripStarted={q.status === 'In-Transit'}
                    className="my-1"
                  />
                )}

                {/* PIN and Live Tracking Controls */}
                {q.status === 'Confirmed' && (
                  <div className="p-3 bg-slate-900 text-white rounded-2xl text-center space-y-2">
                    {!isDriver ? (
                      <div>
                        <div className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                          YOUR START PIN (Show to Driver)
                        </div>
                        <div className="text-2xl font-black tracking-widest text-emerald-400">
                          {q.startOtp}
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onVerifyStartPin(q)}
                        className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer"
                      >
                        🔑 Enter Passenger START PIN
                      </button>
                    )}
                  </div>
                )}

                {q.status === 'In-Transit' && (
                  <div className="space-y-2">
                    <div className="p-3 bg-emerald-900 text-white rounded-2xl text-center space-y-2">
                      {!isDriver ? (
                        <div>
                          <div className="text-[9px] text-emerald-200 font-bold uppercase tracking-wider">
                            YOUR DROP PIN (Show at Destination)
                          </div>
                          <div className="text-2xl font-black tracking-widest text-white">
                            {q.dropOtp}
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onVerifyDropPin(q)}
                          className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs rounded-xl shadow-md cursor-pointer"
                        >
                          🏁 Enter Passenger DROP PIN
                        </button>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setExpandedTrackingId(expandedTrackingId === q.id ? null : q.id)}
                        className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-200 cursor-pointer"
                      >
                        📍 {expandedTrackingId === q.id ? 'Hide Live Map' : 'Track Live on Map'}
                      </button>

                      <button
                        type="button"
                        onClick={() => onTriggerSOS(q)}
                        className="py-2 px-3 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-xs cursor-pointer"
                      >
                        🚨 SOS
                      </button>
                    </div>

                    {!isDriver && (
                      <button
                        type="button"
                        onClick={() => shareLiveTrackingWhatsApp(q)}
                        className="w-full py-2 bg-emerald-500 text-white font-bold text-xs rounded-xl"
                      >
                        📲 Share Live Trip with Family
                      </button>
                    )}
                  </div>
                )}

                {/* Call, Navigate, Chat Actions */}
                <div className="flex flex-wrap gap-2 pt-1 border-t border-slate-100">
                  {otherPhone && otherPhone !== 'N/A' && (
                    <a
                      href={`tel:${otherPhone}`}
                      className="flex-1 py-2 bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold rounded-xl text-center"
                    >
                      📞 Call {otherName.split(' ')[0]}
                    </a>
                  )}

                  {isDriver && (
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
                        cleanLocation(q.status === 'In-Transit' ? q.to : q.from)
                      )}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl text-center"
                    >
                      🧭 {q.status === 'In-Transit' ? 'Nav to Drop' : 'Nav to Pickup'}
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => onOpenChat(q)}
                    className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    💬 Chat
                  </button>

                  <button
                    type="button"
                    onClick={() => onReportUser(isDriver ? q.passengerUid : q.driverUid, otherName, q.id)}
                    className="py-2 px-2.5 text-slate-400 hover:text-red-600 text-xs font-bold cursor-pointer"
                  >
                    ⚠️ Report
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* PENDING TAB CONTENT */}
      {subTab === 'pending' && (
        <div className="space-y-3">
          {pendingRequests.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs">
              No pending requests.
            </div>
          )}

          {pendingRequests.map((q) => {
            const isDriver = q.driverUid === currentUser.uid;
            const otherName = isDriver ? q.passengerName : q.driverName;

            return (
              <div
                key={q.id}
                className="p-4 bg-white border-l-4 border-l-amber-500 border border-slate-200 rounded-2xl shadow-xs space-y-2.5"
              >
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-xs text-slate-900">
                    {q.type === 'passenger' ? `🧑 Seat Request (${q.numSeats || 1})` : `📦 Parcel Request`}
                  </span>
                  <span className="text-[10.5px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                    {q.status}
                  </span>
                </div>

                <div className="relative pl-5 py-1 text-xs border-l-2 border-slate-200 ml-2 space-y-1">
                  <div className="font-bold text-slate-800">{cleanLocation(q.from)}</div>
                  <div className="font-bold text-slate-800">{cleanLocation(q.to)}</div>
                </div>

                <div className="text-xs text-slate-600">
                  👤 <b>{otherName}</b> • 💰 <b>Offer Fare: ₹{q.currentPrice}</b>
                </div>

                {/* Driver Action Buttons */}
                {isDriver ? (
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => onAcceptRequest(q)}
                      className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer"
                    >
                      ✅ Accept Request
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const val = prompt('Enter your counter re-offer price (₹):', String(q.currentPrice));
                        if (val && !isNaN(Number(val)) && Number(val) > 0) {
                          onDriverReOffer(q.id, Number(val));
                        }
                      }}
                      className="py-2.5 px-3 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                    >
                      🔄 Re-offer
                    </button>

                    <button
                      type="button"
                      onClick={() => onRejectRequest(q.id)}
                      className="py-2.5 px-3 bg-red-100 hover:bg-red-200 text-red-700 font-bold text-xs rounded-xl cursor-pointer"
                    >
                      ❌ Reject
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2 pt-1 items-center">
                    {q.status === 'Countered_By_Driver' ? (
                      <button
                        type="button"
                        onClick={() => onAcceptRequest(q)}
                        className="flex-1 py-2 bg-emerald-600 text-white font-extrabold text-xs rounded-xl"
                      >
                        ✅ Accept Driver Counter ₹{q.price || q.currentPrice}
                      </button>
                    ) : (
                      <span className="text-xs text-amber-700 font-bold">
                        ⏳ Waiting for driver to accept...
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => onCancelRequest(q.id)}
                      className="py-2 px-3 bg-red-50 text-red-600 font-bold text-xs rounded-xl border border-red-200 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* HISTORY TAB CONTENT */}
      {subTab === 'history' && (
        <div className="space-y-3">
          {historyTrips.length === 0 && historyRequests.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs">
              No historical trips or bookings.
            </div>
          )}

          {historyRequests.map((q) => {
            const isDriver = q.driverUid === currentUser.uid;
            const otherName = isDriver ? q.passengerName : q.driverName;
            const alreadyRated = isDriver ? q.driverRated : q.passengerRated;

            return (
              <div
                key={q.id}
                className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-2"
              >
                <div className="flex justify-between items-center">
                  <span className="font-extrabold text-xs text-slate-800">
                    {q.type === 'passenger' ? 'Seat Booking' : 'Parcel Delivery'}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    q.status === 'Completed' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {q.status}
                  </span>
                </div>

                <div className="text-xs font-bold text-slate-700">
                  {cleanLocation(q.from)} ➔ {cleanLocation(q.to)}
                </div>

                <div className="text-xs text-slate-500">
                  With {otherName} • Fare: ₹{q.currentPrice}
                </div>

                {q.status === 'Completed' && !alreadyRated && (
                  <button
                    type="button"
                    onClick={() => onOpenRating(q)}
                    className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs rounded-xl mt-1 cursor-pointer"
                  >
                    ⭐ Rate {otherName.split(' ')[0]}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
