import React, { useState, useEffect } from 'react';
import { MapView } from '../MapView';
import { RideTrip, ParcelSlab, UserProfile } from '../../types';
import {
  autocompletePlaces,
  reverseGeocode,
  cleanLocation,
  checkCorridorMatch,
  fetchRoutesBetweenPoints
} from '../../utils/geo';

interface ParcelTabProps {
  currentUser: UserProfile | null;
  rides: RideTrip[];
  isActive: boolean;
  onSendParcel: (
    ride: RideTrip,
    slab: ParcelSlab,
    price: number,
    recName: string,
    recPhone: string,
    paymentMode: string
  ) => Promise<void>;
  onShowToast: (msg: string) => void;
  onRequestLogin: () => void;
}

export const ParcelTab: React.FC<ParcelTabProps> = ({
  currentUser,
  rides,
  isActive,
  onSendParcel,
  onShowToast,
  onRequestLogin
}) => {
  const [pickup, setPickup] = useState({ lat: 21.4588, lng: 80.1961, text: '' });
  const [drop, setDrop] = useState({ lat: 21.5588, lng: 80.3961, text: '' });
  const [radarMode, setRadarMode] = useState<'intercity' | 'local'>('intercity');
  const [snapState, setSnapState] = useState<'collapsed' | 'half' | 'expanded'>('half');

  const [fromQuery, setFromQuery] = useState('');
  const [toQuery, setToQuery] = useState('');
  const [fromSuggestions, setFromSuggestions] = useState<any[]>([]);
  const [toSuggestions, setToSuggestions] = useState<any[]>([]);

  const [selectedSlab, setSelectedSlab] = useState<ParcelSlab>('bag');
  const [recName, setRecName] = useState('');
  const [recPhone, setRecPhone] = useState('');
  const [payMode, setPayMode] = useState<'sender_paid' | 'receiver_cod'>('sender_paid');
  const [dateTime, setDateTime] = useState('');

  const [searchResults, setSearchResults] = useState<Array<RideTrip & { price: number }>>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [routeCoordinates, setRouteCoordinates] = useState<[number, number][]>([]);

  useEffect(() => {
    reverseGeocode(pickup.lat, pickup.lng).then((addr) => {
      setPickup((p) => ({ ...p, text: addr }));
      setFromQuery(addr);
    });
    reverseGeocode(drop.lat, drop.lng).then((addr) => {
      setDrop((d) => ({ ...d, text: addr }));
      setToQuery(addr);
    });
  }, []);

  useEffect(() => {
    fetchRoutesBetweenPoints(pickup, drop).then((routes) => {
      if (routes && routes.length > 0) {
        setRouteCoordinates(routes[0].coordinates);
      }
    });
  }, [pickup.lat, pickup.lng, drop.lat, drop.lng]);

  const handleGPS = () => {
    if (!navigator.geolocation) {
      onShowToast('GPS unsupported on this device');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const addr = await reverseGeocode(lat, lng);
        setPickup({ lat, lng, text: addr });
        setFromQuery(addr);
        onShowToast('📍 Live GPS Position Set!');
      },
      () => onShowToast('GPS access denied'),
      { enableHighAccuracy: true }
    );
  };

  const handleSwap = () => {
    const tempP = { ...pickup };
    const tempQ = fromQuery;
    setPickup(drop);
    setFromQuery(toQuery);
    setDrop(tempP);
    setToQuery(tempQ);
    onShowToast('🔄 Pickup and Delivery Swapped!');
  };

  const handleFindTransporters = () => {
    if (!fromQuery.trim() || !toQuery.trim()) {
      onShowToast('❌ Enter Pickup and Delivery locations!');
      return;
    }
    if (!recName.trim() || recPhone.trim().length !== 10) {
      onShowToast('❌ Enter Receiver Name & 10-digit Phone!');
      return;
    }

    setIsSearching(true);
    setHasSearched(true);
    setSnapState('expanded');

    const maxCorridorKm = radarMode === 'local' ? 2.0 : 10.0;
    const fromText = fromQuery.toLowerCase().split(',')[0].trim();
    const toText = toQuery.toLowerCase().split(',')[0].trim();

    const candidates = rides.filter((r) => {
      if (r.status !== 'Active' || !r.parcel) return false;
      if (currentUser && r.driverUid === currentUser.uid) return false;

      if (selectedSlab === 'doc' && !(r.typeDoc && Number(r.docPrice || 0) > 0)) return false;
      if (selectedSlab === 'bag' && !(r.typeBag && Number(r.bagPrice || 0) > 0)) return false;
      if (selectedSlab === 'cargo' && !(r.typeCargo && Number(r.cargoPrice || 0) > 0)) return false;
      if (selectedSlab === 'full_vehicle' && Number(r.fullVehiclePrice || 0) <= 0) return false;

      return true;
    });

    const matched: Array<RideTrip & { price: number }> = [];

    candidates.forEach((r) => {
      let isMatch = false;
      if (r.geometry) {
        const res = checkCorridorMatch(pickup, drop, r.geometry, maxCorridorKm);
        if (res.isMatch) isMatch = true;
      }
      if (!isMatch) {
        const tripFrom = (r.from || '').toLowerCase();
        const tripTo = (r.to || '').toLowerCase();
        if (tripFrom.includes(fromText) && tripTo.includes(toText)) {
          isMatch = true;
        }
      }

      if (isMatch) {
        const price =
          selectedSlab === 'doc'
            ? r.docPrice || 60
            : selectedSlab === 'bag'
            ? r.bagPrice || 100
            : selectedSlab === 'cargo'
            ? r.cargoPrice || 150
            : r.fullVehiclePrice || 800;

        matched.push({ ...r, price });
      }
    });

    setTimeout(() => {
      setSearchResults(matched);
      setIsSearching(false);
    }, 200);
  };

  return (
    <div className="relative w-full h-full overflow-hidden">
      <MapView
        mapId="parcelMap"
        pickupCoords={pickup}
        dropCoords={drop}
        onPickupChange={(coords) => {
          setPickup((p) => ({ ...p, ...coords }));
          reverseGeocode(coords.lat, coords.lng).then((addr) => {
            setPickup((p) => ({ ...p, text: addr }));
            setFromQuery(addr);
          });
        }}
        onDropChange={(coords) => {
          setDrop((d) => ({ ...d, ...coords }));
          reverseGeocode(coords.lat, coords.lng).then((addr) => {
            setDrop((d) => ({ ...d, text: addr }));
            setToQuery(addr);
          });
        }}
        routeCoordinates={routeCoordinates}
        radarMode={radarMode}
        onToggleRadar={() => {
          setRadarMode((m) => (m === 'intercity' ? 'local' : 'intercity'));
          onShowToast(
            `Radar: ${radarMode === 'intercity' ? '🛵 Local (2 KM)' : '🚗 Intercity (10 KM)'}`
          );
        }}
        onTriggerGPS={handleGPS}
        isActiveTab={isActive}
      />

      {/* Bottom Sheet */}
      <div
        className={`absolute left-0 right-0 bottom-0 bg-white rounded-t-3xl shadow-2xl z-[500] flex flex-col transition-all duration-300 ${
          snapState === 'collapsed'
            ? 'h-[16%]'
            : snapState === 'expanded'
            ? 'h-[88%]'
            : 'h-[54%]'
        }`}
      >
        <div
          onClick={() => {
            setSnapState((s) => (s === 'collapsed' ? 'half' : s === 'half' ? 'expanded' : 'half'));
          }}
          className="w-full py-2.5 flex justify-center items-center cursor-pointer select-none"
        >
          <div className="w-11 h-1 bg-slate-300 rounded-full" />
        </div>

        <div className="flex-1 px-4 pb-20 overflow-y-auto no-scrollbar">
          {/* Pickup Input */}
          <div className="relative mb-2">
            <div className="flex items-center gap-1.5 bg-slate-100 focus-within:bg-white border focus-within:border-blue-500 rounded-xl px-2.5 py-2 transition-all">
              <span className="text-emerald-600 text-xs">●</span>
              <input
                type="text"
                value={fromQuery}
                onChange={async (e) => {
                  setFromQuery(e.target.value);
                  if (e.target.value.length >= 2) {
                    const list = await autocompletePlaces(e.target.value);
                    setFromSuggestions(list);
                  }
                }}
                placeholder="Pickup Area (GPS Enabled)"
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
              {fromQuery && (
                <button
                  onClick={() => { setFromQuery(''); setFromSuggestions([]); }}
                  className="text-slate-400 text-xs px-1"
                >
                  ✕
                </button>
              )}
              <button
                onClick={() => setSnapState('collapsed')}
                className="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-1 rounded-md"
              >
                📍 Map
              </button>
            </div>

            {fromSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl mt-1 z-50 overflow-hidden">
                {fromSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setPickup({ lat: item.lat, lng: item.lon, text: item.cleanName });
                      setFromQuery(item.cleanName);
                      setFromSuggestions([]);
                    }}
                    className="p-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
                  >
                    📍 {item.cleanName}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Delivery Row */}
          <div className="flex items-center gap-1.5 mb-2 relative">
            <div className="flex-1 flex items-center gap-1.5 bg-slate-100 focus-within:bg-white border focus-within:border-blue-500 rounded-xl px-2.5 py-2 transition-all">
              <span className="text-red-500 text-xs">◼</span>
              <input
                type="text"
                value={toQuery}
                onChange={async (e) => {
                  setToQuery(e.target.value);
                  if (e.target.value.length >= 2) {
                    const list = await autocompletePlaces(e.target.value);
                    setToSuggestions(list);
                  }
                }}
                placeholder="Delivery Area / Landmark..."
                className="w-full text-xs font-semibold bg-transparent outline-none text-slate-800"
              />
              {toQuery && (
                <button
                  onClick={() => { setToQuery(''); setToSuggestions([]); }}
                  className="text-slate-400 text-xs px-1"
                >
                  ✕
                </button>
              )}
              <button
                onClick={() => setSnapState('collapsed')}
                className="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-1 rounded-md"
              >
                📍 Map
              </button>
            </div>

            <button
              onClick={handleSwap}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0"
            >
              ⇄
            </button>

            {toSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl mt-1 z-50 overflow-hidden">
                {toSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setDrop({ lat: item.lat, lng: item.lon, text: item.cleanName });
                      setToQuery(item.cleanName);
                      setToSuggestions([]);
                    }}
                    className="p-2 text-xs font-semibold text-slate-700 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
                  >
                    📍 {item.cleanName}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 4-Slab Grid */}
          <div className="grid grid-cols-4 gap-1.5 mb-2.5">
            {[
              { key: 'doc' as ParcelSlab, icon: '📄', title: 'Document', price: '₹60' },
              { key: 'bag' as ParcelSlab, icon: '🎒', title: 'Box ≤5kg', price: '₹100' },
              { key: 'cargo' as ParcelSlab, icon: '📦', title: 'Cargo >5kg', price: '₹150' },
              { key: 'full_vehicle' as ParcelSlab, icon: '🚛', title: 'Full Space', price: 'Bulk' }
            ].map((slab) => {
              const isSelected = selectedSlab === slab.key;
              return (
                <div
                  key={slab.key}
                  onClick={() => setSelectedSlab(slab.key)}
                  className={`p-2 rounded-xl border text-center cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-50 border-blue-600 shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="text-base">{slab.icon}</div>
                  <div className="text-[9.5px] font-bold text-slate-800 truncate">{slab.title}</div>
                  <div className="text-[10.5px] font-black text-blue-600">{slab.price}</div>
                </div>
              );
            })}
          </div>

          {/* Receiver Info */}
          <div className="grid grid-cols-2 gap-1.5 mb-2">
            <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <span className="text-xs">👤</span>
              <input
                type="text"
                value={recName}
                onChange={(e) => setRecName(e.target.value)}
                placeholder="Receiver Name *"
                className="w-full text-xs font-semibold bg-transparent outline-none"
              />
            </div>
            <div className="flex items-center gap-1.5 bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <span className="text-xs">📞</span>
              <input
                type="tel"
                maxLength={10}
                value={recPhone}
                onChange={(e) => setRecPhone(e.target.value.replace(/\D/g, ''))}
                placeholder="Receiver Mobile *"
                className="w-full text-xs font-semibold bg-transparent outline-none"
              />
            </div>
          </div>

          {/* Schedule & Pay Mode Grid */}
          <div className="grid grid-cols-2 gap-1.5 mb-3">
            <label className="relative flex items-center justify-center gap-1 py-2 px-2 bg-slate-900 text-white rounded-xl text-[11px] font-bold cursor-pointer select-none truncate">
              <span>📅</span>
              <span className="truncate">{dateTime ? dateTime.replace('T', ' ') : 'Today, Now'}</span>
              <input
                type="datetime-local"
                value={dateTime}
                onChange={(e) => setDateTime(e.target.value)}
                className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
              />
            </label>

            <button
              type="button"
              onClick={() => setPayMode(payMode === 'sender_paid' ? 'receiver_cod' : 'sender_paid')}
              className="py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-[11px] font-bold border border-slate-200 truncate cursor-pointer"
            >
              {payMode === 'sender_paid' ? '📦 Paid by Sender' : '🚚 COD (Pay on Drop)'}
            </button>
          </div>

          {/* Search Button */}
          <button
            type="button"
            onClick={handleFindTransporters}
            disabled={isSearching}
            className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-600 text-white rounded-xl font-extrabold text-sm shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            {isSearching ? (
              <span>⏳ Scanning Logistics Transporters...</span>
            ) : (
              <span>Find Transporters →</span>
            )}
          </button>

          {/* Results */}
          <div className="mt-3 space-y-3">
            {hasSearched && searchResults.length === 0 && !isSearching && (
              <div className="text-center py-8 px-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="text-3xl mb-2">📦</div>
                <h4 className="text-sm font-extrabold text-slate-800 mb-1">
                  No Transporters Available
                </h4>
                <p className="text-xs text-slate-500">
                  No active drivers accepting {selectedSlab} along this route right now.
                </p>
              </div>
            )}

            {searchResults.map((r) => (
              <div
                key={r.id}
                className="p-3.5 bg-white border border-slate-200 rounded-2xl shadow-xs space-y-2.5"
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={r.driverDp || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'}
                      alt={r.driverName}
                      className="w-10 h-10 rounded-full object-cover border-2 border-blue-600 shrink-0"
                    />
                    <div>
                      <div className="text-xs font-black text-slate-900">{r.driverName}</div>
                      <div className="text-[10px] text-slate-500 font-semibold">
                        {r.vehicle} ({r.carNumber || 'Verified'})
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-base font-black text-emerald-600">₹{r.price}</div>
                    <div className="text-[9.5px] text-slate-400 font-bold">Standard Rate</div>
                  </div>
                </div>

                <div className="relative pl-5 py-1 text-xs border-l-2 border-slate-200 ml-2 space-y-1.5">
                  <div className="font-bold text-slate-800">{cleanLocation(r.from)}</div>
                  <div className="font-bold text-slate-800">{cleanLocation(r.to)}</div>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (!currentUser) {
                        onRequestLogin();
                        return;
                      }
                      onSendParcel(r, selectedSlab, r.price, recName, recPhone, payMode);
                    }}
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow-xs cursor-pointer"
                  >
                    📦 Book Transporter • ₹{r.price}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
