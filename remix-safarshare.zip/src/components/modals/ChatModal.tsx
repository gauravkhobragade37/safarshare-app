import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, UserProfile } from '../../types';
import { auth, db, collection, query, orderBy, onSnapshot, addDoc, doc, updateDoc } from '../../firebase';

interface ChatModalProps {
  isOpen: boolean;
  requestId: string | null;
  otherName: string;
  otherPhone?: string;
  currentUser: UserProfile | null;
  isReadOnly?: boolean;
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  requestId,
  otherName,
  otherPhone,
  currentUser,
  isReadOnly = false,
  onClose
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!isOpen || !requestId) {
      setMessages([]);
      return;
    }

    // Try loading local cached messages first
    try {
      const cached = localStorage.getItem(`safar_chat_${requestId}`);
      if (cached) {
        setMessages(JSON.parse(cached));
      }
    } catch {
      // Ignored
    }

    if (!auth.currentUser) {
      return;
    }

    const chatCol = collection(db, 'requests', requestId, 'messages');
    const q = query(chatCol, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const msgs = snapshot.docs.map((docSnap) => ({
          id: docSnap.id,
          ...(docSnap.data() as Omit<ChatMessage, 'id'>)
        }));
        setMessages(msgs);
        try {
          localStorage.setItem(`safar_chat_${requestId}`, JSON.stringify(msgs));
        } catch {
          // Ignored
        }
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      },
      (err) => {
        console.warn('Chat snapshot handled:', err.message);
      }
    );

    return () => unsubscribe();
  }, [isOpen, requestId]);

  if (!isOpen || !requestId) return null;

  const handleSend = async () => {
    if (!inputText.trim() || !currentUser || isReadOnly || isSending) return;
    const text = inputText.trim();
    setInputText('');
    setIsSending(true);

    const newMsgObj: ChatMessage = {
      id: 'local-msg-' + Date.now(),
      text,
      senderUid: currentUser.uid,
      senderName: currentUser.name || 'User',
      createdAt: Date.now()
    };

    // Optimistically update local message state & cache
    setMessages((prev) => {
      const next = [...prev, newMsgObj];
      try {
        localStorage.setItem(`safar_chat_${requestId}`, JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        const chatCol = collection(db, 'requests', requestId, 'messages');
        await addDoc(chatCol, {
          text,
          senderUid: currentUser.uid,
          senderName: currentUser.name || 'User',
          createdAt: newMsgObj.createdAt
        });

        // Update parent request with last message summary
        await updateDoc(doc(db, 'requests', requestId), {
          lastMsgText: text,
          lastMsgTime: Date.now(),
          lastMsgSender: currentUser.uid,
          lastMsgSenderName: currentUser.name || 'User'
        });
      }
    } catch (e) {
      console.warn('Chat remote sync fallback to local:', e);
    } finally {
      setIsSending(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[10000] flex justify-center items-center p-3 animate-in fade-in">
      <div className="bg-white w-full max-w-md h-[500px] rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-blue-600 text-white px-4 py-3 flex justify-between items-center shadow-md">
          <div className="flex items-center gap-2">
            <span className="text-lg">💬</span>
            <div>
              <div className="text-xs font-black leading-tight">
                {otherName}
              </div>
              <div className="text-[10px] text-blue-100 font-semibold">
                Live In-App Chat
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {otherPhone && otherPhone !== 'N/A' && (
              <a
                href={`tel:${otherPhone}`}
                className="bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg transition-all"
              >
                📞 Call
              </a>
            )}
            <button
              onClick={onClose}
              className="text-white hover:text-blue-100 text-xl font-bold ml-1 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 p-3 overflow-y-auto bg-slate-50 flex flex-col gap-2">
          {messages.length === 0 ? (
            <div className="text-center text-slate-400 text-xs my-auto">
              No messages yet. Say hello to {otherName}! 👋
            </div>
          ) : (
            messages.map((msg) => {
              const isSentByMe = currentUser && msg.senderUid === currentUser.uid;
              return (
                <div
                  key={msg.id}
                  className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-xs shadow-xs ${
                    isSentByMe
                      ? 'bg-blue-600 text-white self-end rounded-br-xs'
                      : 'bg-white border border-slate-200 text-slate-800 self-start rounded-bl-xs'
                  }`}
                >
                  <div
                    className={`text-[9.5px] font-black mb-0.5 ${
                      isSentByMe ? 'text-blue-200' : 'text-slate-400'
                    }`}
                  >
                    {msg.senderName}
                  </div>
                  <div className="font-medium break-words leading-relaxed">
                    {msg.text}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-2.5 bg-white border-t border-slate-200 flex gap-2 items-center">
          <input
            type="text"
            value={inputText}
            disabled={isReadOnly}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            placeholder={
              isReadOnly
                ? '🔒 Chat closed - trip finished'
                : 'Write a message...'
            }
            className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-medium text-slate-800 disabled:bg-slate-100 disabled:text-slate-400"
          />
          <button
            type="button"
            onClick={handleSend}
            disabled={!inputText.trim() || isReadOnly}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};
