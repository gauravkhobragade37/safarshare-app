import React, { useState, useEffect, useRef } from 'react';

interface PinModalProps {
  isOpen: boolean;
  title: string;
  icon: string;
  onVerify: (pin: string) => Promise<void> | void;
  onClose: () => void;
}

export const PinModal: React.FC<PinModalProps> = ({
  isOpen,
  title,
  icon,
  onVerify,
  onClose
}) => {
  const [digits, setDigits] = useState(['', '', '', '']);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const inputRefs = [
    useRef<HTMLInputElement | null>(null),
    useRef<HTMLInputElement | null>(null),
    useRef<HTMLInputElement | null>(null),
    useRef<HTMLInputElement | null>(null)
  ];

  useEffect(() => {
    if (isOpen) {
      setDigits(['', '', '', '']);
      setIsSubmitting(false);
      setTimeout(() => inputRefs[0].current?.focus(), 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleInputChange = (index: number, val: string) => {
    const clean = val.replace(/\D/g, '').slice(-1);
    const newDigits = [...digits];
    newDigits[index] = clean;
    setDigits(newDigits);

    if (clean && index < 3) {
      inputRefs[index + 1].current?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs[index - 1].current?.focus();
    }
  };

  const handleSubmit = async () => {
    const pin = digits.join('');
    if (pin.length !== 4) return;
    setIsSubmitting(true);
    try {
      await onVerify(pin);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-[10000] flex justify-center items-center p-4 animate-in fade-in">
      <div className="bg-slate-900 text-white w-full max-w-sm rounded-3xl p-6 text-center shadow-2xl border border-slate-700">
        <div className="text-4xl mb-2">{icon}</div>
        <h3 className="text-base font-bold mb-1">{title}</h3>
        <p className="text-xs text-slate-400 mb-4">
          Ask the passenger/receiver for their 4-digit code
        </p>

        <div className="flex justify-center gap-3 my-4">
          {digits.map((digit, idx) => (
            <input
              key={idx}
              ref={inputRefs[idx]}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleInputChange(idx, e.target.value)}
              onKeyDown={(e) => handleKeyDown(idx, e)}
              className="w-12 h-14 text-2xl font-extrabold text-center bg-slate-800 border-2 border-slate-600 focus:border-blue-500 rounded-xl text-white outline-none transition-all"
            />
          ))}
        </div>

        <div className="flex gap-3 mt-5">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl border border-slate-700 transition-all cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={digits.join('').length !== 4 || isSubmitting}
            className="flex-1 py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all cursor-pointer"
          >
            {isSubmitting ? 'Verifying...' : 'Verify Code'}
          </button>
        </div>
      </div>
    </div>
  );
};
