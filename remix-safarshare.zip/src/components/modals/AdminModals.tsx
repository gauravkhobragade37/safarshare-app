import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, UserVehicle, RideTrip, BookingRequest, SponsoredAd } from '../../types';
import { cleanLocation, format12Hour } from '../../utils/geo';
import L from 'leaflet';

// 🔍 Deep Inspect User Modal
export const DeepInspectModal: React.FC<{
  isOpen: boolean;
  user: UserProfile | null;
  userTrips: RideTrip[];
  userBookings: BookingRequest[];
  onClose: () => void;
}> = ({ isOpen, user, userTrips, userBookings, onClose }) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!isOpen || !mapContainerRef.current) return;

    const timer = setTimeout(() => {
      if (!mapContainerRef.current) return;
      if (!mapInstanceRef.current) {
        mapInstanceRef.current = L.map(mapContainerRef.current, {
          zoomControl: false,
          attributionControl: false
        }).setView([21.4588, 80.1961], 11);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 18
        }).addTo(mapInstanceRef.current);
      } else {
        mapInstanceRef.current.invalidateSize();
      }

      // Draw polyline of active trip if available
      const active = userTrips.find((t) => t.status === 'Active') || userTrips[0];
      if (active && active.geometry && mapInstanceRef.current) {
        try {
          const geom = typeof active.geometry === 'string' ? JSON.parse(active.geometry) : active.geometry;
          if (geom.coordinates) {
            const latlngs = geom.coordinates.map((c: any) => [c[1], c[0]]);
            const poly = L.polyline(latlngs, { color: '#1261ff', weight: 5 }).addTo(mapInstanceRef.current);
            mapInstanceRef.current.fitBounds(poly.getBounds(), { padding: [20, 20] });
          }
        } catch {
          // Ignored
        }
      }
    }, 150);

    return () => {
      clearTimeout(timer);
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [isOpen, userTrips]);

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">
            🔍 User Inspection: {user.name}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div><b>Email:</b> {user.email}</div>
            <div><b>Phone:</b> {user.phone ? `+91 ${user.phone}` : 'None'}</div>
            <div><b>Role:</b> {user.role} {user.isBlocked ? '(BLOCKED)' : '(Active)'}</div>
          </div>

          <div ref={mapContainerRef} className="w-full h-44 rounded-xl border border-slate-200 overflow-hidden" />

          <div>
            <h4 className="font-extrabold text-slate-800 mb-1.5">
              🚗 Posted Trips ({userTrips.length})
            </h4>
            {userTrips.length === 0 ? (
              <div className="text-slate-400">No trips posted.</div>
            ) : (
              <div className="space-y-1.5">
                {userTrips.map((t) => (
                  <div key={t.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <div className="font-bold">{cleanLocation(t.from)} ➔ {cleanLocation(t.to)}</div>
                    <div className="text-[11px] text-slate-500">
                      {t.vehicle} • ₹{t.seatPrice}/seat • Status: <b>{t.status}</b>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h4 className="font-extrabold text-slate-800 mb-1.5">
              📋 Bookings ({userBookings.length})
            </h4>
            {userBookings.length === 0 ? (
              <div className="text-slate-400">No bookings made.</div>
            ) : (
              <div className="space-y-1.5">
                {userBookings.map((q) => (
                  <div key={q.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <div className="font-bold">
                      {q.type === 'passenger' ? '🧑 Seat' : '📦 Parcel'}: {cleanLocation(q.from)} ➔ {cleanLocation(q.to)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Fare: ₹{q.currentPrice} • Status: <b>{q.status}</b>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// 🚘 Admin Garage & KYC Modal
export const AdminGarageModal: React.FC<{
  isOpen: boolean;
  user: UserProfile | null;
  vehicles: UserVehicle[];
  onApprove: (vehicleId: string) => Promise<void>;
  onRejectAndSuspend: (vehicleId: string, userUid: string) => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, user, vehicles, onApprove, onRejectAndSuspend, onClose }) => {
  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">
            🚘 Garage KYC: {user.name}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div><b>Email:</b> {user.email}</div>
            <div><b>Phone:</b> {user.phone ? `+91 ${user.phone}` : 'None'}</div>
            <div><b>Gender:</b> {user.gender}</div>
          </div>

          <h4 className="font-extrabold text-slate-800">
            Registered Vehicles ({vehicles.length})
          </h4>

          {vehicles.length === 0 ? (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl">
              ⚠️ No vehicles registered by this user.
            </div>
          ) : (
            <div className="space-y-2">
              {vehicles.map((v) => (
                <div
                  key={v.id}
                  className="p-3 bg-white border border-slate-200 rounded-xl shadow-xs space-y-2"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-sm text-blue-600 tracking-wider">
                      {v.plate}
                    </span>
                    <span className="text-[10.5px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                      {v.type}
                    </span>
                  </div>

                  <div className="text-slate-600">Model: <b>{v.model}</b></div>

                  <div className="flex items-center gap-2 pt-1">
                    {v.kycStatus !== 'verified' && (
                      <button
                        onClick={() => onApprove(v.id)}
                        className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs"
                      >
                        ✅ Approve KYC
                      </button>
                    )}
                    {v.kycStatus !== 'rejected' && (
                      <button
                        onClick={() => onRejectAndSuspend(v.id, user.uid)}
                        className="flex-1 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs"
                      >
                        🚫 Reject & Suspend
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// 🔍 Admin Trip Complete Details & Force Cancel Modal
export const AdminTripDetailsModal: React.FC<{
  isOpen: boolean;
  trip: RideTrip | null;
  tripRequests: BookingRequest[];
  onForceCancel: (tripId: string) => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, trip, tripRequests, onForceCancel, onClose }) => {
  if (!isOpen || !trip) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">
            🔍 Trip: {cleanLocation(trip.from)} ➔ {cleanLocation(trip.to)}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="font-bold text-slate-800 mb-1">🚘 Driver Info:</div>
            <div>Name: <b>{trip.driverName}</b></div>
            <div>
              Phone:{' '}
              <a href={`tel:${trip.driverPhone}`} className="text-blue-600 font-bold">
                {trip.driverPhone || 'N/A'}
              </a>
            </div>
            <div>Vehicle: {trip.vehicle} ({trip.carNumber || 'N/A'})</div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="font-bold text-slate-800 mb-1">🛣️ Schedule & Fare:</div>
            <div>From: {trip.from}</div>
            <div>To: {trip.to}</div>
            <div>Date: {trip.date} • Time: {format12Hour(trip.time)}</div>
            <div>Fare: ₹{trip.seatPrice}/seat • Seats left: {trip.seats}</div>
            <div>Status: <span className="font-bold text-blue-600">{trip.status}</span></div>
          </div>

          <div>
            <div className="font-bold text-slate-800 mb-1.5">
              👥 Bookings on this trip ({tripRequests.length}):
            </div>
            {tripRequests.length === 0 ? (
              <div className="text-slate-400">No bookings yet.</div>
            ) : (
              <div className="space-y-1.5">
                {tripRequests.map((q) => (
                  <div key={q.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <div className="font-bold">
                      {q.type === 'passenger' ? '🧑 Passenger' : '📦 Parcel'}: {q.passengerName} (📞 {q.passengerPhone})
                    </div>
                    <div className="text-slate-500">
                      Fare: ₹{q.currentPrice} • Status: <b>{q.status}</b>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {trip.status === 'Active' && (
            <button
              onClick={() => onForceCancel(trip.id)}
              className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
            >
              🚫 Force Cancel This Trip
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// 📢 Sponsored Ads Engine Modal
export const SponsoredAdsModal: React.FC<{
  isOpen: boolean;
  ads: SponsoredAd[];
  onAdd: (name: string, category: string, landmark: string, targetRoute: string, phone: string) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, ads, onAdd, onDelete, onClose }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Mobile & Electronics Shop');
  const [landmark, setLandmark] = useState('');
  const [targetRoute, setTargetRoute] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!name.trim() || !landmark.trim() || !phone.trim()) return;
    setLoading(true);
    try {
      await onAdd(name.trim(), category, landmark.trim(), targetRoute.trim(), phone.trim());
      setName('');
      setLandmark('');
      setTargetRoute('');
      setPhone('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">📢 Local Sponsored Ads Engine</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 space-y-2">
            <div className="font-extrabold text-amber-800 text-xs">
              ➕ Add Local Business / Sponsor Ad
            </div>

            <div>
              <label className="text-[10.5px] font-bold text-slate-700 block mb-0.5">Business Name *</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sai Mobile Store"
                className="w-full text-xs p-2 rounded-xl border border-amber-300 bg-white"
              />
            </div>

            <div>
              <label className="text-[10.5px] font-bold text-slate-700 block mb-0.5">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-xs p-2 rounded-xl border border-amber-300 bg-white"
              >
                <option value="Mobile & Electronics Shop">📱 Mobile & Electronics Shop</option>
                <option value="Restaurant & Dhaba">🍲 Restaurant & Highway Dhaba</option>
                <option value="Hotel & Stay">🏨 Hotel / Stay / Lodge</option>
                <option value="Retail & Supermarket">🛍️ Retail & Supermarket</option>
              </select>
            </div>

            <div>
              <label className="text-[10.5px] font-bold text-slate-700 block mb-0.5">Landmark *</label>
              <input
                type="text"
                value={landmark}
                onChange={(e) => setLandmark(e.target.value)}
                placeholder="e.g. Main Market Chowk, Gondia"
                className="w-full text-xs p-2 rounded-xl border border-amber-300 bg-white"
              />
            </div>

            <div>
              <label className="text-[10.5px] font-bold text-slate-700 block mb-0.5">Target Route</label>
              <input
                type="text"
                value={targetRoute}
                onChange={(e) => setTargetRoute(e.target.value)}
                placeholder="e.g. Gondia - Nagpur"
                className="w-full text-xs p-2 rounded-xl border border-amber-300 bg-white"
              />
            </div>

            <div>
              <label className="text-[10.5px] font-bold text-slate-700 block mb-0.5">Contact Phone *</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                placeholder="10-digit mobile"
                className="w-full text-xs p-2 rounded-xl border border-amber-300 bg-white"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading || !name.trim() || !landmark.trim() || !phone.trim()}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs"
            >
              {loading ? 'Publishing...' : '🚀 Publish Sponsored Ad'}
            </button>
          </div>

          <h4 className="font-extrabold text-slate-800">
            Active Sponsored Partners ({ads.length})
          </h4>

          {ads.length === 0 ? (
            <div className="text-slate-400">No sponsored ads published.</div>
          ) : (
            <div className="space-y-1.5">
              {ads.map((ad) => (
                <div
                  key={ad.id}
                  className="flex justify-between items-center p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <div>
                    <div className="font-bold text-slate-800">{ad.name}</div>
                    <div className="text-[10.5px] text-slate-500">
                      {ad.category} • 📍 {ad.landmark}
                    </div>
                  </div>
                  <button
                    onClick={() => onDelete(ad.id)}
                    className="text-red-500 hover:text-red-700 font-bold p-1 cursor-pointer"
                  >
                    🗑️
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
