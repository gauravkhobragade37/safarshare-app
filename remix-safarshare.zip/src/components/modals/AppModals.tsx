import React, { useState, useEffect } from 'react';
import { UserProfile, UserVehicle, RideTrip, BookingRequest, SponsoredAd } from '../../types';
import L from 'leaflet';

// 🧳 Luggage Modal
export const LuggageModal: React.FC<{
  isOpen: boolean;
  selectedCount: number;
  onSelect: (count: number) => void;
  onClose: () => void;
}> = ({ isOpen, selectedCount, onSelect, onClose }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-extrabold text-slate-800">
            🧳 Extra Luggage / Suitcase
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">
            ✕
          </button>
        </div>

        <div className="space-y-2">
          <div
            onClick={() => { onSelect(0); onClose(); }}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition-all ${
              selectedCount === 0 ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">🚫 No Extra Bag</div>
              <div className="text-[10.5px] text-slate-500">Standard small hand bag / backpack</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              selectedCount === 0 ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {selectedCount === 0 ? '✓' : ''}
            </div>
          </div>

          <div
            onClick={() => { onSelect(1); onClose(); }}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition-all ${
              selectedCount === 1 ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">🧳 1 Extra Suitcase / Trolley</div>
              <div className="text-[10.5px] text-slate-500">Heavy baggage cargo fee +₹50</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              selectedCount === 1 ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {selectedCount === 1 ? '✓' : ''}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// 🚗 Vehicle Category Filter Modal
export const VehicleFilterModal: React.FC<{
  isOpen: boolean;
  selectedVehicle: string;
  onSelect: (veh: string) => void;
  onClose: () => void;
}> = ({ isOpen, selectedVehicle, onSelect, onClose }) => {
  if (!isOpen) return null;
  const options = [
    { key: '', label: '🚗 Any Vehicle', sub: 'Show all available vehicles' },
    { key: 'Bike', label: '🏍️ Bike / Scooter', sub: 'Max 1 Pillion Seat' },
    { key: 'Auto', label: '🛺 Auto / E-Rickshaw', sub: 'Max 3 Seats' },
    { key: 'Car', label: '🚗 Car / Cab Pool', sub: 'Max 4 Seats' },
    { key: 'Pickup/Truck', label: '🛻 Pickup / Mini Truck', sub: 'Commercial Logistics' }
  ];

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-extrabold text-slate-800">🚗 Select Vehicle Filter</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>
        <div className="space-y-2">
          {options.map((opt) => (
            <div
              key={opt.key}
              onClick={() => { onSelect(opt.key); onClose(); }}
              className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition-all ${
                selectedVehicle === opt.key ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div>
                <div className="text-xs font-bold text-slate-800">{opt.label}</div>
                <div className="text-[10px] text-slate-500">{opt.sub}</div>
              </div>
              <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
                selectedVehicle === opt.key ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
              }`}>
                {selectedVehicle === opt.key ? '✓' : ''}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 👥 Dynamic Seats Selector Modal
export const SeatsModal: React.FC<{
  isOpen: boolean;
  selectedSeats: number;
  maxSeats?: number;
  onSelect: (seats: number) => void;
  onClose: () => void;
}> = ({ isOpen, selectedSeats, maxSeats = 4, onSelect, onClose }) => {
  if (!isOpen) return null;
  const list = Array.from({ length: maxSeats }, (_, i) => i + 1);

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-extrabold text-slate-800">👥 Number of Passenger Seats</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>
        <div className="space-y-2">
          {list.map((count) => (
            <div
              key={count}
              onClick={() => { onSelect(count); onClose(); }}
              className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition-all ${
                selectedSeats === count ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="text-xs font-bold text-slate-800">
                {count} {count === 1 ? 'Seat' : 'Seats'}
              </div>
              <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
                selectedSeats === count ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
              }`}>
                {selectedSeats === count ? '✓' : ''}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 💳 Booking Payment Mode Choice Modal
export const BookingPaymentModal: React.FC<{
  isOpen: boolean;
  onConfirm: (mode: 'cash_pickup' | 'driver_qr') => void;
  onClose: () => void;
}> = ({ isOpen, onConfirm, onClose }) => {
  const [mode, setMode] = useState<'cash_pickup' | 'driver_qr'>('cash_pickup');
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">💳 Direct Driver Settlement</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>
        <p className="text-[11px] text-slate-500 mb-3">
          SafarShare charges 0% commission. You pay the driver directly at pickup.
        </p>

        <div className="space-y-2 mb-4">
          <div
            onClick={() => setMode('cash_pickup')}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition-all ${
              mode === 'cash_pickup' ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">💵 Cash on Pickup</div>
              <div className="text-[10px] text-slate-500">Pay hard cash directly to driver</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              mode === 'cash_pickup' ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {mode === 'cash_pickup' ? '✓' : ''}
            </div>
          </div>

          <div
            onClick={() => setMode('driver_qr')}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition-all ${
              mode === 'driver_qr' ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">📱 Scan Driver UPI QR</div>
              <div className="text-[10px] text-slate-500">Pay via Google Pay, PhonePe, Paytm directly to driver</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              mode === 'driver_qr' ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {mode === 'driver_qr' ? '✓' : ''}
            </div>
          </div>
        </div>

        <button
          onClick={() => { onConfirm(mode); onClose(); }}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-md cursor-pointer transition-all"
        >
          Confirm & Send Request
        </button>
      </div>
    </div>
  );
};

// 📦 Parcel Slabs Acceptance Modal (for Drivers posting a trip)
export const ParcelSlabsModal: React.FC<{
  isOpen: boolean;
  typeDoc: boolean;
  typeBag: boolean;
  typeCargo: boolean;
  typeFull: boolean;
  onToggle: (slabKey: 'doc' | 'bag' | 'cargo' | 'full') => void;
  onClose: () => void;
}> = ({ isOpen, typeDoc, typeBag, typeCargo, typeFull, onToggle, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">📦 Accept Parcel Slabs</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>
        <p className="text-[11px] text-slate-500 mb-3">
          Earn extra fuel money by transporting verified documents & packages along your route.
        </p>

        <div className="space-y-2 mb-4">
          <div
            onClick={() => onToggle('doc')}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer ${
              typeDoc ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">📄 Small Document (≤1kg)</div>
              <div className="text-[10px] text-emerald-600 font-bold">Standard Rate: ₹60</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              typeDoc ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {typeDoc ? '✓' : ''}
            </div>
          </div>

          <div
            onClick={() => onToggle('bag')}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer ${
              typeBag ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">🎒 Medium Box (≤5kg)</div>
              <div className="text-[10px] text-emerald-600 font-bold">Standard Rate: ₹100</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              typeBag ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {typeBag ? '✓' : ''}
            </div>
          </div>

          <div
            onClick={() => onToggle('cargo')}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer ${
              typeCargo ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">📦 Cargo (&gt;5kg)</div>
              <div className="text-[10px] text-emerald-600 font-bold">Standard Rate: ₹150</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              typeCargo ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {typeCargo ? '✓' : ''}
            </div>
          </div>

          <div
            onClick={() => onToggle('full')}
            className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer ${
              typeFull ? 'bg-blue-50 border-blue-600' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-bold text-slate-800">🚛 Full Vehicle / Commercial Bulk</div>
              <div className="text-[10px] text-slate-500">Custom Driver Quote</div>
            </div>
            <div className={`w-5 h-5 rounded-md border flex items-center justify-center text-xs font-bold ${
              typeFull ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
            }`}>
              {typeFull ? '✓' : ''}
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-blue-600 text-white text-xs font-bold rounded-xl"
        >
          Done
        </button>
      </div>
    </div>
  );
};

// ✏️ Edit Profile Modal
export const EditProfileModal: React.FC<{
  isOpen: boolean;
  currentUser: UserProfile | null;
  onSave: (name: string, phone: string, gender: 'Male' | 'Female' | 'Other') => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, currentUser, onSave, onClose }) => {
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>(currentUser?.gender || 'Male');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setPhone(currentUser.phone || '');
      setGender(currentUser.gender || 'Male');
    }
  }, [currentUser]);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!name.trim()) return;
    setLoading(true);
    try {
      await onSave(name.trim(), phone.trim(), gender);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-extrabold text-slate-800">✏️ Edit Personal Details</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="space-y-3 mb-4">
          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Full Name *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full Name"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">10-Digit Mobile *</label>
            <input
              type="tel"
              maxLength={10}
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
              placeholder="e.g. 9876543210"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Gender</label>
            <select
              value={gender}
              onChange={(e) => setGender(e.target.value as any)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold bg-white"
            >
              <option value="Male">🧑 Male</option>
              <option value="Female">👩 Female</option>
              <option value="Other">⚪ Other</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading || !name.trim()}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-md cursor-pointer transition-all"
        >
          {loading ? 'Saving...' : '💾 Save Details'}
        </button>
      </div>
    </div>
  );
};

// ➕ Add Vehicle Modal
export const AddVehicleModal: React.FC<{
  isOpen: boolean;
  onAdd: (type: any, model: string, plate: string) => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, onAdd, onClose }) => {
  const [type, setType] = useState('Bike');
  const [model, setModel] = useState('');
  const [plate, setPlate] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!model.trim() || !plate.trim()) return;
    setLoading(true);
    try {
      await onAdd(type, model.trim(), plate.trim().toUpperCase());
      setModel('');
      setPlate('');
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-extrabold text-slate-800">➕ Add Vehicle to Garage</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="space-y-3 mb-4">
          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Vehicle Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold bg-white"
            >
              <option value="Bike">🏍️ Bike / Motorcycle</option>
              <option value="Car">🚗 Car (Sedan / Hatchback / SUV)</option>
              <option value="Auto">🛺 Auto / E-Rickshaw</option>
              <option value="Pickup/Truck">🛻 Pickup / Mini Truck</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Model Name *</label>
            <input
              type="text"
              value={model}
              onChange={(e) => setModel(e.target.value)}
              placeholder="e.g. Apache RTR / Swift Dzire"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Number Plate *</label>
            <input
              type="text"
              value={plate}
              onChange={(e) => setPlate(e.target.value.toUpperCase())}
              placeholder="e.g. MH35AB1234"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold uppercase tracking-wider"
            />
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading || !model.trim() || !plate.trim()}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-md cursor-pointer transition-all"
        >
          {loading ? 'Saving...' : '➕ Save Vehicle to Garage'}
        </button>
      </div>
    </div>
  );
};

// 📍 Add Saved Place Modal
export const AddSavedPlaceModal: React.FC<{
  isOpen: boolean;
  onAdd: (title: string, address: string) => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, onAdd, onClose }) => {
  const [title, setTitle] = useState('');
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!title.trim() || !address.trim()) return;
    setLoading(true);
    try {
      await onAdd(title.trim(), address.trim());
      setTitle('');
      setAddress('');
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-extrabold text-slate-800">📍 Add Saved Place</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="space-y-3 mb-4">
          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Home, Office, Gym, Campus"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 mb-1 block">Address / Landmark *</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Civil Lines, Main Road"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 font-semibold"
            />
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading || !title.trim() || !address.trim()}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-md cursor-pointer transition-all"
        >
          {loading ? 'Saving...' : '📍 Save Location'}
        </button>
      </div>
    </div>
  );
};

// ✏️ Edit Trip Modal
export const EditTripModal: React.FC<{
  isOpen: boolean;
  trip: RideTrip | null;
  onSave: (rideId: string, seats: number, price: number, date: string, time: string) => Promise<void>;
  onClose: () => void;
}> = ({ isOpen, trip, onSave, onClose }) => {
  const [seats, setSeats] = useState(trip?.seats || 3);
  const [price, setPrice] = useState(trip?.seatPrice || 150);
  const [date, setDate] = useState(trip?.date || '');
  const [time, setTime] = useState(trip?.time || '');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (trip) {
      setSeats(trip.seats || 3);
      setPrice(trip.seatPrice || 150);
      setDate(trip.date || '');
      setTime(trip.time || '');
    }
  }, [trip]);

  if (!isOpen || !trip) return null;

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await onSave(trip.id, Number(seats), Number(price), date, time);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">✏️ Edit Trip Details</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="text-xs text-slate-600 mb-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
          <div><b>From:</b> {trip.from}</div>
          <div><b>To:</b> {trip.to}</div>
        </div>

        <div className="grid grid-cols-2 gap-2.5 mb-3">
          <div>
            <label className="text-[10.5px] font-bold text-slate-600 block mb-1">Seats Left</label>
            <input
              type="number"
              min={0}
              max={6}
              value={seats}
              onChange={(e) => setSeats(Number(e.target.value))}
              className="w-full text-xs p-2 rounded-xl border border-slate-200 font-bold"
            />
          </div>
          <div>
            <label className="text-[10.5px] font-bold text-slate-600 block mb-1">Fare / Seat (₹)</label>
            <input
              type="number"
              min={10}
              value={price}
              onChange={(e) => setPrice(Number(e.target.value))}
              className="w-full text-xs p-2 rounded-xl border border-slate-200 font-bold text-blue-600"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5 mb-4">
          <div>
            <label className="text-[10.5px] font-bold text-slate-600 block mb-1">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full text-xs p-2 rounded-xl border border-slate-200 font-semibold"
            />
          </div>
          <div>
            <label className="text-[10.5px] font-bold text-slate-600 block mb-1">Time</label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full text-xs p-2 rounded-xl border border-slate-200 font-semibold"
            />
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold rounded-xl shadow-md cursor-pointer transition-all"
        >
          {loading ? 'Saving...' : '💾 Save Changes'}
        </button>
      </div>
    </div>
  );
};

// 📜 Terms & Policy Modal
export const TermsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[2000] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-extrabold text-slate-800">📜 Terms of Service & Privacy</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto text-xs text-slate-600 space-y-3 leading-relaxed pr-1">
          <p>
            <b>1. Direct Peer-to-Peer Mobility:</b> SafarShare connects verified vehicle owners, commuters, and parcel senders along shared corridors.
          </p>
          <p>
            <b>2. 100% Direct Driver Settlement:</b> SafarShare does not act as a payment intermediary or take commission cuts on driver travel fares. Settlements are completed directly via cash or UPI.
          </p>
          <p>
            <b>3. Safety & Dual-PIN Verification:</b> Passengers and senders must exchange their 4-Digit START PIN at boarding and DROP PIN at destination completion for mutual security.
          </p>
          <p>
            <b>4. Community Standards:</b> Users must carry valid government photo identification and ensure vehicles possess valid RC and insurance.
          </p>
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full py-2.5 bg-blue-600 text-white text-xs font-extrabold rounded-xl shadow-xs"
        >
          I Understand & Accept
        </button>
      </div>
    </div>
  );
};
