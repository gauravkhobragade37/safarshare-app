import React, { useState } from 'react';

interface RatingModalProps {
  isOpen: boolean;
  targetName: string;
  onSubmit: (stars: number, tags: string[], review: string) => Promise<void> | void;
  onClose: () => void;
}

export const RatingModal: React.FC<RatingModalProps> = ({
  isOpen,
  targetName,
  onSubmit,
  onClose
}) => {
  const [stars, setStars] = useState(5);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [review, setReview] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const availableTags = [
    '🛡️ Safe Driving',
    '⏰ On Time',
    '🙏 Polite',
    '✨ Clean Vehicle',
    '🐢 Late',
    '😠 Rude Behaviour'
  ];

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await onSubmit(stars, selectedTags, review);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[10000] flex justify-center items-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-sm rounded-3xl p-5 text-center shadow-2xl border border-slate-200">
        <div className="text-4xl mb-1">⭐</div>
        <h3 className="text-base font-extrabold text-slate-800">
          Rate {targetName || 'Your Experience'}
        </h3>
        <p className="text-xs text-slate-500 mb-3">
          Help build a trusted SafarShare community
        </p>

        {/* Stars */}
        <div className="flex justify-center gap-1 text-3xl my-2 cursor-pointer select-none">
          {[1, 2, 3, 4, 5].map((s) => (
            <span
              key={s}
              onClick={() => setStars(s)}
              className={`transition-transform hover:scale-125 ${
                s <= stars ? 'text-amber-400' : 'text-slate-200'
              }`}
            >
              ★
            </span>
          ))}
        </div>

        {/* Feedback tags */}
        <div className="flex flex-wrap gap-1.5 justify-center my-3">
          {availableTags.map((tag) => {
            const isSelected = selectedTags.includes(tag);
            return (
              <button
                key={tag}
                type="button"
                onClick={() => toggleTag(tag)}
                className={`text-[11px] font-bold px-2.5 py-1 rounded-full border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {tag}
              </button>
            );
          })}
        </div>

        {/* Text Review */}
        <textarea
          value={review}
          onChange={(e) => setReview(e.target.value)}
          placeholder="Write a quick review (optional)..."
          rows={2}
          className="w-full text-xs p-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-500 resize-none font-medium mb-3 text-slate-700"
        />

        <button
          type="button"
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="w-full py-3 bg-gradient-to-r from-blue-600 to-sky-600 text-white text-xs font-extrabold rounded-xl shadow-md transition-all cursor-pointer"
        >
          {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
        </button>

        <button
          type="button"
          onClick={onClose}
          className="mt-2 text-xs font-semibold text-slate-500 hover:text-slate-700 cursor-pointer"
        >
          Skip
        </button>
      </div>
    </div>
  );
};
