import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  RideTrip,
  BookingRequest,
  UserVehicle,
  SavedPlace,
  SponsoredAd,
  ReportItem,
  LiveLocation,
  ParcelSlab
} from './types';
import {
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  getDocs
} from './firebase';

import {
  INITIAL_RIDES,
  INITIAL_SPONSORED_ADS,
  INITIAL_USER_VEHICLES,
  INITIAL_SAVED_PLACES,
  INITIAL_REQUESTS,
  INITIAL_USERS
} from './data/initialData';

import { Header } from './components/Header';
import { Navigation, TabType } from './components/Navigation';
import { ToastContainer, ToastMessage } from './components/Toast';
import { RidesTab } from './components/tabs/RidesTab';
import { ParcelTab } from './components/tabs/ParcelTab';
import { PostTab } from './components/tabs/PostTab';
import { ActivityTab } from './components/tabs/ActivityTab';
import { ProfileTab } from './components/tabs/ProfileTab';

import { PinModal } from './components/modals/PinModal';
import { RatingModal } from './components/modals/RatingModal';
import { ChatModal } from './components/modals/ChatModal';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [currentTab, setCurrentTab] = useState<TabType>('rides');
  const [isAuthReady, setIsAuthReady] = useState(false);

  // Real-time Collections with Local Caching & Initial Fallbacks
  const [rides, setRides] = useState<RideTrip[]>(() => {
    try {
      const cached = localStorage.getItem('safar_rides_cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignored
    }
    return INITIAL_RIDES;
  });

  const [requests, setRequests] = useState<BookingRequest[]>(() => {
    try {
      const cached = localStorage.getItem('safar_requests_cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignored
    }
    return INITIAL_REQUESTS;
  });

  const [vehicles, setVehicles] = useState<UserVehicle[]>(() => {
    try {
      const cached = localStorage.getItem('safar_vehicles_cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignored
    }
    return INITIAL_USER_VEHICLES;
  });

  const [savedPlaces, setSavedPlaces] = useState<SavedPlace[]>(() => {
    try {
      const cached = localStorage.getItem('safar_places_cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignored
    }
    return INITIAL_SAVED_PLACES;
  });

  const [sponsoredAds, setSponsoredAds] = useState<SponsoredAd[]>(() => {
    try {
      const cached = localStorage.getItem('safar_ads_cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignored
    }
    return INITIAL_SPONSORED_ADS;
  });

  const [reports, setReports] = useState<ReportItem[]>([]);
  const [users, setUsers] = useState<UserProfile[]>(INITIAL_USERS);
  const [liveLocations, setLiveLocations] = useState<Record<string, LiveLocation>>({});

  // UI state
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [activePinModal, setActivePinModal] = useState<{
    isOpen: boolean;
    title: string;
    icon: string;
    onVerify: (pin: string) => Promise<void>;
  }>({
    isOpen: false,
    title: '',
    icon: '🔑',
    onVerify: async () => {}
  });

  const [activeRatingModal, setActiveRatingModal] = useState<{
    isOpen: boolean;
    requestId: string;
    targetName: string;
    targetUid: string;
  }>({
    isOpen: false,
    requestId: '',
    targetName: '',
    targetUid: ''
  });

  const [activeChatModal, setActiveChatModal] = useState<{
    isOpen: boolean;
    requestId: string;
    otherName: string;
    otherPhone?: string;
    isReadOnly?: boolean;
  }>({
    isOpen: false,
    requestId: '',
    otherName: '',
    isReadOnly: false
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const driverWatchRef = useRef<number | null>(null);

  const showToast = (text: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, text }]);
    try {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(() => {});
      }
    } catch {
      // Ignored
    }
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  };

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const snap = await getDoc(userDocRef);

          const isAdmin =
            firebaseUser.email?.toLowerCase() === 'gauravkhobragade37@gmail.com' ||
            (snap.exists() && snap.data().role === 'admin');

          const existingData = snap.exists() ? snap.data() : {};

          const profile: UserProfile = {
            uid: firebaseUser.uid,
            name: existingData.name || firebaseUser.displayName || 'User',
            email: firebaseUser.email || '',
            phone: existingData.phone || '',
            gender: existingData.gender || 'Male',
            photoURL:
              existingData.photoURL ||
              firebaseUser.photoURL ||
              'https://cdn-icons-png.flaticon.com/512/149/149071.png',
            role: isAdmin ? 'admin' : 'citizen',
            isBlocked: existingData.isBlocked || false,
            blockReason: existingData.blockReason || '',
            lastActive: Date.now()
          };

          try {
            await setDoc(userDocRef, profile, { merge: true });
          } catch (e: any) {
            console.warn('User profile remote setDoc warning:', e.message);
          }

          setCurrentUser(profile);
          showToast(`👋 Welcome, ${profile.name.split(' ')[0]}!`);
        } catch (e: any) {
          console.warn('Auth profile sync fallback:', e);
          const fallbackProfile: UserProfile = {
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || 'User',
            email: firebaseUser.email || '',
            phone: '',
            gender: 'Male',
            photoURL:
              firebaseUser.photoURL ||
              'https://cdn-icons-png.flaticon.com/512/149/149071.png',
            role: firebaseUser.email?.toLowerCase() === 'gauravkhobragade37@gmail.com' ? 'admin' : 'citizen',
            lastActive: Date.now()
          };
          setCurrentUser(fallbackProfile);
        }
      } else {
        setCurrentUser(null);
      }
      setIsAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  // Demo Login Helper
  const handleDemoLogin = (asAdmin: boolean) => {
    const demoUser: UserProfile = {
      uid: asAdmin ? 'demo-admin-gaurav' : 'demo-citizen-user',
      name: asAdmin ? 'Gaurav Khobragade (Admin)' : 'Rahul Verma',
      email: asAdmin ? 'gauravkhobragade37@gmail.com' : 'rahul.verma@example.com',
      phone: '8668828542',
      gender: 'Male',
      photoURL: asAdmin
        ? 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'
        : 'https://cdn-icons-png.flaticon.com/512/149/149071.png',
      role: asAdmin ? 'admin' : 'citizen',
      lastActive: Date.now()
    };
    setCurrentUser(demoUser);
    showToast(`⚡ Signed in as ${demoUser.name}`);
  };

  const handleGoogleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e: any) {
      if (e.code === 'auth/popup-blocked' || e.code === 'auth/cancelled-popup-request') {
        showToast('⚠️ Popups blocked in iframe preview. Using Demo Admin mode.');
        handleDemoLogin(true);
      } else {
        showToast('Login error: ' + (e.message || 'Check connection'));
      }
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch {
      // Ignored
    }
    setCurrentUser(null);
    showToast('🚪 Logged out successfully.');
  };

  // Public Real-time Synchronizations (Always safe to listen to on mount)
  useEffect(() => {
    const unsubRides = onSnapshot(
      collection(db, 'rides'),
      (snap) => {
        if (!snap.empty) {
          const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as RideTrip));
          setRides(list);
          try {
            localStorage.setItem('safar_rides_cache', JSON.stringify(list));
          } catch {
            // Ignored
          }
        }
      },
      (err) => {
        console.warn('[Firestore] rides snapshot handled:', err.message);
      }
    );

    const unsubAds = onSnapshot(
      collection(db, 'sponsored_ads'),
      (snap) => {
        if (!snap.empty) {
          const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SponsoredAd));
          setSponsoredAds(list);
          try {
            localStorage.setItem('safar_ads_cache', JSON.stringify(list));
          } catch {
            // Ignored
          }
        }
      },
      (err) => {
        console.warn('[Firestore] sponsored_ads snapshot handled:', err.message);
      }
    );

    const unsubLocations = onSnapshot(
      collection(db, 'live_locations'),
      (snap) => {
        const map: Record<string, LiveLocation> = {};
        snap.docs.forEach((d) => {
          map[d.id] = d.data() as LiveLocation;
        });
        setLiveLocations(map);
      },
      (err) => {
        console.warn('[Firestore] live_locations snapshot handled:', err.message);
      }
    );

    return () => {
      unsubRides();
      unsubAds();
      unsubLocations();
    };
  }, []);

  // Protected / User-Scoped Real-time Synchronizations
  // CRITICAL: Only attach these listeners if auth is resolved and the user is authenticated via Firebase Auth
  useEffect(() => {
    if (!isAuthReady || !currentUser || !auth.currentUser) {
      return;
    }

    const unsubRequests = onSnapshot(
      collection(db, 'requests'),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as BookingRequest));
        setRequests(list);
        try {
          localStorage.setItem('safar_requests_cache', JSON.stringify(list));
        } catch {
          // Ignored
        }
      },
      (err) => {
        console.warn('[Firestore] requests snapshot handled:', err.message);
      }
    );

    const unsubVehicles = onSnapshot(
      collection(db, 'user_vehicles'),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as UserVehicle));
        setVehicles(list);
        try {
          localStorage.setItem('safar_vehicles_cache', JSON.stringify(list));
        } catch {
          // Ignored
        }
      },
      (err) => {
        console.warn('[Firestore] user_vehicles snapshot handled:', err.message);
      }
    );

    const unsubPlaces = onSnapshot(
      collection(db, 'saved_places'),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SavedPlace));
        setSavedPlaces(list);
        try {
          localStorage.setItem('safar_places_cache', JSON.stringify(list));
        } catch {
          // Ignored
        }
      },
      (err) => {
        console.warn('[Firestore] saved_places snapshot handled:', err.message);
      }
    );

    let unsubReports = () => {};
    let unsubUsers = () => {};

    // Admin collections: only listen if current user is confirmed Admin
    if (currentUser.role === 'admin') {
      unsubReports = onSnapshot(
        collection(db, 'reports'),
        (snap) => {
          const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as ReportItem));
          setReports(list);
        },
        (err) => {
          console.warn('[Firestore] reports snapshot handled:', err.message);
        }
      );

      unsubUsers = onSnapshot(
        collection(db, 'users'),
        (snap) => {
          const list = snap.docs.map((d) => ({ uid: d.id, ...d.data() } as UserProfile));
          setUsers(list);
        },
        (err) => {
          console.warn('[Firestore] users snapshot handled:', err.message);
        }
      );
    }

    return () => {
      unsubRequests();
      unsubVehicles();
      unsubPlaces();
      unsubReports();
      unsubUsers();
    };
  }, [currentUser, isAuthReady]);

  // Driver GPS Watcher
  useEffect(() => {
    if (!currentUser || !navigator.geolocation) return;

    const inTransitTrip = requests.find(
      (q) => q.driverUid === currentUser.uid && ['Confirmed', 'In-Transit'].includes(q.status)
    );

    if (inTransitTrip && inTransitTrip.rideId && driverWatchRef.current === null) {
      driverWatchRef.current = navigator.geolocation.watchPosition(
        async (pos) => {
          const locPayload: LiveLocation = {
            rideId: inTransitTrip.rideId,
            driverUid: currentUser.uid,
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy || null,
            speed: pos.coords.speed || null,
            updatedAt: Date.now(),
            status: 'live'
          };
          setLiveLocations((prev) => ({ ...prev, [inTransitTrip.rideId]: locPayload }));

          try {
            if (auth.currentUser) {
              await setDoc(doc(db, 'live_locations', inTransitTrip.rideId), locPayload, { merge: true });
            }
          } catch {
            // Ignored
          }
        },
        () => {},
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
      );
    } else if (!inTransitTrip && driverWatchRef.current !== null) {
      navigator.geolocation.clearWatch(driverWatchRef.current);
      driverWatchRef.current = null;
    }

    return () => {
      if (driverWatchRef.current !== null) {
        navigator.geolocation.clearWatch(driverWatchRef.current);
        driverWatchRef.current = null;
      }
    };
  }, [currentUser, requests]);

  // URL Query Parameters check (e.g. ?tripId=... or ?trackRideId=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tripId = params.get('tripId');
    const trackRideId = params.get('trackRideId');

    if (tripId) {
      setCurrentTab('rides');
      showToast('🎯 Loaded trip from WhatsApp link!');
    } else if (trackRideId) {
      setCurrentTab('activity');
      showToast('📍 Live tracking opened from WhatsApp!');
    }
  }, []);

  // Handlers for Ride Booking & Trips
  const handleBookRide = async (
    ride: RideTrip,
    fare: number,
    travelKm: number,
    paymentMode: 'cash_pickup' | 'driver_qr'
  ) => {
    if (!currentUser) {
      handleGoogleLogin();
      return;
    }

    const startOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const dropOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const newReq: BookingRequest = {
      id: 'req-' + Date.now(),
      rideId: ride.id,
      driverUid: ride.driverUid,
      driverName: ride.driverName || 'Driver',
      driverPhone: ride.driverPhone || '',
      passengerUid: currentUser.uid,
      passengerName: currentUser.name || 'User',
      passengerPhone: currentUser.phone || '',
      passengerEmail: currentUser.email || '',
      type: 'passenger',
      numSeats: 1,
      originalPrice: fare,
      currentPrice: fare,
      price: fare,
      from: ride.from,
      to: ride.to,
      date: ride.date,
      travelKm,
      status: 'Pending',
      paymentMode,
      startOtp,
      dropOtp,
      created: Date.now(),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    // Optimistic local state update
    setRequests((prev) => {
      const next = [newReq, ...prev];
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        const docRef = await addDoc(collection(db, 'requests'), newReq);
        newReq.id = docRef.id;
      }
    } catch (e: any) {
      console.warn('Booking sync fallback to local:', e.message);
    }

    showToast('✅ Seat booking request sent to driver!');
    setCurrentTab('activity');
  };

  const handleOfferFare = async (ride: RideTrip, offerPrice: number, travelKm: number) => {
    if (!currentUser) {
      handleGoogleLogin();
      return;
    }

    const startOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const dropOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const newReq: BookingRequest = {
      id: 'req-' + Date.now(),
      rideId: ride.id,
      driverUid: ride.driverUid,
      driverName: ride.driverName || 'Driver',
      driverPhone: ride.driverPhone || '',
      passengerUid: currentUser.uid,
      passengerName: currentUser.name || 'User',
      passengerPhone: currentUser.phone || '',
      passengerEmail: currentUser.email || '',
      type: 'passenger',
      numSeats: 1,
      originalPrice: ride.seatPrice || offerPrice,
      currentPrice: offerPrice,
      price: offerPrice,
      from: ride.from,
      to: ride.to,
      date: ride.date,
      travelKm,
      status: 'Pending',
      paymentMode: 'cash_pickup',
      startOtp,
      dropOtp,
      created: Date.now(),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    setRequests((prev) => {
      const next = [newReq, ...prev];
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        const docRef = await addDoc(collection(db, 'requests'), newReq);
        newReq.id = docRef.id;
      }
    } catch (e: any) {
      console.warn('Offer sync fallback to local:', e.message);
    }

    showToast(`🔄 Counter offer ₹${offerPrice} sent to driver!`);
    setCurrentTab('activity');
  };

  const handleSendParcel = async (
    ride: RideTrip,
    slab: ParcelSlab,
    price: number,
    recName: string,
    recPhone: string,
    paymentMode: string
  ) => {
    if (!currentUser) {
      handleGoogleLogin();
      return;
    }

    const startOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const dropOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const newReq: BookingRequest = {
      id: 'req-' + Date.now(),
      rideId: ride.id,
      driverUid: ride.driverUid,
      driverName: ride.driverName || 'Driver',
      driverPhone: ride.driverPhone || '',
      passengerUid: currentUser.uid,
      passengerName: currentUser.name || 'User',
      passengerPhone: currentUser.phone || '',
      passengerEmail: currentUser.email || '',
      type: 'parcel',
      slab,
      originalPrice: price,
      currentPrice: price,
      from: ride.from,
      to: ride.to,
      date: ride.date,
      recName,
      recPhone,
      paymentMode,
      paymentSettlement: paymentMode,
      status: 'Pending',
      startOtp,
      dropOtp,
      created: Date.now(),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    setRequests((prev) => {
      const next = [newReq, ...prev];
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        const docRef = await addDoc(collection(db, 'requests'), newReq);
        newReq.id = docRef.id;
      }
    } catch (e: any) {
      console.warn('Parcel sync fallback to local:', e.message);
    }

    showToast('✅ Parcel request sent to transporter!');
    setCurrentTab('activity');
  };

  const handlePublishTrip = async (
    tripData: Omit<RideTrip, 'id' | 'created' | 'updatedAt'>,
    alsoReturn: boolean,
    returnTime: string
  ) => {
    const mainRide: RideTrip = {
      ...tripData,
      id: 'ride-' + Date.now(),
      created: Date.now(),
      updatedAt: Date.now()
    };

    let returnRide: RideTrip | null = null;
    if (alsoReturn && returnTime) {
      returnRide = {
        ...tripData,
        id: 'ride-' + (Date.now() + 1),
        from: tripData.to,
        to: tripData.from,
        time: returnTime,
        created: Date.now() + 1,
        updatedAt: Date.now() + 1
      };
    }

    setRides((prev) => {
      const next = [mainRide, ...(returnRide ? [returnRide] : []), ...prev];
      try {
        localStorage.setItem('safar_rides_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        const ref = await addDoc(collection(db, 'rides'), mainRide);
        mainRide.id = ref.id;
        if (returnRide) {
          const retRef = await addDoc(collection(db, 'rides'), returnRide);
          returnRide.id = retRef.id;
        }
      }
    } catch (e: any) {
      console.warn('Trip publish sync warning:', e.message);
    }

    showToast('🚀 Ride published successfully!');
    setCurrentTab('activity');
  };

  // Activity Actions
  const handleAcceptRequest = async (request: BookingRequest) => {
    setRequests((prev) => {
      const next = prev.map((q) => (q.id === request.id ? { ...q, status: 'Confirmed' as const, confirmedAt: Date.now() } : q));
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    if (request.type === 'passenger' && request.rideId) {
      setRides((prev) => {
        const next = prev.map((r) =>
          r.id === request.rideId ? { ...r, seats: Math.max(0, (r.seats || 1) - (request.numSeats || 1)) } : r
        );
        try {
          localStorage.setItem('safar_rides_cache', JSON.stringify(next));
        } catch {
          // Ignored
        }
        return next;
      });
    }

    try {
      if (auth.currentUser) {
        await updateDoc(doc(db, 'requests', request.id), {
          status: 'Confirmed',
          confirmedAt: Date.now()
        });

        if (request.type === 'passenger' && request.rideId) {
          const rideRef = doc(db, 'rides', request.rideId);
          const snap = await getDoc(rideRef);
          if (snap.exists()) {
            const curr = Number(snap.data().seats || 1);
            await updateDoc(rideRef, { seats: Math.max(0, curr - (request.numSeats || 1)) });
          }
        }
      }
    } catch (e: any) {
      console.warn('Accept request remote warning:', e.message);
    }

    showToast('✅ Booking Confirmed! Start PIN is active.');
  };

  const handleRejectRequest = async (requestId: string) => {
    setRequests((prev) => {
      const next = prev.map((q) => (q.id === requestId ? { ...q, status: 'Rejected' as const, updatedAt: Date.now() } : q));
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        await updateDoc(doc(db, 'requests', requestId), {
          status: 'Rejected',
          updatedAt: Date.now()
        });
      }
    } catch (e: any) {
      console.warn('Reject remote warning:', e.message);
    }
    showToast('Request rejected.');
  };

  const handleCancelRequest = async (requestId: string) => {
    const reason = prompt('Enter cancellation reason:');
    if (reason === null) return;

    const req = requests.find((q) => q.id === requestId);
    setRequests((prev) => {
      const next = prev.map((q) =>
        q.id === requestId
          ? { ...q, status: 'Cancelled' as const, cancelReason: reason || 'Cancelled by user', cancelledAt: Date.now() }
          : q
      );
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    if (req && req.type === 'passenger' && req.rideId && ['Confirmed', 'In-Transit'].includes(req.status)) {
      setRides((prev) => {
        const next = prev.map((r) =>
          r.id === req.rideId ? { ...r, seats: (r.seats || 0) + (req.numSeats || 1) } : r
        );
        try {
          localStorage.setItem('safar_rides_cache', JSON.stringify(next));
        } catch {
          // Ignored
        }
        return next;
      });
    }

    try {
      if (auth.currentUser) {
        await updateDoc(doc(db, 'requests', requestId), {
          status: 'Cancelled',
          cancelReason: reason || 'Cancelled by user',
          cancelledAt: Date.now()
        });

        if (req && req.type === 'passenger' && req.rideId && ['Confirmed', 'In-Transit'].includes(req.status)) {
          const rideRef = doc(db, 'rides', req.rideId);
          const snap = await getDoc(rideRef);
          if (snap.exists()) {
            const curr = Number(snap.data().seats || 0);
            await updateDoc(rideRef, { seats: curr + (req.numSeats || 1) });
          }
        }
      }
    } catch (e: any) {
      console.warn('Cancel remote warning:', e.message);
    }

    showToast('Booking cancelled.');
  };

  const handleCancelTrip = async (rideId: string) => {
    const reason = prompt('Reason for cancelling trip:');
    if (reason === null) return;

    setRides((prev) => {
      const next = prev.map((r) =>
        r.id === rideId ? { ...r, status: 'Cancelled' as const, cancelReason: reason || 'Cancelled by driver', cancelledAt: Date.now() } : r
      );
      try {
        localStorage.setItem('safar_rides_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        await updateDoc(doc(db, 'rides', rideId), {
          status: 'Cancelled',
          cancelReason: reason || 'Cancelled by driver',
          cancelledAt: Date.now()
        });
      }
    } catch (e: any) {
      console.warn('Trip cancel remote warning:', e.message);
    }

    showToast('🚫 Trip cancelled.');
  };

  const handleDriverReOffer = async (requestId: string, newPrice: number) => {
    setRequests((prev) => {
      const next = prev.map((q) =>
        q.id === requestId
          ? { ...q, currentPrice: newPrice, price: newPrice, status: 'Countered_By_Driver' as const, updatedAt: Date.now() }
          : q
      );
      try {
        localStorage.setItem('safar_requests_cache', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });

    try {
      if (auth.currentUser) {
        await updateDoc(doc(db, 'requests', requestId), {
          currentPrice: newPrice,
          price: newPrice,
          status: 'Countered_By_Driver',
          updatedAt: Date.now()
        });
      }
    } catch (e: any) {
      console.warn('Counter offer remote warning:', e.message);
    }

    showToast('🔄 Counter re-offer sent to passenger!');
  };

  // Start PIN Verification
  const handleVerifyStartPin = (request: BookingRequest) => {
    setActivePinModal({
      isOpen: true,
      title: 'Enter 4-Digit START PIN',
      icon: '🔑',
      onVerify: async (pin: string) => {
        if (pin !== request.startOtp) {
          showToast('❌ Wrong Start PIN! Please check again.');
          return;
        }

        setRequests((prev) => {
          const next = prev.map((q) => (q.id === request.id ? { ...q, status: 'In-Transit' as const, startedAt: Date.now() } : q));
          try {
            localStorage.setItem('safar_requests_cache', JSON.stringify(next));
          } catch {
            // Ignored
          }
          return next;
        });

        if (request.rideId) {
          setRides((prev) => {
            const next = prev.map((r) => (r.id === request.rideId ? { ...r, tripStarted: true } : r));
            try {
              localStorage.setItem('safar_rides_cache', JSON.stringify(next));
            } catch {
              // Ignored
            }
            return next;
          });
        }

        try {
          if (auth.currentUser) {
            await updateDoc(doc(db, 'requests', request.id), {
              status: 'In-Transit',
              startedAt: Date.now()
            });
            if (request.rideId) {
              await updateDoc(doc(db, 'rides', request.rideId), {
                tripStarted: true
              });
            }
          }
        } catch (e: any) {
          console.warn('Start pin verify remote warning:', e.message);
        }

        setActivePinModal((p) => ({ ...p, isOpen: false }));
        showToast('🚗 Start PIN verified! Ride is now In-Transit.');
      }
    });
  };

  // Drop PIN Verification
  const handleVerifyDropPin = (request: BookingRequest) => {
    setActivePinModal({
      isOpen: true,
      title: 'Enter 4-Digit DROP PIN',
      icon: '🏁',
      onVerify: async (pin: string) => {
        if (pin !== request.dropOtp) {
          showToast('❌ Wrong Drop PIN! Please check again.');
          return;
        }

        setRequests((prev) => {
          const next = prev.map((q) => (q.id === request.id ? { ...q, status: 'Completed' as const, completedAt: Date.now() } : q));
          try {
            localStorage.setItem('safar_requests_cache', JSON.stringify(next));
          } catch {
            // Ignored
          }
          return next;
        });

        try {
          if (auth.currentUser) {
            await updateDoc(doc(db, 'requests', request.id), {
              status: 'Completed',
              completedAt: Date.now()
            });
          }
        } catch (e: any) {
          console.warn('Drop pin verify remote warning:', e.message);
        }

        setActivePinModal((p) => ({ ...p, isOpen: false }));
        showToast('🏁 Trip completed successfully!');

        // Open rating modal
        setActiveRatingModal({
          isOpen: true,
          requestId: request.id,
          targetName: request.passengerName || 'Passenger',
          targetUid: request.passengerUid
        });
      }
    });
  };

  // SOS Emergency Trigger
  const handleTriggerSOS = async (request: BookingRequest) => {
    const reportItem: ReportItem = {
      id: 'rep-' + Date.now(),
      type: '🚨 SOS EMERGENCY TRIGGERED',
      reporterUid: currentUser?.uid,
      reporterName: currentUser?.name,
      targetUid: request.driverUid,
      targetName: request.driverName,
      requestId: request.id,
      reason: `Emergency SOS triggered on route: ${request.from} ➔ ${request.to}`,
      status: 'open',
      createdAt: Date.now()
    };

    setReports((prev) => [reportItem, ...prev]);

    try {
      if (auth.currentUser) {
        await addDoc(collection(db, 'reports'), reportItem);
      }
    } catch {
      // Handled
    }

    showToast('🚨 SOS Emergency alert logged to Admin. Connecting 112...');
    setTimeout(() => {
      window.location.href = 'tel:112';
    }, 500);
  };

  const handleReportUser = async (targetUid: string, targetName: string, requestId: string) => {
    const reason = prompt(`Report ${targetName} - please describe the issue:`);
    if (!reason || !reason.trim()) return;

    const reportItem: ReportItem = {
      id: 'rep-' + Date.now(),
      type: 'User Report',
      reporterUid: currentUser?.uid,
      reporterName: currentUser?.name,
      targetUid,
      targetName,
      requestId,
      reason: reason.trim(),
      status: 'open',
      createdAt: Date.now()
    };

    setReports((prev) => [reportItem, ...prev]);

    try {
      if (auth.currentUser) {
        await addDoc(collection(db, 'reports'), reportItem);
      }
    } catch (e: any) {
      console.warn('Report remote warning:', e.message);
    }
    showToast('✅ Report submitted to Admin for review.');
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-50 select-none">
      <audio
        ref={audioRef}
        src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3"
        preload="auto"
      />

      <ToastContainer toasts={toasts} onRemove={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />

      {/* Header */}
      <Header
        currentUser={currentUser}
        onLogin={handleGoogleLogin}
        onDemoLogin={handleDemoLogin}
        onOpenProfile={() => setCurrentTab('profile')}
      />

      {/* Main Tab Viewport */}
      <main className="relative flex-1 w-full overflow-hidden">
        {currentTab === 'rides' && (
          <RidesTab
            currentUser={currentUser}
            rides={rides}
            sponsoredAds={sponsoredAds}
            isActive={currentTab === 'rides'}
            onBookRide={handleBookRide}
            onOfferFare={handleOfferFare}
            onShowToast={showToast}
            onRequestLogin={handleGoogleLogin}
          />
        )}

        {currentTab === 'parcel' && (
          <ParcelTab
            currentUser={currentUser}
            rides={rides}
            isActive={currentTab === 'parcel'}
            onSendParcel={handleSendParcel}
            onShowToast={showToast}
            onRequestLogin={handleGoogleLogin}
          />
        )}

        {currentTab === 'post' && (
          <PostTab
            currentUser={currentUser}
            vehicles={vehicles.filter((v) => v.userUid === currentUser?.uid)}
            isActive={currentTab === 'post'}
            onPublishTrip={handlePublishTrip}
            onShowToast={showToast}
            onRequestLogin={handleGoogleLogin}
          />
        )}

        {currentTab === 'activity' && (
          <ActivityTab
            currentUser={currentUser}
            trips={rides}
            requests={requests}
            onAcceptRequest={handleAcceptRequest}
            onRejectRequest={handleRejectRequest}
            onCancelRequest={handleCancelRequest}
            onCancelTrip={handleCancelTrip}
            onDriverReOffer={handleDriverReOffer}
            onVerifyStartPin={handleVerifyStartPin}
            onVerifyDropPin={handleVerifyDropPin}
            onOpenChat={(req) => {
              const isDriver = req.driverUid === currentUser?.uid;
              setActiveChatModal({
                isOpen: true,
                requestId: req.id,
                otherName: isDriver ? req.passengerName : req.driverName,
                otherPhone: isDriver ? req.passengerPhone : req.driverPhone,
                isReadOnly: ['Completed', 'Cancelled', 'Rejected'].includes(req.status)
              });
            }}
            onOpenRating={(req) => {
              const isDriver = req.driverUid === currentUser?.uid;
              setActiveRatingModal({
                isOpen: true,
                requestId: req.id,
                targetName: isDriver ? req.passengerName : req.driverName,
                targetUid: isDriver ? req.passengerUid : req.driverUid
              });
            }}
            onOpenEditTrip={() => {}}
            onTriggerSOS={handleTriggerSOS}
            onReportUser={handleReportUser}
            onShowToast={showToast}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileTab
            currentUser={currentUser}
            users={users}
            trips={rides}
            requests={requests}
            vehicles={vehicles.filter((v) => v.userUid === currentUser?.uid)}
            savedPlaces={savedPlaces.filter((p) => p.userUid === currentUser?.uid)}
            sponsoredAds={sponsoredAds}
            reports={reports}
            liveLocations={liveLocations}
            onUpdateProfile={async (name, phone, gender) => {
              if (!currentUser) return;
              setCurrentUser((u) => (u ? { ...u, name, phone, gender } : null));
              setUsers((prev) => prev.map((u) => (u.uid === currentUser.uid ? { ...u, name, phone, gender } : u)));

              try {
                if (auth.currentUser) {
                  await updateDoc(doc(db, 'users', currentUser.uid), {
                    name,
                    phone,
                    gender,
                    lastActive: Date.now()
                  });
                }
              } catch (e: any) {
                console.warn('Profile update remote warning:', e.message);
              }
              showToast('✅ Profile saved successfully!');
            }}
            onAddVehicle={async (type, model, plate) => {
              if (!currentUser) return;
              const newVeh: UserVehicle = {
                id: 'veh-' + Date.now(),
                type,
                model,
                plate,
                userUid: currentUser.uid,
                userEmail: currentUser.email,
                created: Date.now(),
                kycStatus: 'pending'
              };

              setVehicles((prev) => {
                const next = [newVeh, ...prev];
                try {
                  localStorage.setItem('safar_vehicles_cache', JSON.stringify(next));
                } catch {
                  // Ignored
                }
                return next;
              });

              try {
                if (auth.currentUser) {
                  const ref = await addDoc(collection(db, 'user_vehicles'), newVeh);
                  newVeh.id = ref.id;
                }
              } catch (e: any) {
                console.warn('Vehicle add remote warning:', e.message);
              }

              showToast('✅ Vehicle added to garage!');
            }}
            onDeleteVehicle={async (id) => {
              setVehicles((prev) => {
                const next = prev.filter((v) => v.id !== id);
                try {
                  localStorage.setItem('safar_vehicles_cache', JSON.stringify(next));
                } catch {
                  // Ignored
                }
                return next;
              });

              try {
                if (auth.currentUser) {
                  await deleteDoc(doc(db, 'user_vehicles', id));
                }
              } catch (e: any) {
                console.warn('Vehicle delete remote warning:', e.message);
              }

              showToast('Vehicle removed.');
            }}
            onAddPlace={async (title, address) => {
              if (!currentUser) return;
              const newPlace: SavedPlace = {
                id: 'place-' + Date.now(),
                title,
                address,
                userUid: currentUser.uid,
                createdAt: Date.now()
              };

              setSavedPlaces((prev) => {
                const next = [newPlace, ...prev];
                try {
                  localStorage.setItem('safar_places_cache', JSON.stringify(next));
                } catch {
                  // Ignored
                }
                return next;
              });

              try {
                if (auth.currentUser) {
                  const ref = await addDoc(collection(db, 'saved_places'), newPlace);
                  newPlace.id = ref.id;
                }
              } catch (e: any) {
                console.warn('Place add remote warning:', e.message);
              }

              showToast('📍 Place saved.');
            }}
            onDeletePlace={async (id) => {
              setSavedPlaces((prev) => {
                const next = prev.filter((p) => p.id !== id);
                try {
                  localStorage.setItem('safar_places_cache', JSON.stringify(next));
                } catch {
                  // Ignored
                }
                return next;
              });

              try {
                if (auth.currentUser) {
                  await deleteDoc(doc(db, 'saved_places', id));
                }
              } catch (e: any) {
                console.warn('Place delete remote warning:', e.message);
              }

              showToast('Place removed.');
            }}
            onToggleBlockUser={async (userUid, currentStatus, name) => {
              setUsers((prev) =>
                prev.map((u) =>
                  u.uid === userUid
                    ? { ...u, isBlocked: !currentStatus, blockReason: !currentStatus ? 'Admin manual restriction' : '' }
                    : u
                )
              );

              try {
                if (auth.currentUser) {
                  await updateDoc(doc(db, 'users', userUid), {
                    isBlocked: !currentStatus,
                    blockReason: !currentStatus ? 'Admin manual restriction' : ''
                  });
                }
              } catch (e: any) {
                console.warn('Block user remote warning:', e.message);
              }

              showToast(`User ${name} ${!currentStatus ? 'Blocked' : 'Unblocked'}.`);
            }}
            onForceCancelTrip={async (rideId) => {
              setRides((prev) =>
                prev.map((r) =>
                  r.id === rideId
                    ? { ...r, status: 'Cancelled' as const, cancelReason: 'Admin Force Cancellation', cancelledAt: Date.now() }
                    : r
                )
              );

              try {
                if (auth.currentUser) {
                  await updateDoc(doc(db, 'rides', rideId), {
                    status: 'Cancelled',
                    cancelReason: 'Admin Force Cancellation',
                    cancelledAt: Date.now()
                  });
                }
              } catch (e: any) {
                console.warn('Trip cancel remote warning:', e.message);
              }

              showToast('✅ Trip force cancelled.');
            }}
            onApproveVehicleKYC={async (vehicleId) => {
              setVehicles((prev) =>
                prev.map((v) => (v.id === vehicleId ? { ...v, kycStatus: 'verified' as const } : v))
              );

              try {
                if (auth.currentUser) {
                  await updateDoc(doc(db, 'user_vehicles', vehicleId), {
                    kycStatus: 'verified'
                  });
                }
              } catch (e: any) {
                console.warn('Vehicle KYC approve remote warning:', e.message);
              }

              showToast('✅ Vehicle KYC Approved!');
            }}
            onRejectVehicleKYC={async (vehicleId, userUid) => {
              setVehicles((prev) =>
                prev.map((v) => (v.id === vehicleId ? { ...v, kycStatus: 'rejected' as const } : v))
              );
              setUsers((prev) =>
                prev.map((u) =>
                  u.uid === userUid
                    ? { ...u, isBlocked: true, blockReason: 'Vehicle verification failed.' }
                    : u
                )
              );

              try {
                if (auth.currentUser) {
                  await updateDoc(doc(db, 'user_vehicles', vehicleId), {
                    kycStatus: 'rejected'
                  });
                  await updateDoc(doc(db, 'users', userUid), {
                    isBlocked: true,
                    blockReason: 'Vehicle verification failed.'
                  });
                }
              } catch (e: any) {
                console.warn('Vehicle KYC reject remote warning:', e.message);
              }

              showToast('🚫 Vehicle rejected & user suspended.');
            }}
            onAddSponsoredAd={async (name, category, landmark, targetRoute, phone) => {
              const newAd: SponsoredAd = {
                id: 'ad-' + Date.now(),
                name,
                category,
                landmark,
                targetRoute,
                phone,
                createdAt: Date.now()
              };

              setSponsoredAds((prev) => {
                const next = [newAd, ...prev];
                try {
                  localStorage.setItem('safar_ads_cache', JSON.stringify(next));
                } catch {
                  // Ignored
                }
                return next;
              });

              try {
                if (auth.currentUser) {
                  const ref = await addDoc(collection(db, 'sponsored_ads'), newAd);
                  newAd.id = ref.id;
                }
              } catch (e: any) {
                console.warn('Ad add remote warning:', e.message);
              }

              showToast('🚀 Sponsored ad published!');
            }}
            onDeleteSponsoredAd={async (id) => {
              setSponsoredAds((prev) => {
                const next = prev.filter((a) => a.id !== id);
                try {
                  localStorage.setItem('safar_ads_cache', JSON.stringify(next));
                } catch {
                  // Ignored
                }
                return next;
              });

              try {
                if (auth.currentUser) {
                  await deleteDoc(doc(db, 'sponsored_ads', id));
                }
              } catch (e: any) {
                console.warn('Ad delete remote warning:', e.message);
              }

              showToast('Ad deleted.');
            }}
            onClearAllTestData={async () => {
              if (!confirm('Are you sure you want to clear all test rides & requests?')) return;
              try {
                if (auth.currentUser) {
                  const snapR = await getDocs(collection(db, 'rides'));
                  snapR.forEach(async (d) => await deleteDoc(doc(db, 'rides', d.id)));
                  const snapQ = await getDocs(collection(db, 'requests'));
                  snapQ.forEach(async (d) => await deleteDoc(doc(db, 'requests', d.id)));
                }
              } catch (e: any) {
                console.warn('Clear remote warning:', e.message);
              }

              setRides([]);
              setRequests([]);
              try {
                localStorage.removeItem('safar_rides_cache');
                localStorage.removeItem('safar_requests_cache');
              } catch {
                // Ignored
              }
              showToast('🧹 All test data cleared!');
            }}
            onLogout={handleLogout}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <Navigation
        activeTab={currentTab}
        onSelectTab={setCurrentTab}
        pendingCount={requests.filter((q) => q.driverUid === currentUser?.uid && q.status === 'Pending').length}
      />

      {/* Shared Modals */}
      <PinModal
        isOpen={activePinModal.isOpen}
        title={activePinModal.title}
        icon={activePinModal.icon}
        onVerify={activePinModal.onVerify}
        onClose={() => setActivePinModal((p) => ({ ...p, isOpen: false }))}
      />

      <RatingModal
        isOpen={activeRatingModal.isOpen}
        targetName={activeRatingModal.targetName}
        onSubmit={async (stars, tags, review) => {
          setRequests((prev) => {
            const next = prev.map((q) =>
              q.id === activeRatingModal.requestId ? { ...q, isRated: true, passengerRated: true } : q
            );
            try {
              localStorage.setItem('safar_requests_cache', JSON.stringify(next));
            } catch {
              // Ignored
            }
            return next;
          });

          try {
            if (auth.currentUser) {
              await addDoc(collection(db, 'ratings'), {
                requestId: activeRatingModal.requestId,
                raterUid: currentUser?.uid,
                raterName: currentUser?.name,
                targetUid: activeRatingModal.targetUid,
                targetName: activeRatingModal.targetName,
                stars,
                tags,
                review,
                createdAt: Date.now()
              });

              await updateDoc(doc(db, 'requests', activeRatingModal.requestId), {
                isRated: true,
                passengerRated: true
              });
            }
          } catch (e: any) {
            console.warn('Rating remote warning:', e.message);
          }

          showToast('⭐ Thank you for your feedback!');
        }}
        onClose={() => setActiveRatingModal((p) => ({ ...p, isOpen: false }))}
      />

      <ChatModal
        isOpen={activeChatModal.isOpen}
        requestId={activeChatModal.requestId}
        otherName={activeChatModal.otherName}
        otherPhone={activeChatModal.otherPhone}
        currentUser={currentUser}
        isReadOnly={activeChatModal.isReadOnly}
        onClose={() => setActiveChatModal((p) => ({ ...p, isOpen: false }))}
      />
    </div>
  );
}
