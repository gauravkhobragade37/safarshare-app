import * as turf from '@turf/turf';

export const LOCATIONIQ_API_KEY = "pk.10fcbc3966ee1a09d6e30ae53f2c7c33";

const localMemoryCache: Record<string, [number, number]> = {};

export function formatCleanAddress(displayName: string): string {
  if (!displayName) return "";
  const parts = displayName.split(',').map(p => p.trim());
  const filtered = parts.filter(p => {
    const lower = p.toLowerCase();
    if (/^\d{5,6}$/.test(p)) return false;
    if (lower === 'india' || lower === 'in') return false;
    if (lower.includes('taluka') || lower.includes('district') || lower.includes('tehsil')) return false;
    return true;
  });
  const unique = Array.from(new Set(filtered));
  return unique.slice(0, 2).join(', ') || displayName.split(',')[0];
}

export function cleanLocation(name: string): string {
  return formatCleanAddress(name);
}

export function format12Hour(timeStr: string): string {
  if (!timeStr || !timeStr.includes(':')) return timeStr || '';
  const parts = timeStr.split(':');
  let hours = parseInt(parts[0], 10);
  const minutes = parts[1] || '00';
  if (isNaN(hours)) return timeStr;
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  return `${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;
}

export async function reverseGeocode(lat: number, lng: number): Promise<string> {
  try {
    const url = `https://api.locationiq.com/v1/reverse?key=${LOCATIONIQ_API_KEY}&lat=${lat}&lon=${lng}&accept-language=en&format=json`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('LocationIQ error');
    const d = await res.json();
    return formatCleanAddress(d.display_name) || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  } catch {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&accept-language=en`);
      const d = await res.json();
      return formatCleanAddress(d.display_name) || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    } catch {
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }
  }
}

export async function autocompletePlaces(queryText: string): Promise<Array<{ display_name: string; cleanName: string; lat: number; lon: number }>> {
  if (!queryText || queryText.trim().length < 2) return [];
  const q = queryText.trim();
  try {
    const url = `https://api.locationiq.com/v1/autocomplete?key=${LOCATIONIQ_API_KEY}&q=${encodeURIComponent(q)}&countrycodes=in&accept-language=en&limit=5&format=json`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Autocomplete failed');
    const data = await res.json();
    return data.map((item: any) => ({
      display_name: item.display_name,
      cleanName: formatCleanAddress(item.display_name),
      lat: parseFloat(item.lat),
      lon: parseFloat(item.lon)
    }));
  } catch {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&countrycodes=in&accept-language=en&limit=5&q=${encodeURIComponent(q)}`);
      const data = await res.json();
      return data.map((item: any) => ({
        display_name: item.display_name,
        cleanName: formatCleanAddress(item.display_name),
        lat: parseFloat(item.lat),
        lon: parseFloat(item.lon)
      }));
    } catch {
      return [];
    }
  }
}

export async function geocodePlace(queryText: string): Promise<[number, number]> {
  if (!queryText) return [21.4588, 80.1961];
  const clean = queryText.trim().toLowerCase();
  if (localMemoryCache[clean]) return localMemoryCache[clean];

  try {
    const url = `https://api.locationiq.com/v1/search?key=${LOCATIONIQ_API_KEY}&q=${encodeURIComponent(queryText)}&countrycodes=in&accept-language=en&format=json&limit=1`;
    const res = await fetch(url);
    const data = await res.json();
    if (data && data.length > 0) {
      const coords: [number, number] = [parseFloat(data[0].lat), parseFloat(data[0].lon)];
      localMemoryCache[clean] = coords;
      return coords;
    }
  } catch {
    // fallback
  }
  return [21.4588, 80.1961];
}

export interface OsrmRouteOption {
  geometry: any;
  coordinates: [number, number][]; // [lat, lng] for leaflet
  distanceKm: number;
  durationMin: number;
  summary: string;
}

export async function fetchRoutesBetweenPoints(
  p1: { lat: number; lng: number },
  p2: { lat: number; lng: number }
): Promise<OsrmRouteOption[]> {
  try {
    const res = await fetch(
      `https://router.project-osrm.org/route/v1/driving/${p1.lng},${p1.lat};${p2.lng},${p2.lat}?overview=full&geometries=geojson&alternatives=3`
    );
    if (!res.ok) throw new Error('OSRM network failure');
    const data = await res.json();
    if (data.routes && data.routes.length > 0) {
      return data.routes.map((r: any, idx: number) => ({
        geometry: r.geometry,
        coordinates: r.geometry.coordinates.map((c: [number, number]) => [c[1], c[0]] as [number, number]),
        distanceKm: Number((r.distance / 1000).toFixed(1)),
        durationMin: Math.round(r.duration / 60),
        summary: r.legs?.[0]?.summary ? `Via ${r.legs[0].summary}` : `Route Alt ${idx + 1}`
      }));
    }
  } catch (e) {
    console.warn("OSRM routing offline, using linear approximation", e);
  }

  // Fallback straight-line interpolated route
  const dist = haversineDistance(p1.lat, p1.lng, p2.lat, p2.lng);
  const geojson = {
    type: 'LineString',
    coordinates: [
      [p1.lng, p1.lat],
      [(p1.lng + p2.lng) / 2, (p1.lat + p2.lat) / 2],
      [p2.lng, p2.lat]
    ]
  };
  return [
    {
      geometry: geojson,
      coordinates: [
        [p1.lat, p1.lng],
        [(p1.lat + p2.lat) / 2, (p1.lng + p2.lng) / 2],
        [p2.lat, p2.lng]
      ],
      distanceKm: Number((dist * 1.25).toFixed(1)), // 25% curve factor for roads
      durationMin: Math.round((dist * 1.25) / 0.8), // ~50 km/h average
      summary: 'Direct Highway Corridor'
    }
  ];
}

export function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function checkCorridorMatch(
  pickup: { lat: number; lng: number },
  drop: { lat: number; lng: number },
  geometry: any,
  maxCorridorKm: number
): { isMatch: boolean; travelKm: number } {
  try {
    let geom = geometry;
    if (typeof geom === 'string') {
      geom = JSON.parse(geom);
    }
    if (geom && geom.coordinates && geom.coordinates.length >= 2) {
      const pPickupPt = turf.point([pickup.lng, pickup.lat]);
      const pDropPt = turf.point([drop.lng, drop.lat]);
      const line = turf.lineString(geom.coordinates);

      const dist1 = turf.pointToLineDistance(pPickupPt, line, { units: 'kilometers' });
      const dist2 = turf.pointToLineDistance(pDropPt, line, { units: 'kilometers' });
      const np1 = turf.nearestPointOnLine(line, pPickupPt);
      const np2 = turf.nearestPointOnLine(line, pDropPt);

      const loc1 = (np1.properties as any).location ?? 0;
      const loc2 = (np2.properties as any).location ?? 0;

      if (dist1 <= maxCorridorKm && dist2 <= maxCorridorKm && loc1 <= loc2) {
        const travelKm = Math.max(1, Math.round(loc2 - loc1));
        return { isMatch: true, travelKm };
      }
    }
  } catch (err) {
    // fallback to haversine approximation
  }

  // Linear check fallback
  const d = haversineDistance(pickup.lat, pickup.lng, drop.lat, drop.lng);
  return { isMatch: false, travelKm: Math.round(d) };
}
