/**
 * Utility functions for Trip Progress calculation and Estimated Arrival Time (ETA)
 */

export interface ETAResult {
  departureTime12: string;
  arrivalTime12: string;
  departureDate: string;
  arrivalDate: string;
  isNextDay: boolean;
  durationMinutes: number;
  durationFormatted: string;
  etaLabel: string;
  remainingMinutes?: number;
  remainingFormatted?: string;
}

export interface TripProgressResult {
  progressPercent: number; // 0 to 100
  statusText: string;
  isLive: boolean;
  eta: ETAResult;
}

/**
 * Format minutes into e.g. "2h 15m" or "45m"
 */
export function formatDurationMinutes(minutes: number): string {
  const mins = Math.max(1, Math.round(minutes));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

/**
 * Format a 24-hour HH:MM string to 12-hour AM/PM format
 */
export function formatTimeTo12Hour(timeStr: string): string {
  if (!timeStr || !timeStr.includes(':')) return timeStr || '';
  const parts = timeStr.split(':');
  let hours = parseInt(parts[0], 10);
  const minutes = parts[1] || '00';
  if (isNaN(hours)) return timeStr;
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  return `${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;
}

/**
 * Calculate Estimated Arrival Time (ETA) from departure date, departure time, and duration
 */
export function calculateETA(
  dateStr?: string,
  timeStr?: string,
  durationMinutes?: number,
  distanceKm?: number
): ETAResult {
  // If no duration provided, estimate from distance assuming average corridor speed 50 km/h + 10 mins buffer
  let duration = durationMinutes && durationMinutes > 0 ? durationMinutes : 0;
  if (!duration && distanceKm && distanceKm > 0) {
    duration = Math.max(15, Math.round((distanceKm / 50) * 60) + 10);
  }
  if (!duration) {
    duration = 60; // fallback 1 hour
  }

  const validDateStr = dateStr && dateStr.length >= 10 ? dateStr : new Date().toISOString().split('T')[0];
  const validTimeStr = timeStr && timeStr.includes(':') ? timeStr : '12:00';

  const [depHours, depMins] = validTimeStr.split(':').map((n) => parseInt(n, 10) || 0);

  // Parse departure Date object
  const depDate = new Date(`${validDateStr}T${String(depHours).padStart(2, '0')}:${String(depMins).padStart(2, '0')}:00`);

  // Calculate arrival Date object
  const arrDate = new Date(depDate.getTime() + duration * 60 * 1000);

  // Format arrival time in 12h format
  let arrHours = arrDate.getHours();
  const arrMinutes = String(arrDate.getMinutes()).padStart(2, '0');
  const arrAmpm = arrHours >= 12 ? 'PM' : 'AM';
  arrHours = arrHours % 12;
  arrHours = arrHours ? arrHours : 12;
  const arrivalTime12 = `${String(arrHours).padStart(2, '0')}:${arrMinutes} ${arrAmpm}`;

  const departureTime12 = formatTimeTo12Hour(validTimeStr);

  const isNextDay = arrDate.getDate() !== depDate.getDate() || arrDate.getMonth() !== depDate.getMonth();
  const arrivalDate = arrDate.toISOString().split('T')[0];

  const durationFormatted = formatDurationMinutes(duration);

  const now = Date.now();
  const arrTimeMs = arrDate.getTime();
  const diffMs = arrTimeMs - now;
  const remainingMinutes = diffMs > 0 ? Math.round(diffMs / 60000) : 0;
  const remainingFormatted = remainingMinutes > 0 ? formatDurationMinutes(remainingMinutes) : 'Arrived';

  return {
    departureTime12,
    arrivalTime12,
    departureDate: validDateStr,
    arrivalDate,
    isNextDay,
    durationMinutes: duration,
    durationFormatted,
    etaLabel: `Est. Arrival: ${arrivalTime12}${isNextDay ? ' (+1 day)' : ''} (${durationFormatted})`,
    remainingMinutes,
    remainingFormatted
  };
}

/**
 * Calculates current progress percentage of a trip
 */
export function getTripProgress(
  dateStr?: string,
  timeStr?: string,
  durationMinutes?: number,
  distanceKm?: number,
  tripStarted?: boolean,
  startedAt?: number
): TripProgressResult {
  const eta = calculateETA(dateStr, timeStr, durationMinutes, distanceKm);
  const now = Date.now();

  const [depHours, depMins] = (timeStr || '12:00').split(':').map((n) => parseInt(n, 10) || 0);
  const depDate = new Date(`${dateStr || new Date().toISOString().split('T')[0]}T${String(depHours).padStart(2, '0')}:${String(depMins).padStart(2, '0')}:00`);
  const depTimeMs = startedAt || depDate.getTime();
  const totalDurationMs = eta.durationMinutes * 60 * 1000;
  const arrTimeMs = depTimeMs + totalDurationMs;

  let progressPercent = 0;
  let statusText = 'Scheduled';
  let isLive = false;

  if (tripStarted || (now >= depTimeMs && now <= arrTimeMs)) {
    isLive = true;
    const elapsedMs = Math.max(0, now - depTimeMs);
    progressPercent = Math.min(95, Math.max(5, Math.round((elapsedMs / totalDurationMs) * 100)));
    if (progressPercent < 25) {
      statusText = 'Departed & In-Transit';
    } else if (progressPercent < 80) {
      statusText = 'Cruising Highway Corridor';
    } else {
      statusText = 'Approaching Destination';
    }
  } else if (now > arrTimeMs) {
    progressPercent = 100;
    statusText = 'Trip Completed';
  } else {
    // Upcoming
    const minsUntilStart = Math.round((depTimeMs - now) / 60000);
    if (minsUntilStart <= 30 && minsUntilStart > 0) {
      statusText = `Boarding in ${minsUntilStart} mins`;
      progressPercent = 5;
    } else {
      statusText = 'Scheduled Departure';
      progressPercent = 0;
    }
  }

  return {
    progressPercent,
    statusText,
    isLive,
    eta
  };
}
