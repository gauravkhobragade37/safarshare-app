import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  getDocs,
  enableIndexedDbPersistence
} from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: "AIzaSyAdv9cNM-CIYEigks0OysevRlavcFEm1UM",
  authDomain: "safarshare-7fc91.firebaseapp.com",
  projectId: "safarshare-7fc91",
  storageBucket: "safarshare-7fc91.firebasestorage.app",
  messagingSenderId: "838587520163",
  appId: "1:838587520163:web:8b84c6954939093a61db16",
  measurementId: "G-WRH1W4KRQ8"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

// Safe offline persistence attempt
try {
  enableIndexedDbPersistence(db).catch(() => {
    // Ignored in environments where multiple tabs or private browsing are active
  });
} catch (e) {
  // Ignored
}

export {
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  getDocs,
  signInWithPopup,
  signOut,
  onAuthStateChanged
};
export type { User };
